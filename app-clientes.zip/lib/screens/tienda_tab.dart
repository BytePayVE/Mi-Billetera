import 'package:flutter/material.dart';
import '../core/config.dart';
import '../core/theme.dart';
import '../widgets/ui_kit.dart';
import '../services/supabase_service.dart';
import 'bytecode_screen.dart';

class TiendaTab extends StatefulWidget {
  final Map<String, dynamic> myProfile;
  final double? tasaBcv;
  final ValueChanged<int> onNavigateTab;
  final ValueChanged<String> onShowNotice;

  const TiendaTab({
    super.key,
    required this.myProfile,
    required this.tasaBcv,
    required this.onNavigateTab,
    required this.onShowNotice,
  });

  @override
  State<TiendaTab> createState() => _TiendaTabState();
}

class _TiendaTabState extends State<TiendaTab> {
  late Future<Map<String, dynamic>> _future;

  @override
  void initState() {
    super.initState();
    _future = SupabaseService.fetchTiendaData();
  }

  Future<void> _reload() async {
    setState(() => _future = SupabaseService.fetchTiendaData());
  }

  int get _userMaxCuotas => (widget.myProfile['max_cuotas'] as num?)?.toInt() ?? 3;
  int get _userFase => (widget.myProfile['fase'] as num?)?.toInt() ?? 1;
  double get _userIniPct => AppConfig.inicialPorcentajePorFase(_userFase);
  String get _userFaseNombre => (widget.myProfile['fase_nombre'] ?? 'Bit').toString();

  void _openRequestSheet(Map<String, dynamic> p) {
    final int stock = (p['stock'] as num?)?.toInt() ?? 1;
    final int maxCant = stock < 5 ? stock : 5;
    final double precioUnit = (p['precio_usd'] as num?)?.toDouble() ?? 0.0;
    final int prodMax = (p['max_cuotas'] as num?)?.toInt() ?? 9;
    final int maxCuotasPlan = _userMaxCuotas < prodMax ? _userMaxCuotas : prodMax;

    int cantidad = 1;
    final motivoCtrl = TextEditingController();
    String? err;
    bool sending = false;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: PagobyteColors.paper,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => StatefulBuilder(
        builder: (context, setModal) {
          final double totalUsd = Formatters.r2(precioUnit * cantidad);
          final double inicialUsd = Formatters.r2(totalUsd * _userIniPct);
          final double cuotaUsd = Formatters.r2((totalUsd - inicialUsd) / maxCuotasPlan);

          return Padding(
            padding: EdgeInsets.fromLTRB(
              20,
              20,
              20,
              MediaQuery.of(ctx).viewInsets.bottom + 24,
            ),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(p['nombre'] ?? '', style: PagobyteTheme.heading(20)),
                  const SizedBox(height: 6),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: PagobyteColors.tint,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Simulador según tu Fase ($_userFaseNombre)',
                          style: const TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 12,
                            color: PagobyteColors.byteBlue,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text('Inicial según tu fase (${(_userIniPct * 100).round()}%):', style: TextStyle(fontSize: 13)),
                            Text(
                              '${Formatters.usd(inicialUsd)}${widget.tasaBcv != null ? ' (${Formatters.bs(inicialUsd * widget.tasaBcv!)})' : ''}',
                              style: PagobyteTheme.mono(13, color: PagobyteColors.ink),
                            ),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('$maxCuotasPlan cuotas quincenales:', style: const TextStyle(fontSize: 13)),
                            Text(
                              '${Formatters.usd(cuotaUsd)} c/u',
                              style: PagobyteTheme.mono(13, color: PagobyteColors.byteBlue),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  const Text('Cantidad', style: TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 6),
                  DropdownButtonFormField<int>(
                    value: cantidad,
                    items: List.generate(maxCant, (i) => i + 1)
                        .map((n) => DropdownMenuItem(value: n, child: Text('$n')))
                        .toList(),
                    onChanged: (v) {
                      if (v != null) setModal(() => cantidad = v);
                    },
                  ),
                  const SizedBox(height: 14),
                  const Text('¿Para qué lo necesitas?', style: TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 6),
                  TextField(
                    controller: motivoCtrl,
                    maxLines: 3,
                    onChanged: (_) => setModal(() {}),
                    decoration: const InputDecoration(
                      hintText: 'Cuéntanos con tus palabras para qué lo vas a usar y por qué lo necesitas ahora.',
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    motivoCtrl.text.trim().length < 20
                        ? 'Te faltan ${20 - motivoCtrl.text.trim().length} letras (mínimo 20).'
                        : 'Listo.',
                    style: const TextStyle(color: PagobyteColors.muted, fontSize: 12.5),
                  ),
                  if (err != null) ...[
                    const SizedBox(height: 8),
                    Text(err!, style: const TextStyle(color: PagobyteColors.bad, fontWeight: FontWeight.w600)),
                  ],
                  const SizedBox(height: 14),
                  ElevatedButton(
                    onPressed: sending
                        ? null
                        : () async {
                            if (motivoCtrl.text.trim().length < 20) {
                              setModal(() => err = 'Escribe al menos 20 caracteres en el motivo.');
                              return;
                            }
                            setModal(() {
                              sending = true;
                              err = null;
                            });
                            try {
                              await SupabaseService.solicitarProducto(
                                productoId: p['id'] as String,
                                cantidad: cantidad,
                                motivo: motivoCtrl.text,
                              );
                              if (ctx.mounted) Navigator.pop(ctx);
                              widget.onShowNotice('Recibimos tu solicitud. La revisaremos pronto.');
                              widget.onNavigateTab(2);
                            } catch (e) {
                              setModal(() {
                                sending = false;
                                err = e.toString();
                              });
                            }
                          },
                    child: Text(sending ? 'Enviando...' : 'Enviar solicitud'),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: _reload,
      child: FutureBuilder<Map<String, dynamic>>(
        future: _future,
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const PagobyteSkeletonList(count: 3, showHero: true);
          }
          if (snap.hasError) {
            return Center(child: Text('Error: ${snap.error}'));
          }

          final productos = List<Map<String, dynamic>>.from(snap.data!['productos']);
          final bool bloqueado = snap.data!['bloqueado'] as bool;

          return ListView(
            padding: const EdgeInsets.fromLTRB(18, 12, 18, 110),
            children: [
              // Tarjeta rápida de Escáner QR en Tienda Física
              if (!bloqueado)
                Container(
                  margin: const EdgeInsets.only(bottom: 14),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: PagobyteColors.ink,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: PagobyteColors.cyan.withOpacity(0.18),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Icon(Icons.pin_outlined, color: PagobyteColors.cyan, size: 26),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '¿Estás en una Tienda Aliada?',
                              style: PagobyteTheme.heading(15, color: Colors.white),
                            ),
                            const Text(
                              'Genera tu ByteCode de 6 dígitos y díctalo en caja.',
                              style: TextStyle(color: Color(0xFFB9C3DE), fontSize: 12),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 8),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: PagobyteColors.cyan,
                          foregroundColor: PagobyteColors.ink,
                          minimumSize: const Size(86, 40),
                          padding: const EdgeInsets.symmetric(horizontal: 12),
                        ),
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => const ByteCodeScreen()),
                          );
                        },
                        child: const Text('ByteCode'),
                      ),
                    ],
                  ),
                ),

              if (bloqueado)
                Container(
                  margin: const EdgeInsets.only(bottom: 14),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: PagobyteColors.card,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: PagobyteColors.byteBlue, width: 1.5),
                  ),
                  child: const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'YA TIENES ALGO EN CURSO',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w800,
                          color: PagobyteColors.byteBlue,
                        ),
                      ),
                      SizedBox(height: 6),
                      Text(
                        'Puedes tener una solicitud o una compra a la vez. Podrás pedir otro producto cuando termines de pagar el actual.',
                      ),
                    ],
                  ),
                ),

              if (productos.isEmpty)
                const Center(child: Text('Pronto tendremos productos para ti.'))
              else
                ...productos.map((p) {
                  final int stock = (p['stock'] as num?)?.toInt() ?? 0;
                  final double precio = (p['precio_usd'] as num?)?.toDouble() ?? 0.0;
                  final double inicial = Formatters.r2(precio * _userIniPct);
                  final int prodMax = (p['max_cuotas'] as num?)?.toInt() ?? 9;
                  final int nCuotas = _userMaxCuotas < prodMax ? _userMaxCuotas : prodMax;
                  final double cuota = Formatters.r2((precio - inicial) / nCuotas);

                  return Container(
                    margin: const EdgeInsets.only(bottom: 12),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: PagobyteColors.card,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: PagobyteColors.line),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Text(
                                p['nombre'] ?? '',
                                style: PagobyteTheme.heading(16),
                              ),
                            ),
                            Text(
                              Formatters.usd(precio),
                              style: PagobyteTheme.mono(16, color: PagobyteColors.byteBlue),
                            ),
                          ],
                        ),
                        if ((p['descripcion'] ?? '').toString().isNotEmpty) ...[
                          const SizedBox(height: 6),
                          Text(
                            p['descripcion'],
                            style: const TextStyle(color: PagobyteColors.muted, fontSize: 13),
                          ),
                        ],
                        const SizedBox(height: 10),
                        // Simulador compacto en cada tarjeta
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                          decoration: BoxDecoration(
                            color: PagobyteColors.paper,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: PagobyteColors.line),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('Inicial (${(_userIniPct * 100).round()}%)', style: const TextStyle(fontSize: 11, color: PagobyteColors.muted)),
                                  Text(
                                    Formatters.usd(inicial),
                                    style: PagobyteTheme.mono(13, color: PagobyteColors.ink),
                                  ),
                                ],
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Text('$nCuotas cuotas sin interés', style: const TextStyle(fontSize: 11, color: PagobyteColors.muted)),
                                  Text(
                                    '${Formatters.usd(cuota)} c/u',
                                    style: PagobyteTheme.mono(13, color: PagobyteColors.byteBlue),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        if (stock <= 0) ...[
                          const SizedBox(height: 10),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                decoration: BoxDecoration(
                                  color: PagobyteColors.badBg,
                                  borderRadius: BorderRadius.circular(999),
                                ),
                                child: const Text(
                                  'Agotado',
                                  style: TextStyle(
                                    color: PagobyteColors.bad,
                                    fontWeight: FontWeight.w700,
                                    fontSize: 12,
                                  ),
                                ),
                              ),
                              TextButton.icon(
                                icon: const Icon(Icons.notifications_active_outlined, size: 17),
                                label: const Text(
                                  'Avísame cuando vuelva',
                                  style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12.5),
                                ),
                                onPressed: () async {
                                  try {
                                    await SupabaseService.suscribirAlertaStock(p['id'] as String);
                                    widget.onShowNotice('¡Listo! Te avisaremos apenas vuelva el stock de ${p['nombre']}.');
                                  } catch (e) {
                                    widget.onShowNotice('No se pudo activar la alerta: $e');
                                  }
                                },
                              ),
                            ],
                          ),
                        ] else if (!bloqueado) ...[
                          const SizedBox(height: 12),
                          ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: PagobyteColors.tint,
                              foregroundColor: PagobyteColors.byteBlue,
                            ),
                            onPressed: () => _openRequestSheet(p),
                            child: const Text('Solicitar este producto'),
                          ),
                        ],
                      ],
                    ),
                  );
                }),
            ],
          );
        },
      ),
    );
  }
}
