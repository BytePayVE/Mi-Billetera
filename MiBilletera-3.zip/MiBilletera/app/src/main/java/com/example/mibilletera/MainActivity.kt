package com.example.mibilletera

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs

// ================== COLORES ==================
private val AzulMedio = Color(0xFF3F6FE8)
private val Azul = Color(0xFF1E4FD8)
private val AzulOscuro = Color(0xFF0B2A8F)
private val AzulClaro = Color(0xFFDCE8FF)
private val AzulTexto = Color(0xFFC9D8FF)
private val Fondo = Color(0xFFF2F6FD)
private val Texto = Color(0xFF1B2733)
private val Gris = Color(0xFF7A8AA5)
private val Verde = Color(0xFF2E7D32)
private val VerdeClaro = Color(0xFFE3F5E8)

// ================== FUENTE ==================
// Por ahora usa la fuente del sistema. Luego aquí se cambia por Georama / Libre Franklin.
private val Fuente: FontFamily = FontFamily.SansSerif

private fun tipografia(f: FontFamily): Typography {
    val b = Typography()
    return Typography(
        displayLarge = b.displayLarge.copy(fontFamily = f),
        displayMedium = b.displayMedium.copy(fontFamily = f),
        displaySmall = b.displaySmall.copy(fontFamily = f),
        headlineLarge = b.headlineLarge.copy(fontFamily = f),
        headlineMedium = b.headlineMedium.copy(fontFamily = f),
        headlineSmall = b.headlineSmall.copy(fontFamily = f),
        titleLarge = b.titleLarge.copy(fontFamily = f),
        titleMedium = b.titleMedium.copy(fontFamily = f),
        titleSmall = b.titleSmall.copy(fontFamily = f),
        bodyLarge = b.bodyLarge.copy(fontFamily = f),
        bodyMedium = b.bodyMedium.copy(fontFamily = f),
        bodySmall = b.bodySmall.copy(fontFamily = f),
        labelLarge = b.labelLarge.copy(fontFamily = f),
        labelMedium = b.labelMedium.copy(fontFamily = f),
        labelSmall = b.labelSmall.copy(fontFamily = f)
    )
}

// ================== DATOS DE PRUEBA ==================
private const val USUARIO_VALIDO = "00"
private const val CLAVE_VALIDA = "0000"
private const val NOMBRE = "Carlos Mendoza"
private const val INICIALES = "CM"
private const val MONEDA = "$"
private const val SALDO = 1250.50

data class Tienda(val emoji: String, val nombre: String, val oferta: String)
data class Movimiento(val titulo: String, val fecha: String, val monto: Double)

private val tiendas = listOf(
    Tienda("🛒", "SuperMercado Central", "5% de descuento"),
    Tienda("💊", "Farmacia Salud", "10% en medicinas"),
    Tienda("⛽", "Gasolinera Ruta", "Acumula puntos"),
    Tienda("🍔", "Comidas Rápidas Sol", "2x1 los miércoles"),
    Tienda("👕", "Moda Express", "15% primera compra")
)

private val movimientos = listOf(
    Movimiento("Recarga de saldo", "Hoy", 200.0),
    Movimiento("SuperMercado Central", "Ayer", -45.30),
    Movimiento("Farmacia Salud", "Hace 2 días", -18.90),
    Movimiento("Pago recibido", "Hace 3 días", 80.0),
    Movimiento("Gasolinera Ruta", "Hace 5 días", -30.0)
)

private fun dinero(valor: Double): String =
    MONEDA + " " + String.format("%,.2f", valor)

// ================== ACTIVIDAD ==================
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.light(
                android.graphics.Color.TRANSPARENT,
                android.graphics.Color.TRANSPARENT
            )
        )
        setContent { AppBilletera() }
    }
}

@Composable
fun AppBilletera() {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Azul,
            onPrimary = Color.White,
            background = Fondo,
            surface = Color.White,
            onSurface = Texto
        ),
        typography = tipografia(Fuente)
    ) {
        ProvideTextStyle(MaterialTheme.typography.bodyLarge) {
            var sesionIniciada by rememberSaveable { mutableStateOf(false) }
            if (sesionIniciada) {
                PantallaPrincipal(onSalir = { sesionIniciada = false })
            } else {
                PantallaLogin(onEntrar = { sesionIniciada = true })
            }
        }
    }
}

// ================== LOGIN ==================
@Composable
private fun coloresCampo() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = Color.White,
    unfocusedTextColor = Color.White,
    focusedBorderColor = Color.White,
    unfocusedBorderColor = Color(0x99FFFFFF),
    focusedLabelColor = Color.White,
    unfocusedLabelColor = AzulTexto,
    cursorColor = Color.White,
    focusedLeadingIconColor = Color.White,
    unfocusedLeadingIconColor = AzulTexto
)

@Composable
fun PantallaLogin(onEntrar: () -> Unit) {
    var usuario by remember { mutableStateOf("") }
    var clave by remember { mutableStateOf("") }
    var hayError by remember { mutableStateOf(false) }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF8CB0FF), Color(0xFF4F7DF0))))
    ) {
        // círculos decorativos del fondo
        Box(
            Modifier
                .size(260.dp)
                .offset(x = (-80).dp, y = (-60).dp)
                .background(Color(0x26FFFFFF), CircleShape)
        )
        Box(
            Modifier
                .size(240.dp)
                .align(Alignment.BottomEnd)
                .offset(x = 80.dp, y = 70.dp)
                .background(Color(0x22FFFFFF), CircleShape)
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .shadow(20.dp, RoundedCornerShape(28.dp))
                    .clip(RoundedCornerShape(28.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF2A5BEA), Color(0xFF10349F))))
                    .padding(26.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Box(
                        Modifier
                            .size(76.dp)
                            .background(Color.White, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("MB", color = Azul, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                    }
                    Spacer(Modifier.height(16.dp))
                    Text("Bienvenido", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Text("Ingresa para ver tu billetera", color = AzulTexto, fontSize = 15.sp)
                    Spacer(Modifier.height(24.dp))

                    OutlinedTextField(
                        value = usuario,
                        onValueChange = { usuario = it; hayError = false },
                        label = { Text("Usuario") },
                        leadingIcon = { Icon(Icons.Filled.Person, contentDescription = null) },
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp),
                        colors = coloresCampo(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(14.dp))
                    OutlinedTextField(
                        value = clave,
                        onValueChange = { clave = it; hayError = false },
                        label = { Text("Clave") },
                        leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = null) },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        shape = RoundedCornerShape(16.dp),
                        colors = coloresCampo(),
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (hayError) {
                        Spacer(Modifier.height(10.dp))
                        Text("Usuario o clave incorrectos", color = Color(0xFFFFD0D0), fontSize = 14.sp)
                    }

                    Spacer(Modifier.height(22.dp))
                    Button(
                        onClick = {
                            if (usuario == USUARIO_VALIDO && clave == CLAVE_VALIDA) onEntrar()
                            else hayError = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Azul),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                    ) {
                        Text("Entrar", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    }
                    TextButton(onClick = { }) {
                        Text("¿Olvidaste tu clave?", color = AzulTexto)
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
            Text("Versión de prueba", color = Color.White, fontSize = 13.sp)
        }
    }
}

// ================== PANTALLA PRINCIPAL ==================
@Composable
fun PantallaPrincipal(onSalir: () -> Unit) {
    var pestana by rememberSaveable { mutableIntStateOf(0) }

    Scaffold(
        containerColor = Fondo,
        contentWindowInsets = WindowInsets(0.dp, 0.dp, 0.dp, 0.dp),
        bottomBar = {
            NavigationBar(containerColor = Color.White, tonalElevation = 8.dp) {
                ItemMenu(pestana == 0, { pestana = 0 }, Icons.Filled.Home, "Billetera")
                ItemMenu(pestana == 1, { pestana = 1 }, Icons.Filled.ShoppingCart, "Tiendas")
                ItemMenu(pestana == 2, { pestana = 2 }, Icons.Filled.Person, "Cuenta")
            }
        }
    ) { padding ->
        when (pestana) {
            0 -> TabBilletera(padding)
            1 -> TabTiendas(padding)
            else -> TabCuenta(padding, onSalir)
        }
    }
}

@Composable
private fun RowScope.ItemMenu(
    seleccionado: Boolean,
    alPulsar: () -> Unit,
    icono: ImageVector,
    texto: String
) {
    NavigationBarItem(
        selected = seleccionado,
        onClick = alPulsar,
        icon = { Icon(icono, contentDescription = texto) },
        label = { Text(texto, fontSize = 12.sp) },
        colors = NavigationBarItemDefaults.colors(
            selectedIconColor = Azul,
            selectedTextColor = Azul,
            indicatorColor = AzulClaro,
            unselectedIconColor = Gris,
            unselectedTextColor = Gris
        )
    )
}

// Encabezado azul con degradado y esquinas redondeadas abajo
@Composable
private fun Encabezado(contenido: @Composable ColumnScope.() -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp))
            .background(Brush.linearGradient(listOf(AzulMedio, AzulOscuro)))
    ) {
        Box(
            Modifier
                .size(190.dp)
                .align(Alignment.TopEnd)
                .offset(x = 70.dp, y = (-50).dp)
                .background(Color(0x1FFFFFFF), CircleShape)
        )
        Column(
            modifier = Modifier
                .statusBarsPadding()
                .padding(horizontal = 20.dp, vertical = 20.dp),
            content = contenido
        )
    }
}

// ================== PESTAÑA BILLETERA ==================
@Composable
fun TabBilletera(padding: PaddingValues) {
    var saldoVisible by remember { mutableStateOf(true) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Fondo)
            .padding(padding),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 20.dp)
    ) {
        item {
            Encabezado {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(46.dp)
                            .background(Color(0x33FFFFFF), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(INICIALES, color = Color.White, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Bienvenido", color = AzulTexto, fontSize = 13.sp)
                        Text(NOMBRE, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }
                    Icon(Icons.Filled.Notifications, contentDescription = "Notificaciones", tint = Color.White)
                }
                Spacer(Modifier.height(24.dp))
                Box(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(24.dp))
                        .background(Color(0x26FFFFFF))
                        .padding(22.dp)
                ) {
                    Column {
                        Text("Saldo disponible", color = AzulTexto, fontSize = 14.sp)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            if (saldoVisible) dinero(SALDO) else "$MONEDA ••••••",
                            color = Color.White,
                            fontSize = 36.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Spacer(Modifier.height(10.dp))
                        Text(
                            if (saldoVisible) "Ocultar saldo" else "Mostrar saldo",
                            color = Color.White,
                            fontSize = 13.sp,
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .clickable { saldoVisible = !saldoVisible }
                                .background(Color(0x33FFFFFF))
                                .padding(horizontal = 14.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }
        item {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                Accion("Recargar", Icons.Filled.Add)
                Accion("Pagar", Icons.Filled.ShoppingCart)
                Accion("Enviar", Icons.AutoMirrored.Filled.Send)
            }
        }
        item {
            Text(
                "Movimientos recientes",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Texto,
                modifier = Modifier.padding(horizontal = 20.dp)
            )
        }
        items(movimientos) { m -> FilaMovimiento(m) }
    }
}

@Composable
private fun Accion(texto: String, icono: ImageVector) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .size(64.dp)
                .shadow(6.dp, RoundedCornerShape(22.dp))
                .clip(RoundedCornerShape(22.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF3F7BFF), AzulOscuro)))
                .clickable { },
            contentAlignment = Alignment.Center
        ) {
            Icon(icono, contentDescription = texto, tint = Color.White)
        }
        Spacer(Modifier.height(8.dp))
        Text(texto, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Texto)
    }
}

@Composable
private fun FilaMovimiento(m: Movimiento) {
    val esIngreso = m.monto > 0
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(46.dp)
                    .background(if (esIngreso) VerdeClaro else AzulClaro, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    if (esIngreso) Icons.Filled.Add else Icons.Filled.ShoppingCart,
                    contentDescription = null,
                    tint = if (esIngreso) Verde else Azul
                )
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(m.titulo, fontWeight = FontWeight.SemiBold, color = Texto)
                Text(m.fecha, fontSize = 13.sp, color = Gris)
            }
            Text(
                (if (esIngreso) "+ " else "- ") + dinero(abs(m.monto)),
                fontWeight = FontWeight.Bold,
                color = if (esIngreso) Verde else Texto
            )
        }
    }
}

// ================== PESTAÑA TIENDAS ==================
@Composable
fun TabTiendas(padding: PaddingValues) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Fondo)
            .padding(padding),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 20.dp)
    ) {
        item {
            Encabezado {
                Text("Tiendas aliadas", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text("Paga y obtén beneficios exclusivos", color = AzulTexto, fontSize = 14.sp)
                Spacer(Modifier.height(8.dp))
            }
        }
        items(tiendas) { t ->
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier
                            .size(58.dp)
                            .background(AzulClaro, RoundedCornerShape(18.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(t.emoji, fontSize = 28.sp)
                    }
                    Spacer(Modifier.width(16.dp))
                    Column {
                        Text(t.nombre, fontWeight = FontWeight.Bold, color = Texto, fontSize = 16.sp)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            t.oferta,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = Azul,
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .background(AzulClaro)
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }
    }
}

// ================== PESTAÑA CUENTA ==================
@Composable
fun TabCuenta(padding: PaddingValues, onSalir: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .background(Fondo)
            .padding(padding)
    ) {
        Encabezado {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    Modifier
                        .size(86.dp)
                        .background(Color.White, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(INICIALES, color = Azul, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                }
                Spacer(Modifier.height(12.dp))
                Text(NOMBRE, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Usuario: $USUARIO_VALIDO", color = AzulTexto, fontSize = 14.sp)
                Spacer(Modifier.height(8.dp))
            }
        }
        Column(Modifier.padding(20.dp)) {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(horizontal = 20.dp, vertical = 12.dp)) {
                    FilaInfo("Nombre", NOMBRE)
                    FilaInfo("Usuario", USUARIO_VALIDO)
                    FilaInfo("Tipo de cuenta", "Prueba")
                }
            }
            Spacer(Modifier.height(24.dp))
            Button(
                onClick = onSalir,
                colors = ButtonDefaults.buttonColors(containerColor = Azul, contentColor = Color.White),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
            ) {
                Text("Cerrar sesión", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun FilaInfo(titulo: String, valor: String) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(titulo, color = Gris)
        Text(valor, fontWeight = FontWeight.SemiBold, color = Texto)
    }
}
