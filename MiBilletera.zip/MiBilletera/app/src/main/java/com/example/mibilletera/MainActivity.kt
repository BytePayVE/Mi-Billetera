package com.example.mibilletera

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs

// ---------- Colores (paleta de confianza: azul + blanco) ----------
private val Azul = Color(0xFF0D47A1)
private val AzulClaro = Color(0xFFBBDEFB)
private val Fondo = Color(0xFFF4F7FB)
private val Texto = Color(0xFF1B2733)
private val Verde = Color(0xFF2E7D32)
private val Rojo = Color(0xFFC62828)

// ---------- Datos de prueba ----------
private const val USUARIO_VALIDO = "00"
private const val CLAVE_VALIDA = "0000"
private const val NOMBRE = "Carlos Mendoza"
private const val MONEDA = "$"
private const val SALDO = 1250.50

data class Tienda(val emoji: String, val nombre: String, val oferta: String)
data class Movimiento(val titulo: String, val fecha: String, val monto: Double)

private val tiendas = listOf(
    Tienda("🛒", "SuperMercado Central", "5% de descuento en compras"),
    Tienda("💊", "Farmacia Salud", "10% de descuento en medicinas"),
    Tienda("⛽", "Gasolinera Ruta", "Acumula puntos por cada pago"),
    Tienda("🍔", "Comidas Rápidas Sol", "2x1 los miércoles"),
    Tienda("👕", "Moda Express", "15% en tu primera compra")
)

private val movimientos = listOf(
    Movimiento("Recarga de saldo", "Hoy", 200.0),
    Movimiento("SuperMercado Central", "Ayer", -45.30),
    Movimiento("Farmacia Salud", "Hace 2 días", -18.90),
    Movimiento("Pago recibido", "Hace 3 días", 80.0),
    Movimiento("Gasolinera Ruta", "Hace 5 días", -30.0)
)

private fun dinero(valor: Double): String =
    MONEDA + " " + String.format("%,.2f", valor)

// ---------- Actividad principal ----------
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppBilletera() }
    }
}

@Composable
fun AppBilletera() {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Azul,
            onPrimary = Color.White,
            background = Fondo,
            surface = Color.White,
            onSurface = Texto
        )
    ) {
        var sesionIniciada by rememberSaveable { mutableStateOf(false) }
        if (sesionIniciada) {
            PantallaPrincipal(onSalir = { sesionIniciada = false })
        } else {
            PantallaLogin(onEntrar = { sesionIniciada = true })
        }
    }
}

// ---------- Pantalla de login ----------
@Composable
fun PantallaLogin(onEntrar: () -> Unit) {
    var usuario by remember { mutableStateOf("") }
    var clave by remember { mutableStateOf("") }
    var hayError by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Azul)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("💙", fontSize = 48.sp)
        Text("Mi Billetera", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Text("Tus pagos, simples y seguros", color = AzulClaro, fontSize = 16.sp)
        Spacer(Modifier.height(32.dp))

        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(20.dp)) {
                Text("Iniciar sesión", fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = Texto)
                Spacer(Modifier.height(16.dp))

                OutlinedTextField(
                    value = usuario,
                    onValueChange = { usuario = it; hayError = false },
                    label = { Text("Usuario") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = clave,
                    onValueChange = { clave = it; hayError = false },
                    label = { Text("Clave") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    modifier = Modifier.fillMaxWidth()
                )

                if (hayError) {
                    Text(
                        "Usuario o clave incorrectos",
                        color = Rojo,
                        fontSize = 14.sp,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }

                Spacer(Modifier.height(20.dp))
                Button(
                    onClick = {
                        if (usuario == USUARIO_VALIDO && clave == CLAVE_VALIDA) onEntrar()
                        else hayError = true
                    },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                ) {
                    Text("Entrar", fontSize = 18.sp)
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("Versión de prueba", color = AzulClaro, fontSize = 13.sp)
    }
}

// ---------- Pantalla principal con menú inferior ----------
@Composable
fun PantallaPrincipal(onSalir: () -> Unit) {
    var pestana by rememberSaveable { mutableIntStateOf(0) }

    Scaffold(
        containerColor = Fondo,
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                NavigationBarItem(
                    selected = pestana == 0,
                    onClick = { pestana = 0 },
                    icon = { Text("💳") },
                    label = { Text("Billetera") }
                )
                NavigationBarItem(
                    selected = pestana == 1,
                    onClick = { pestana = 1 },
                    icon = { Text("🏪") },
                    label = { Text("Tiendas") }
                )
                NavigationBarItem(
                    selected = pestana == 2,
                    onClick = { pestana = 2 },
                    icon = { Text("👤") },
                    label = { Text("Cuenta") }
                )
            }
        }
    ) { padding ->
        when (pestana) {
            0 -> TabBilletera(padding)
            1 -> TabTiendas(padding)
            else -> TabCuenta(padding, onSalir)
        }
    }
}

// ---------- Pestaña 1: Billetera ----------
@Composable
fun TabBilletera(padding: PaddingValues) {
    var saldoVisible by remember { mutableStateOf(true) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Fondo)
            .padding(padding),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Hola, Carlos 👋", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Texto)
        }
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Azul),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(24.dp)) {
                    Text("Saldo disponible", color = AzulClaro, fontSize = 15.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        if (saldoVisible) dinero(SALDO) else "$MONEDA ••••••",
                        color = Color.White,
                        fontSize = 36.sp,
                        fontWeight = FontWeight.Bold
                    )
                    TextButton(onClick = { saldoVisible = !saldoVisible }) {
                        Text(
                            if (saldoVisible) "Ocultar saldo" else "Mostrar saldo",
                            color = Color.White
                        )
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth()) {
                Button(
                    onClick = { },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f)
                ) { Text("Recargar") }
                Spacer(Modifier.width(12.dp))
                OutlinedButton(
                    onClick = { },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f)
                ) { Text("Pagar") }
            }
        }
        item {
            Text(
                "Movimientos recientes",
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
                color = Texto
            )
        }
        items(movimientos) { m -> FilaMovimiento(m) }
    }
}

@Composable
fun FilaMovimiento(m: Movimiento) {
    val esIngreso = m.monto > 0
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(m.titulo, fontWeight = FontWeight.Medium, color = Texto)
                Text(m.fecha, fontSize = 13.sp, color = Color.Gray)
            }
            Text(
                (if (esIngreso) "+ " else "- ") + dinero(abs(m.monto)),
                fontWeight = FontWeight.Bold,
                color = if (esIngreso) Verde else Texto
            )
        }
    }
}

// ---------- Pestaña 2: Tiendas aliadas ----------
@Composable
fun TabTiendas(padding: PaddingValues) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Fondo)
            .padding(padding),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Tiendas aliadas", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Texto)
        }
        items(tiendas) { t ->
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(t.emoji, fontSize = 32.sp)
                    Spacer(Modifier.width(16.dp))
                    Column {
                        Text(t.nombre, fontWeight = FontWeight.SemiBold, color = Texto)
                        Text(t.oferta, fontSize = 14.sp, color = Azul)
                    }
                }
            }
        }
    }
}

// ---------- Pestaña 3: Cuenta ----------
@Composable
fun TabCuenta(padding: PaddingValues, onSalir: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Fondo)
            .padding(padding)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("👤", fontSize = 64.sp)
        Text(NOMBRE, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Texto)
        Text("Usuario: $USUARIO_VALIDO", color = Color.Gray)
        Spacer(Modifier.height(32.dp))
        Button(
            onClick = onSalir,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
        ) {
            Text("Cerrar sesión", fontSize = 16.sp)
        }
    }
}
