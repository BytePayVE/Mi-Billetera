import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../core/terms_data.dart';
import 'contract_reading_screen.dart';
import '../core/theme.dart';
import '../services/supabase_service.dart';
import '../widgets/pagobyte_logo.dart';

class AuthScreen extends StatefulWidget {
  final VoidCallback onAuthenticated;

  const AuthScreen({super.key, required this.onAuthenticated});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  bool _isLogin = true;
  bool _loading = false;
  bool _emailSent = false;
  bool _acceptedTerms = false;
  String _tipoCedula = 'V';
  String _estado = 'Lara';
  String _tipoZona = 'Urbanización';
  String? _errorMsg;
  int _loginAttempts = 0;
  DateTime? _loginBlockedUntil;

  Uint8List? _cedulaBytes;
  String? _cedulaName;
  Uint8List? _selfieBytes;
  String? _selfieName;

  final _picker = ImagePicker();

  final _emailLoginCtrl = TextEditingController();
  final _passLoginCtrl = TextEditingController();

  final _nombreCtrl = TextEditingController();
  final _numCedCtrl = TextEditingController();
  final _telCtrl = TextEditingController();
  final _ciudadCtrl = TextEditingController();
  final _direccionCtrl = TextEditingController();
  final _emailRegCtrl = TextEditingController();
  final _passRegCtrl = TextEditingController();

  static const List<String> _estadosVzla = [
    'Amazonas', 'Anzoátegui', 'Apure', 'Aragua', 'Barinas', 'Bolívar',
    'Carabobo', 'Cojedes', 'Delta Amacuro', 'Distrito Capital', 'Falcón',
    'Guárico', 'La Guaira', 'Lara', 'Mérida', 'Miranda', 'Monagas',
    'Nueva Esparta', 'Portuguesa', 'Sucre', 'Táchira', 'Trujillo',
    'Yaracuy', 'Zulia',
  ];

  static const List<String> _tiposZona = [
    'Urbanización',
    'Barrio',
    'Caserío',
    'Villa',
    'Sector',
    'Avenida / Calle',
  ];

  @override
  void dispose() {
    _emailLoginCtrl.dispose();
    _passLoginCtrl.dispose();
    _nombreCtrl.dispose();
    _numCedCtrl.dispose();
    _telCtrl.dispose();
    _ciudadCtrl.dispose();
    _direccionCtrl.dispose();
    _emailRegCtrl.dispose();
    _passRegCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickPhoto({required bool isSelfie}) async {
    final source = await showModalBottomSheet<ImageSource>(
      context: context,
      backgroundColor: PagobyteColors.card,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.camera_alt, color: PagobyteColors.byteBlue),
              title: const Text('Tomar foto con cámara'),
              onTap: () => Navigator.pop(ctx, ImageSource.camera),
            ),
            ListTile(
              leading: const Icon(Icons.photo_library, color: PagobyteColors.byteBlue),
              title: const Text('Elegir de la galería'),
              onTap: () => Navigator.pop(ctx, ImageSource.gallery),
            ),
          ],
        ),
      ),
    );
    if (source == null) return;

    final picked = await _picker.pickImage(
      source: source,
      preferredCameraDevice: isSelfie ? CameraDevice.front : CameraDevice.rear,
      maxWidth: 1280,
      imageQuality: 80,
    );
    if (picked == null) return;
    final bytes = await picked.readAsBytes();
    setState(() {
      if (isSelfie) {
        _selfieBytes = bytes;
        _selfieName = picked.name;
      } else {
        _cedulaBytes = bytes;
        _cedulaName = picked.name;
      }
    });
  }

  Future<void> _handleLogin() async {
    if (_loginBlockedUntil != null && DateTime.now().isBefore(_loginBlockedUntil!)) {
      final secs = _loginBlockedUntil!.difference(DateTime.now()).inSeconds + 1;
      setState(() => _errorMsg = 'Demasiados intentos fallidos. Espera ${secs}s para volver a intentar.');
      return;
    }
    setState(() {
      _errorMsg = null;
      _loading = true;
    });
    try {
      await SupabaseService.signIn(_emailLoginCtrl.text, _passLoginCtrl.text);
      _loginAttempts = 0;
      _loginBlockedUntil = null;
      widget.onAuthenticated();
    } on AuthException catch (e) {
      _loginAttempts++;
      if (_loginAttempts >= 5) {
        _loginBlockedUntil = DateTime.now().add(const Duration(seconds: 30));
        _loginAttempts = 0;
      }
      setState(() {
        _errorMsg = e.message.toLowerCase().contains('confirm')
            ? 'Primero confirma tu correo con el enlace que te enviamos.'
            : 'Correo o contraseña incorrectos.';
      });
    } catch (_) {
      setState(() => _errorMsg = 'No se pudo iniciar sesión. Intenta de nuevo.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _handleSignUp() async {
    setState(() => _errorMsg = null);
    final cedula = '$_tipoCedula${_numCedCtrl.text.replaceAll(RegExp(r'\D'), '')}';
    final telefono = _telCtrl.text.replaceAll(RegExp(r'[^\d+]'), '');

    if (_nombreCtrl.text.trim().length < 4) {
      setState(() => _errorMsg = 'Ingresa tu nombre y apellido completo.');
      return;
    }
    if (!RegExp(r'^[VE]\d{6,9}$').hasMatch(cedula)) {
      setState(() => _errorMsg = 'Revisa tu cédula: deben ser de 6 a 9 números.');
      return;
    }
    if (!RegExp(r'^\+?\d{10,15}$').hasMatch(telefono)) {
      setState(() => _errorMsg = 'Revisa tu teléfono: deben ser de 10 a 15 números.');
      return;
    }
    if (_ciudadCtrl.text.trim().length < 3) {
      setState(() => _errorMsg = 'Indica la ciudad o pueblo donde vives.');
      return;
    }
    if (_direccionCtrl.text.trim().length < 6) {
      setState(() => _errorMsg = 'Indica el nombre de tu $_tipoZona y dirección exacta.');
      return;
    }
    if (_cedulaBytes == null) {
      setState(() => _errorMsg = 'Por seguridad, debes subir la foto frontal de tu cédula.');
      return;
    }
    if (_selfieBytes == null) {
      setState(() => _errorMsg = 'Por seguridad, debes subir una foto tuya (selfie) verificando tu identidad.');
      return;
    }
    if (_passRegCtrl.text.length < 8) {
      setState(() => _errorMsg = 'La contraseña debe tener mínimo 8 caracteres.');
      return;
    }
    if (!_acceptedTerms) {
      setState(() => _errorMsg = 'Debes aceptar los Términos y Condiciones y la Política de Privacidad.');
      return;
    }

    setState(() => _loading = true);
    try {
      final res = await SupabaseService.signUpClient(
        nombre: _nombreCtrl.text,
        cedula: cedula,
        telefono: telefono,
        email: _emailRegCtrl.text,
        password: _passRegCtrl.text,
        estado: _estado,
        ciudad: _ciudadCtrl.text,
        tipoZona: _tipoZona,
        direccionDetalle: _direccionCtrl.text,
        cedulaPhotoBytes: _cedulaBytes!,
        selfiePhotoBytes: _selfieBytes!,
      );
      if (res.session != null) {
        widget.onAuthenticated();
      } else {
        setState(() => _emailSent = true);
      }
    } on AuthException catch (e) {
      final m = e.message.toLowerCase();
      setState(() {
        if (m.contains('rate limit')) {
          _errorMsg = 'Se enviaron demasiados correos seguidos. Espera unos minutos.';
        } else if (m.contains('database error')) {
          _errorMsg = 'Esa cédula ya podría estar registrada o un dato es inválido.';
        } else if (m.contains('already')) {
          _errorMsg = 'Ese correo ya tiene una cuenta. Entra con tu contraseña.';
        } else {
          _errorMsg = 'No se pudo crear la cuenta. Intenta de nuevo.';
        }
      });
    } catch (_) {
      setState(() => _errorMsg = 'Error de conexión al registrar la cuenta.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _openPasswordRecoverySheet() {
    final emailCtrl = TextEditingController(text: _emailLoginCtrl.text.trim());
    final otpCtrl = TextEditingController();
    final newPassCtrl = TextEditingController();
    bool codeSent = false;
    bool busy = false;
    String? err;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: PagobyteColors.paper,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => StatefulBuilder(
        builder: (context, setModal) => Padding(
          padding: EdgeInsets.fromLTRB(
            20,
            20,
            20,
            MediaQuery.of(ctx).viewInsets.bottom + 24,
          ),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Recuperar contraseña', style: PagobyteTheme.heading(20)),
                const SizedBox(height: 6),
                Text(
                  codeSent
                      ? 'Ingresa el código de 6 dígitos que enviamos a tu correo y elige tu nueva contraseña.'
                      : 'Escribe el correo con el que te registraste y te enviaremos un código de 6 dígitos.',
                  style: const TextStyle(color: PagobyteColors.muted, fontSize: 13.5),
                ),
                const SizedBox(height: 14),
                TextField(
                  controller: emailCtrl,
                  enabled: !codeSent,
                  keyboardType: TextInputType.emailAddress,
                  decoration: const InputDecoration(labelText: 'Correo electrónico'),
                ),
                if (codeSent) ...[
                  const SizedBox(height: 10),
                  TextField(
                    controller: otpCtrl,
                    keyboardType: TextInputType.number,
                    maxLength: 6,
                    decoration: const InputDecoration(
                      labelText: 'Código de 6 dígitos',
                      counterText: '',
                    ),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: newPassCtrl,
                    obscureText: true,
                    decoration: const InputDecoration(
                      labelText: 'Nueva contraseña (mínimo 8 caracteres)',
                    ),
                  ),
                ],
                if (err != null) ...[
                  const SizedBox(height: 8),
                  Text(
                    err!,
                    style: const TextStyle(
                      color: PagobyteColors.bad,
                      fontWeight: FontWeight.w600,
                      fontSize: 13,
                    ),
                  ),
                ],
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: busy
                      ? null
                      : () async {
                          if (!codeSent) {
                            if (!emailCtrl.text.contains('@')) {
                              setModal(() => err = 'Ingresa un correo válido.');
                              return;
                            }
                            setModal(() {
                              busy = true;
                              err = null;
                            });
                            try {
                              await SupabaseService.sendPasswordResetOtp(emailCtrl.text);
                              setModal(() {
                                busy = false;
                                codeSent = true;
                              });
                            } catch (e) {
                              setModal(() {
                                busy = false;
                                err = 'No se pudo enviar el código: $e';
                              });
                            }
                          } else {
                            if (otpCtrl.text.trim().length < 6) {
                              setModal(() => err = 'Ingresa el código completo de 6 dígitos.');
                              return;
                            }
                            if (newPassCtrl.text.length < 8) {
                              setModal(() => err = 'La nueva contraseña debe tener mínimo 8 caracteres.');
                              return;
                            }
                            setModal(() {
                              busy = true;
                              err = null;
                            });
                            try {
                              await SupabaseService.verifyRecoveryOtpAndUpdatePassword(
                                email: emailCtrl.text,
                                token: otpCtrl.text,
                                newPassword: newPassCtrl.text,
                              );
                              if (ctx.mounted) Navigator.pop(ctx);
                              widget.onAuthenticated();
                            } catch (e) {
                              setModal(() {
                                busy = false;
                                err = 'Código inválido o expirado. Intenta de nuevo.';
                              });
                            }
                          }
                        },
                  child: Text(
                    busy
                        ? 'Procesando...'
                        : (codeSent ? 'Cambiar contraseña y entrar' : 'Enviar código al correo'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: PagobyteColors.ink,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 26, 24, 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const PagobyteLogo(size: 46, darkSurface: true),
                  const SizedBox(height: 12),
                  const PagobyteWordmark(fontSize: 32, darkSurface: true),
                  const SizedBox(height: 4),
                  const Text(
                    'Tecnología en partes. Cuotas claras, a tu ritmo.',
                    style: TextStyle(color: Color(0xFFB9C3DE), fontSize: 14.5),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Container(
                width: double.infinity,
                decoration: const BoxDecoration(
                  color: PagobyteColors.paper,
                  borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
                ),
                child: SingleChildScrollView(
                  padding: const EdgeInsets.fromLTRB(22, 22, 22, 36),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          color: const Color(0xFFE5E9F4),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Row(
                          children: [
                            _tabButton('Entrar', _isLogin, () {
                              setState(() {
                                _isLogin = true;
                                _emailSent = false;
                                _errorMsg = null;
                              });
                            }),
                            _tabButton('Crear cuenta', !_isLogin, () {
                              setState(() {
                                _isLogin = false;
                                _emailSent = false;
                                _errorMsg = null;
                              });
                            }),
                          ],
                        ),
                      ),
                      const SizedBox(height: 18),
                      if (_emailSent) _buildEmailConfirmationCard()
                      else if (_isLogin) _buildLoginForm()
                      else _buildSignUpForm(),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _tabButton(String label, bool active, VoidCallback onTap) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: active ? Colors.white : Colors.transparent,
            borderRadius: BorderRadius.circular(9),
          ),
          child: Text(
            label,
            style: TextStyle(
              fontWeight: FontWeight.w700,
              color: active ? PagobyteColors.ink : PagobyteColors.muted,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildLoginForm() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _fieldLabel('Correo'),
        TextField(
          controller: _emailLoginCtrl,
          keyboardType: TextInputType.emailAddress,
          decoration: const InputDecoration(hintText: 'tu@correo.com'),
        ),
        _fieldLabel('Contraseña'),
        TextField(
          controller: _passLoginCtrl,
          obscureText: true,
          decoration: const InputDecoration(hintText: '••••••••'),
        ),
        if (_errorMsg != null) _errorWidget(_errorMsg!),
        const SizedBox(height: 18),
        ElevatedButton(
          onPressed: _loading ? null : _handleLogin,
          child: Text(_loading ? 'Entrando...' : 'Entrar'),
        ),
        const SizedBox(height: 8),
        Center(
          child: TextButton(
            onPressed: _openPasswordRecoverySheet,
            child: const Text(
              '¿Olvidaste tu contraseña?',
              style: TextStyle(
                color: PagobyteColors.byteBlue,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSignUpForm() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('1. Datos de identidad', style: PagobyteTheme.heading(16, color: PagobyteColors.byteBlue)),
        _fieldLabel('Nombre y apellido completo'),
        TextField(
          controller: _nombreCtrl,
          textCapitalization: TextCapitalization.words,
          decoration: const InputDecoration(hintText: 'Tal como aparece en tu cédula'),
        ),
        _fieldLabel('Cédula de identidad'),
        Row(
          children: [
            SizedBox(
              width: 78,
              child: DropdownButtonFormField<String>(
                value: _tipoCedula,
                items: const [
                  DropdownMenuItem(value: 'V', child: Text('V')),
                  DropdownMenuItem(value: 'E', child: Text('E')),
                ],
                onChanged: (v) {
                  if (v != null) setState(() => _tipoCedula = v);
                },
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: TextField(
                controller: _numCedCtrl,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(hintText: '12345678'),
              ),
            ),
          ],
        ),
        _fieldLabel('Teléfono de contacto (WhatsApp)'),
        TextField(
          controller: _telCtrl,
          keyboardType: TextInputType.phone,
          decoration: const InputDecoration(hintText: '04141234567'),
        ),

        const SizedBox(height: 20),
        Text('2. Domicilio y ubicación', style: PagobyteTheme.heading(16, color: PagobyteColors.byteBlue)),
        _fieldLabel('Estado'),
        DropdownButtonFormField<String>(
          value: _estado,
          items: _estadosVzla
              .map((e) => DropdownMenuItem(value: e, child: Text(e)))
              .toList(),
          onChanged: (v) {
            if (v != null) setState(() => _estado = v);
          },
        ),
        _fieldLabel('Ciudad o población'),
        TextField(
          controller: _ciudadCtrl,
          textCapitalization: TextCapitalization.words,
          decoration: const InputDecoration(hintText: 'Ej: El Tocuyo, Barquisimeto...'),
        ),
        _fieldLabel('Tipo de zona residencial'),
        DropdownButtonFormField<String>(
          value: _tipoZona,
          items: _tiposZona
              .map((z) => DropdownMenuItem(value: z, child: Text(z)))
              .toList(),
          onChanged: (v) {
            if (v != null) setState(() => _tipoZona = v);
          },
        ),
        _fieldLabel('Dirección exacta ($_tipoZona, calle, casa/apto)'),
        TextField(
          controller: _direccionCtrl,
          maxLines: 2,
          textCapitalization: TextCapitalization.sentences,
          decoration: InputDecoration(
            hintText: 'Nombre del $_tipoZona, calle, número de casa o punto de referencia',
          ),
        ),

        const SizedBox(height: 20),
        Text('3. Verificación de seguridad (KYC)', style: PagobyteTheme.heading(16, color: PagobyteColors.byteBlue)),
        const SizedBox(height: 4),
        const Text(
          'Por seguridad legal y prevención de fraude, sube una foto nítida de tu cédula y una foto tuya (selfie).',
          style: TextStyle(color: PagobyteColors.muted, fontSize: 12.5),
        ),
        const SizedBox(height: 10),
        OutlinedButton.icon(
          style: OutlinedButton.styleFrom(
            minimumSize: const Size(double.infinity, 48),
            side: BorderSide(
              color: _cedulaBytes != null ? PagobyteColors.ok : PagobyteColors.byteBlue,
            ),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
          icon: Icon(
            _cedulaBytes != null ? Icons.check_circle : Icons.badge_outlined,
            color: _cedulaBytes != null ? PagobyteColors.ok : PagobyteColors.byteBlue,
          ),
          label: Text(
            _cedulaName != null ? 'Cédula cargada: $_cedulaName' : 'Subir foto frontal de tu Cédula',
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: _cedulaBytes != null ? PagobyteColors.ok : PagobyteColors.byteBlue,
              fontWeight: FontWeight.w700,
            ),
          ),
          onPressed: () => _pickPhoto(isSelfie: false),
        ),
        const SizedBox(height: 10),
        OutlinedButton.icon(
          style: OutlinedButton.styleFrom(
            minimumSize: const Size(double.infinity, 48),
            side: BorderSide(
              color: _selfieBytes != null ? PagobyteColors.ok : PagobyteColors.byteBlue,
            ),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
          icon: Icon(
            _selfieBytes != null ? Icons.check_circle : Icons.face_retouching_natural,
            color: _selfieBytes != null ? PagobyteColors.ok : PagobyteColors.byteBlue,
          ),
          label: Text(
            _selfieName != null ? 'Selfie cargada: $_selfieName' : 'Tomar o subir foto tuya (Selfie)',
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: _selfieBytes != null ? PagobyteColors.ok : PagobyteColors.byteBlue,
              fontWeight: FontWeight.w700,
            ),
          ),
          onPressed: () => _pickPhoto(isSelfie: true),
        ),

        const SizedBox(height: 20),
        Text('4. Acceso a la cuenta', style: PagobyteTheme.heading(16, color: PagobyteColors.byteBlue)),
        _fieldLabel('Correo electrónico'),
        TextField(
          controller: _emailRegCtrl,
          keyboardType: TextInputType.emailAddress,
          decoration: const InputDecoration(hintText: 'tu@correo.com'),
        ),
        _fieldLabel('Contraseña (mínimo 8 caracteres)'),
        TextField(
          controller: _passRegCtrl,
          obscureText: true,
          decoration: const InputDecoration(hintText: '••••••••'),
        ),
        const SizedBox(height: 14),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: _acceptedTerms ? PagobyteColors.okBg : PagobyteColors.tint,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: _acceptedTerms ? PagobyteColors.ok : PagobyteColors.byteBlue,
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(
                    _acceptedTerms ? Icons.verified : Icons.gavel_outlined,
                    color: _acceptedTerms ? PagobyteColors.ok : PagobyteColors.byteBlue,
                    size: 20,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      _acceptedTerms
                          ? 'Contrato leído al 100% y aceptado'
                          : 'Lectura obligatoria del Contrato Legal (0% → 100%)',
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 13.5,
                        color: _acceptedTerms ? PagobyteColors.ok : PagobyteColors.ink,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Text(
                _acceptedTerms
                    ? 'Tu aceptación electrónica de Términos y Política de Privacidad está lista para guardarse en tu expediente.'
                    : 'Antes de crear tu cuenta debes leer el contrato completo con las leyes vigentes de Venezuela y Política de Privacidad.',
                style: const TextStyle(fontSize: 12.5, color: PagobyteColors.muted),
              ),
              const SizedBox(height: 10),
              OutlinedButton.icon(
                style: OutlinedButton.styleFrom(
                  minimumSize: const Size(double.infinity, 44),
                  side: BorderSide(
                    color: _acceptedTerms ? PagobyteColors.ok : PagobyteColors.byteBlue,
                  ),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                icon: Icon(
                  _acceptedTerms ? Icons.check_circle : Icons.menu_book,
                  color: _acceptedTerms ? PagobyteColors.ok : PagobyteColors.byteBlue,
                ),
                label: Text(
                  _acceptedTerms ? 'Volver a leer el contrato' : 'Leer y aceptar contrato completo',
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                    color: _acceptedTerms ? PagobyteColors.ok : PagobyteColors.byteBlue,
                  ),
                ),
                onPressed: () async {
                  final ok = await Navigator.push<bool>(
                    context,
                    MaterialPageRoute(builder: (_) => const ContractReadingScreen()),
                  );
                  if (ok == true && mounted) {
                    setState(() => _acceptedTerms = true);
                  }
                },
              ),
            ],
          ),
        ),
        if (_errorMsg != null) _errorWidget(_errorMsg!),
        const SizedBox(height: 16),
        ElevatedButton(
          onPressed: _loading ? null : _handleSignUp,
          child: Text(_loading ? 'Verificando y creando cuenta...' : 'Crear mi cuenta'),
        ),
        const SizedBox(height: 8),
        const Text(
          'Te enviaremos un correo para confirmar tu identidad.',
          style: TextStyle(color: PagobyteColors.muted, fontSize: 13),
        ),
      ],
    );
  }

  Widget _buildEmailConfirmationCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: PagobyteColors.tint,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Revisa tu correo', style: PagobyteTheme.heading(20)),
          const SizedBox(height: 8),
          const Text(
            'Te enviamos un enlace para confirmar tu cuenta. Después de confirmarla, vuelve aquí y entra con tu correo y contraseña.',
            style: TextStyle(fontSize: 14, height: 1.45),
          ),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: () => setState(() {
              _isLogin = true;
              _emailSent = false;
            }),
            child: const Text('Ir a Iniciar sesión'),
          ),
        ],
      ),
    );
  }

  Widget _fieldLabel(String text) {
    return Padding(
      padding: const EdgeInsets.only(top: 12, bottom: 6),
      child: Text(
        text,
        style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
      ),
    );
  }

  Widget _errorWidget(String msg) {
    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: Text(
        msg,
        style: const TextStyle(
          color: PagobyteColors.bad,
          fontSize: 13.5,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}
