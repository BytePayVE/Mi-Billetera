import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import '../core/config.dart';
import '../core/theme.dart';
import '../services/notification_service.dart';
import '../services/security_service.dart';
import '../services/supabase_service.dart';
import '../widgets/pagobyte_logo.dart';
import '../widgets/ui_kit.dart';
import 'cuotas_tab.dart';
import 'inicio_tab.dart';
import 'perfil_tab.dart';
import 'tienda_tab.dart';

class HomeShell extends StatefulWidget {
  final VoidCallback onSignedOut;

  const HomeShell({super.key, required this.onSignedOut});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;
  bool _loading = true;
  Map<String, dynamic> _profile = {};
  double? _tasaBcv;
  int _unreadCount = 0;
  bool _locked = false;

  @override
  void initState() {
    super.initState();
    _checkBiometricLock();
    _initPermissionsAndNotifications();
    _bootstrap();
  }

  @override
  void dispose() {
    NotificationService.unsubscribe();
    super.dispose();
  }

  Future<void> _checkBiometricLock() async {
    final enabled = await SecurityService.isLockEnabled();
    if (!enabled) return;
    if (mounted) setState(() => _locked = true);
    final ok = await SecurityService.authenticate();
    if (ok && mounted) setState(() => _locked = false);
  }

  Future<void> _initPermissionsAndNotifications() async {
    if (!kIsWeb) {
      try {
        final status = await Permission.locationWhenInUse.status;
        if (status.isDenied) {
          await Permission.locationWhenInUse.request();
        }
      } catch (_) {}
    }

    await NotificationService.init();
    final user = SupabaseService.currentUser;
    if (user != null) {
      NotificationService.subscribeToSupabaseNotifications(
        userId: user.id,
        onNewNotification: (notif) {
          if (mounted) {
            setState(() => _unreadCount++);
            _showNotice('${notif['titulo'] ?? 'Aviso'}: ${notif['mensaje'] ?? ''}');
          }
        },
      );
      final notifs = await NotificationService.fetchMyNotifications();
      final unread = notifs.where((n) => n['leida'] != true).length;
      if (mounted) setState(() => _unreadCount = unread);
    }
  }

  Future<void> _bootstrap() async {
    try {
      final results = await Future.wait([
        SupabaseService.fetchMyBasicProfile(),
        SupabaseService.fetchLatestBcvRate(),
      ]);
      if (mounted) {
        setState(() {
          _profile = (results[0] as Map<String, dynamic>?) ?? {};
          _tasaBcv = results[1] as double?;
          _loading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _showNotice(String msg) {
    if (!mounted) return;
    final lower = msg.toLowerCase();
    final type = lower.contains('error') || lower.contains('no se pudo')
        ? ToastType.error
        : (lower.contains('listo') || lower.contains('aprob') || lower.contains('recibimos') || lower.contains('verific'))
            ? ToastType.success
            : ToastType.info;
    PagobyteToast.show(context, msg, type: type);
  }

  Future<void> _openNotificationsCenter() async {
    final notifs = await NotificationService.fetchMyNotifications();
    await NotificationService.markAllAsRead();
    if (mounted) setState(() => _unreadCount = 0);
    if (!mounted) return;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: PagobyteColors.paper,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => DraggableScrollableSheet(
        initialChildSize: 0.7,
        minChildSize: 0.4,
        maxChildSize: 0.9,
        expand: false,
        builder: (_, ctrl) => Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 18, 12, 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Notificaciones', style: PagobyteTheme.heading(20)),
                  TextButton(
                    onPressed: () => Navigator.pop(ctx),
                    child: const Text('Cerrar', style: TextStyle(fontWeight: FontWeight.w700)),
                  ),
                ],
              ),
            ),
            const Divider(height: 1, color: PagobyteColors.line),
            Expanded(
              child: notifs.isEmpty
                  ? const Center(
                      child: Text(
                        'No tienes notificaciones todavía.',
                        style: TextStyle(color: PagobyteColors.muted),
                      ),
                    )
                  : ListView.builder(
                      controller: ctrl,
                      padding: const EdgeInsets.all(16),
                      itemCount: notifs.length,
                      itemBuilder: (_, i) {
                        final n = notifs[i];
                        return Container(
                          margin: const EdgeInsets.only(bottom: 10),
                          padding: const EdgeInsets.all(14),
                          decoration: BoxDecoration(
                            color: PagobyteColors.card,
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(color: PagobyteColors.line),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                (n['titulo'] ?? 'Pagobyte').toString(),
                                style: PagobyteTheme.heading(15, color: PagobyteColors.byteBlue),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                (n['mensaje'] ?? '').toString(),
                                style: const TextStyle(fontSize: 13.5),
                              ),
                              const SizedBox(height: 6),
                              Text(
                                Formatters.fechaLarga(n['creada_en']?.toString()),
                                style: const TextStyle(color: PagobyteColors.muted, fontSize: 11.5),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_locked) {
      return Scaffold(
        backgroundColor: PagobyteColors.ink,
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const PagobyteLogo(size: 56, darkSurface: true),
                const SizedBox(height: 18),
                Text('Pagobyte bloqueado', style: PagobyteTheme.heading(22, color: Colors.white)),
                const SizedBox(height: 8),
                const Text(
                  'Usa tu huella o PIN del teléfono para continuar.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Color(0xFFB9C3DE)),
                ),
                const SizedBox(height: 24),
                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: PagobyteColors.cyan,
                    foregroundColor: PagobyteColors.ink,
                  ),
                  icon: const Icon(Icons.fingerprint),
                  label: const Text('Desbloquear'),
                  onPressed: _checkBiometricLock,
                ),
              ],
            ),
          ),
        ),
      );
    }

    if (_loading) {
      return const Scaffold(body: SafeArea(child: PagobyteSkeletonList(count: 3, showHero: true)));
    }

    final tabs = [
      InicioTab(
        myProfile: _profile,
        tasaBcv: _tasaBcv,
        onNavigateTab: (i) => setState(() => _index = i),
      ),
      TiendaTab(
        myProfile: _profile,
        tasaBcv: _tasaBcv,
        onNavigateTab: (i) => setState(() => _index = i),
        onShowNotice: _showNotice,
      ),
      CuotasTab(
        myProfile: _profile,
        tasaBcv: _tasaBcv,
        onShowNotice: _showNotice,
      ),
      const PerfilTab(),
    ];

    return Scaffold(
      appBar: AppBar(
        backgroundColor: PagobyteColors.paper,
        elevation: 0,
        title: const Row(
          children: [
            PagobyteLogo(size: 26),
            SizedBox(width: 8),
            PagobyteWordmark(fontSize: 20),
          ],
        ),
        actions: [
          Stack(
            alignment: Alignment.center,
            children: [
              IconButton(
                icon: const Icon(Icons.notifications_outlined, color: PagobyteColors.ink),
                onPressed: _openNotificationsCenter,
              ),
              if (_unreadCount > 0)
                Positioned(
                  right: 6,
                  top: 6,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1.5),
                    decoration: BoxDecoration(
                      color: PagobyteColors.bad,
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Text(
                      _unreadCount > 9 ? '9+' : '$_unreadCount',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 10,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ),
            ],
          ),
          TextButton(
            onPressed: () async {
              NotificationService.unsubscribe();
              await SupabaseService.signOut();
              widget.onSignedOut();
            },
            child: const Text(
              'Salir',
              style: TextStyle(color: PagobyteColors.byteBlue, fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
      body: Stack(
        children: [
          tabs[_index],
          Positioned(
            left: 14,
            right: 14,
            bottom: 14,
            child: SafeArea(
              top: false,
              child: Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: PagobyteColors.ink,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  children: [
                    _navBtn(0, Icons.home_outlined, 'Inicio'),
                    _navBtn(1, Icons.shopping_bag_outlined, 'Tienda'),
                    _navBtn(2, Icons.receipt_long_outlined, 'Cuotas'),
                    _navBtn(3, Icons.person_outline, 'Perfil'),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _navBtn(int idx, IconData icon, String label) {
    final bool active = _index == idx;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _index = idx),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: active ? PagobyteColors.cyan : Colors.transparent,
            borderRadius: BorderRadius.circular(14),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                icon,
                size: 21,
                color: active ? PagobyteColors.ink : const Color(0xFFA9B3CE),
              ),
              const SizedBox(height: 2),
              Text(
                label,
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  color: active ? PagobyteColors.ink : const Color(0xFFA9B3CE),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
