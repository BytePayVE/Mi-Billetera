import 'package:flutter/material.dart';
import '../core/config.dart';
import '../core/theme.dart';
import '../widgets/ui_kit.dart';
import '../services/supabase_service.dart';

class InicioTab extends StatefulWidget {
  final Map<String, dynamic> myProfile;
  final double? tasaBcv;
  final ValueChanged<int> onNavigateTab;

  const InicioTab({
    super.key,
    required this.myProfile,
    required this.tasaBcv,
    required this.onNavigateTab,
  });

  @override
  State<InicioTab> createState() => _InicioTabState();
}

class _InicioTabState extends State<InicioTab> {
  late Future<Map<String, dynamic>> _future;

  @override
  void initState() {
    super.initState();
    _future = SupabaseService.fetchInicioData();
  }

  Future<void> _reload() async {
    setState(() => _future = SupabaseService.fetchInicioData());
  }

  @override
  Widget build(BuildContext context) {
    final firstName = ((widget.myProfile['nombre'] as String?) ?? '')
        .trim()
        .split(' ')
        .first;

    return RefreshIndicator(
      onRefresh: _reload,
      child: FutureBuilder<Map<String, dynamic>>(
        future: _future,
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const PagobyteSkeletonList(count: 3, showHero: true);
          }
          if (snap.hasError) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text(
                  'No se pudo cargar: ${snap.error}',
                  style: const TextStyle(color: PagobyteColors.bad),
                ),
              ),
            );
          }

          final data = snap.data!;
          final String frase = data['frase'] as String;
          final bool tieneOferta = data['tieneOferta'] as bool;
          final Map<String, dynamic>? proxima =
              data['proxima'] as Map<String, dynamic>?;

          return ListView(
            padding: const EdgeInsets.fromLTRB(18, 12, 18, 110),
            children: [
              // Hero oscuro tecnológico
              Container(
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                  color: PagobyteColors.ink,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      firstName.isNotEmpty ? 'Hola, $firstName' : 'Hola',
                      style: PagobyteTheme.heading(28, color: Colors.white),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      frase,
                      style: const TextStyle(
                        color: Color(0xFFC4CDE6),
                        fontSize: 15,
                        height: 1.4,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Builder(
                      builder: (_) {
                        final int faseNum = (widget.myProfile['fase'] as num?)?.toInt() ?? 1;
                        final double cupo = AppConfig.cupoReferencialPorFase(faseNum);
                        final int iniPct = (AppConfig.inicialPorcentajePorFase(faseNum) * 100).round();
                        return Container(
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.08),
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(color: PagobyteColors.cyan.withOpacity(0.35)),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Row(
                                    children: [
                                      Text(
                                        'CUPO REFERENCIAL PRE-APROBADO',
                                    style: TextStyle(
                                      color: PagobyteColors.cyan,
                                      fontSize: 10.5,
                                      fontWeight: FontWeight.w800,
                                      letterSpacing: 0.6,
                                    ),
                                  ),
                                  SizedBox(width: 5),
                                  PagobyteTooltip(
                                    message: 'Monto estimado según tu Fase actual. Sube de Fase pagando a tiempo o adelantando cuotas.',
                                    child: Icon(Icons.info_outline, size: 14, color: PagobyteColors.cyan),
                                  ),
                                ],
                              ),
                                  const SizedBox(height: 2),
                                  Text(
                                    'Hasta ${Formatters.usd(cupo)}',
                                    style: PagobyteTheme.mono(20, color: Colors.white),
                                  ),
                                ],
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                                decoration: BoxDecoration(
                                  color: PagobyteColors.cyan,
                                  borderRadius: BorderRadius.circular(999),
                                ),
                                child: Text(
                                  'Inicial $iniPct%',
                                  style: const TextStyle(
                                    color: PagobyteColors.ink,
                                    fontWeight: FontWeight.w800,
                                    fontSize: 12,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 14),

              // Banner de Oferta pendiente por aceptar
              if (tieneOferta) ...[
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: PagobyteColors.card,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: PagobyteColors.byteBlue, width: 1.8),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'TIENES UNA OFERTA',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w800,
                          color: PagobyteColors.byteBlue,
                        ),
                      ),
                      const SizedBox(height: 6),
                      const Text(
                        'Aprobamos tu solicitud. Revisa las condiciones y acepta tu compromiso para continuar.',
                      ),
                      const SizedBox(height: 12),
                      ElevatedButton(
                        onPressed: () => widget.onNavigateTab(2),
                        child: const Text('Ver mi oferta'),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 14),
              ],

              // Próximo pago o invitación a tienda
              if (proxima != null)
                _buildNextPaymentCard(proxima)
              else if (!tieneOferta)
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: PagobyteColors.card,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: PagobyteColors.line),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'TUS CUOTAS',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          color: PagobyteColors.muted,
                        ),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        'Todavía no tienes compras activas. Elige un producto y cuéntanos para qué lo necesitas: lo revisamos y te respondemos aquí.',
                      ),
                      const SizedBox(height: 14),
                      ElevatedButton(
                        onPressed: () => widget.onNavigateTab(1),
                        child: const Text('Ver la tienda'),
                      ),
                    ],
                  ),
                ),


              const SizedBox(height: 24),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: PagobyteColors.card,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: PagobyteColors.line),
                ),
                child: const Text(
                  'Pagobyte no está autorizado por la Superintendencia de Instituciones del Sector Bancario (SUDEBAN) para intermediar o fungir como pasarela de pagos entre clientes y comercios. Pagobyte es una plataforma tecnológica que facilita el acceso a compras a plazo en comercios aliados; los clientes abonan o depositan los pagos y cuotas directamente en las cuentas bancarias de los comercios.',
                  style: TextStyle(
                    color: PagobyteColors.muted,
                    fontSize: 11.5,
                    height: 1.45,
                  ),
                ),
              ),

              if (widget.tasaBcv != null) ...[
                const SizedBox(height: 14),
                Text(
                  'Tasa BCV de referencia: ${Formatters.bs(widget.tasaBcv!)} por dólar',
                  style: PagobyteTheme.mono(
                    12.5,
                    color: PagobyteColors.muted,
                    weight: FontWeight.w500,
                  ),
                ),
              ],
            ],
          );
        },
      ),
    );
  }

  Widget _buildNextPaymentCard(Map<String, dynamic> c) {
    final compra = c['compras'] as Map<String, dynamic>? ?? {};
    final producto = compra['productos'] as Map<String, dynamic>? ?? {};
    final int numero = (c['numero'] as num).toInt();
    final double montoUsd = (c['monto_usd'] as num).toDouble();
    final String? vence = c['fecha_vencimiento'] as String?;
    final double rec = compra['estado'] == 'activa'
        ? Formatters.calcularRecargoUsd(vence, montoUsd)
        : 0.0;
    final double total = Formatters.r2(montoUsd + rec);

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: PagobyteColors.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: PagobyteColors.line),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            numero == 0 ? 'TU INICIAL, LO PRIMERO' : 'TU PRÓXIMO PAGO',
            style: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: PagobyteColors.muted,
            ),
          ),
          const SizedBox(height: 6),
          Text(Formatters.usd(total), style: PagobyteTheme.mono(30)),
          const SizedBox(height: 6),
          Text(
            '${rec > 0 ? 'Incluye ${Formatters.usd(rec)} de recargo por atraso. ' : ''}'
            '${widget.tasaBcv != null ? 'Hoy equivale a ${Formatters.bs(total * widget.tasaBcv!)}. ' : ''}'
            '${numero == 0 ? 'Inicial' : 'Cuota $numero'} de ${producto['nombre'] ?? 'tu compra'}'
            '${numero == 0 ? '.' : ', vence el ${Formatters.diaCorto(vence)}.'}',
            style: const TextStyle(color: PagobyteColors.muted, fontSize: 13.5),
          ),
          const SizedBox(height: 14),
          ElevatedButton(
            onPressed: () => widget.onNavigateTab(2),
            child: const Text('Ver y reportar pago'),
          ),
        ],
      ),
    );
  }
}
