import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

abstract class PagobyteColors {
  static const Color ink = Color(0xFF0B1020);
  static const Color ink2 = Color(0xFF151C33);
  static const Color paper = Color(0xFFF3F5FA);
  static const Color card = Color(0xFFFFFFFF);
  static const Color line = Color(0xFFDCE1EE);
  static const Color muted = Color(0xFF55607A);

  static const Color byteBlue = Color(0xFF2447F5);
  static const Color byteBlueDark = Color(0xFF1B3AD1);
  static const Color cyan = Color(0xFF19D5FF);
  static const Color tint = Color(0xFFE6EBFA);

  static const Color ok = Color(0xFF0B7A5A);
  static const Color okBg = Color(0xFFDDF3EA);
  static const Color warn = Color(0xFF8A5A00);
  static const Color warnBg = Color(0xFFFFEBC7);
  static const Color bad = Color(0xFFB3261E);
  static const Color badBg = Color(0xFFFDE3E1);
}

class PagobyteTheme {
  static ThemeData build() {
    final base = ThemeData.light(useMaterial3: true);
    return base.copyWith(
      scaffoldBackgroundColor: PagobyteColors.paper,
      primaryColor: PagobyteColors.byteBlue,
      colorScheme: const ColorScheme.light(
        primary: PagobyteColors.byteBlue,
        secondary: PagobyteColors.cyan,
        surface: PagobyteColors.card,
        error: PagobyteColors.bad,
      ),
      textTheme: GoogleFonts.interTextTheme(base.textTheme).apply(
        bodyColor: PagobyteColors.ink,
        displayColor: PagobyteColors.ink,
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: PagobyteColors.card,
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: PagobyteColors.line, width: 1.5),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: PagobyteColors.byteBlue, width: 1.8),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: PagobyteColors.bad, width: 1.5),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: PagobyteColors.bad, width: 1.8),
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: PagobyteColors.byteBlue,
          foregroundColor: Colors.white,
          minimumSize: const Size(double.infinity, 48),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          textStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
          elevation: 0,
        ),
      ),
    );
  }

  static TextStyle heading(double size, {Color color = PagobyteColors.ink}) {
    return GoogleFonts.georama(
      fontSize: size,
      fontWeight: FontWeight.w700,
      color: color,
      height: 1.15,
    );
  }

  static TextStyle mono(double size, {Color color = PagobyteColors.ink, FontWeight weight = FontWeight.w700}) {
    return GoogleFonts.jetBrainsMono(
      fontSize: size,
      fontWeight: weight,
      color: color,
    );
  }
}
