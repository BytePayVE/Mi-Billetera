import 'dart:typed_data';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../core/config.dart';

class SupabaseService {
  static SupabaseClient get client => Supabase.instance.client;

  static User? get currentUser => client.auth.currentUser;

  static Future<void> signIn(String email, String password) async {
    await client.auth.signInWithPassword(
      email: email.trim(),
      password: password,
    );
  }

  static Future<AuthResponse> signUpClient({
    required String nombre,
    required String cedula,
    required String telefono,
    required String email,
    required String password,
  }) async {
    return await client.auth.signUp(
      email: email.trim(),
      password: password,
      data: {
        'nombre': nombre.trim(),
        'cedula': cedula.trim().toUpperCase(),
        'telefono': telefono.trim(),
        'terminos': AppConfig.terminosVersion,
      },
    );
  }


  static Future<void> sendPasswordResetOtp(String email) async {
    await client.auth.resetPasswordForEmail(email.trim());
  }

  static Future<void> verifyRecoveryOtpAndUpdatePassword({
    required String email,
    required String token,
    required String newPassword,
  }) async {
    await client.auth.verifyOTP(
      type: OtpType.recovery,
      email: email.trim(),
      token: token.trim(),
    );
    await client.auth.updateUser(
      UserAttributes(password: newPassword),
    );
  }

  static Future<void> signOut() async {
    await client.auth.signOut();
  }

  static Future<Map<String, dynamic>?> fetchMyBasicProfile() async {
    final user = currentUser;
    if (user == null) return null;
    return await client
        .from('clientes')
        .select('nombre, cedula, telefono')
        .eq('id', user.id)
        .maybeSingle();
  }

  static Future<double?> fetchLatestBcvRate() async {
    final res = await client
        .from('tasas_bcv')
        .select('tasa_bs')
        .order('fecha', ascending: false)
        .limit(1);
    if (res.isEmpty) return null;
    return (res.first['tasa_bs'] as num?)?.toDouble();
  }

  static Future<Map<String, dynamic>> fetchInicioData() async {
    final franja = Formatters.franjaCaracas();
    final results = await Future.wait([
      client.from('saludos').select('mensaje').eq('franja', franja),
      client
          .from('cuotas')
          .select('numero, monto_usd, fecha_vencimiento, compras!inner(estado, productos(nombre))')
          .inFilter('estado', ['pendiente', 'vencida'])
          .inFilter('compras.estado', ['esperando_inicial', 'activa'])
          .order('fecha_vencimiento')
          .limit(10),
      client.from('compras').select('id').eq('estado', 'por_aceptar'),
    ]);

    final saludos = List<Map<String, dynamic>>.from(results[0] as List);
    final cuotas = List<Map<String, dynamic>>.from(results[1] as List);
    final ofertas = List<Map<String, dynamic>>.from(results[2] as List);

    final String frase = saludos.isNotEmpty
        ? (saludos[DateTime.now().millisecond % saludos.length]['mensaje'] as String)
        : 'Qué gusto verte por aquí.';

    Map<String, dynamic>? proxima;
    for (final q in cuotas) {
      final compra = q['compras'] as Map<String, dynamic>?;
      if (compra?['estado'] == 'activa' || q['numero'] == 0) {
        proxima = q;
        break;
      }
    }

    return {
      'frase': frase,
      'proxima': proxima,
      'tieneOferta': ofertas.isNotEmpty,
    };
  }

  static Future<Map<String, dynamic>> fetchTiendaData() async {
    final results = await Future.wait([
      client
          .from('productos')
          .select('id, nombre, descripcion, categoria, precio_usd, stock')
          .order('nombre'),
      client
          .from('compras')
          .select('id')
          .inFilter('estado', ['por_aceptar', 'esperando_inicial', 'activa']),
      client.from('solicitudes').select('id').eq('estado', 'pendiente'),
    ]);

    final productos = List<Map<String, dynamic>>.from(results[0] as List);
    final comprasEnCurso = (results[1] as List).length;
    final solicitudesPend = (results[2] as List).length;

    return {
      'productos': productos,
      'bloqueado': (comprasEnCurso + solicitudesPend) > 0,
    };
  }

  static Future<Map<String, dynamic>> fetchCuotasData() async {
    final results = await Future.wait([
      client
          .from('compras')
          .select('id, total_usd, inicial_usd, numero_cuotas, cantidad, productos(nombre)')
          .eq('estado', 'por_aceptar'),
      client
          .from('solicitudes')
          .select('id, estado, nota_admin, cantidad, creada_en, productos(nombre)')
          .inFilter('estado', ['pendiente', 'rechazada'])
          .order('creada_en', ascending: false)
          .limit(5),
      client
          .from('compras')
          .select('id, estado, total_usd, productos(nombre), cuotas(id, numero, monto_usd, estado, fecha_vencimiento)')
          .inFilter('estado', ['esperando_inicial', 'activa', 'pagada'])
          .order('creado_en', ascending: false),
    ]);

    return {
      'ofertas': List<Map<String, dynamic>>.from(results[0] as List),
      'solicitudes': List<Map<String, dynamic>>.from(results[1] as List),
      'compras': List<Map<String, dynamic>>.from(results[2] as List),
    };
  }

  static Future<Map<String, dynamic>> fetchPerfilData() async {
    final user = currentUser;
    if (user == null) return {'cliente': null, 'fases': []};

    final results = await Future.wait([
      client
          .from('clientes')
          .select('nombre, cedula, telefono, correo, fase, puntos, creado_en, terminos_version, terminos_aceptados_en, fases(nombre, max_cuotas)')
          .eq('id', user.id)
          .maybeSingle(),
      client
          .from('fases')
          .select('fase, nombre, puntos_minimos')
          .order('fase'),
    ]);

    return {
      'cliente': results[0] as Map<String, dynamic>?,
      'fases': List<Map<String, dynamic>>.from(results[1] as List),
    };
  }

  static Future<void> solicitarProducto({
    required String productoId,
    required int cantidad,
    required String motivo,
  }) async {
    await client.rpc('solicitar_producto', params: {
      'p_producto_id': productoId,
      'p_cantidad': cantidad,
      'p_motivo': motivo.trim(),
    });
  }

  static Future<void> aceptarCompra(String compraId) async {
    await client.rpc('aceptar_compra', params: {
      'p_compra_id': compraId,
      'p_terminos': AppConfig.terminosVersion,
    });
  }

  static Future<void> reportarPago({
    required String cuotaId,
    required String metodo,
    required String referencia,
    required String telefono,
    required String cedula,
    required String fechaIso,
    required Uint8List imageBytes,
  }) async {
    final user = currentUser;
    if (user == null) throw Exception('Sesión expirada.');

    final path = '${user.id}/${DateTime.now().millisecondsSinceEpoch}.jpg';
    await client.storage.from('comprobantes').uploadBinary(
          path,
          imageBytes,
          fileOptions: const FileOptions(contentType: 'image/jpeg'),
        );

    String cleanCed = cedula.toUpperCase().replaceAll(RegExp(r'[^VE0-9]'), '');
    if (RegExp(r'^\d').hasMatch(cleanCed)) cleanCed = 'V$cleanCed';

    await client.rpc('reportar_pago', params: {
      'p_cuota_id': cuotaId,
      'p_metodo': metodo,
      'p_referencia': referencia.trim(),
      'p_telefono': telefono.replaceAll(RegExp(r'[^\d+]'), ''),
      'p_cedula': cleanCed,
      'p_fecha': fechaIso,
      'p_comprobante': path,
    });
  }
}
