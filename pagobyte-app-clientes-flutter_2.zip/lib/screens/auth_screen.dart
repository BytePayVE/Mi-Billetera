import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../core/terms_data.dart';
import '../core/theme.dart';
import '../services/supabase_service.dart';
import '../widgets/pagobyte_logo.dart';

class AuthScreen extends StatefulWidget {
  final VoidCallback onAuthenticated;

  const AuthScreen({super.key, required this.onAuthenticated});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  bool _isLogin = true;
  bool _loading = false;
  bool _emailSent = false;
  bool _acceptedTerms = false;
  String _tipoCedula = 'V';
  String? _errorMsg;

  final _emailLoginCtrl = TextEditingController();
  final _passLoginCtrl = TextEditingController();

  final _nombreCtrl = TextEditingController();
  final _numCedCtrl = TextEditingController();
  final _telCtrl = TextEditingController();
  final _emailRegCtrl = TextEditingController();
  final _passRegCtrl = TextEditingController();

  @override
  void dispose() {
    _emailLoginCtrl.dispose();
    _passLoginCtrl.dispose();
    _nombreCtrl.dispose();
    _numCedCtrl.dispose();
    _telCtrl.dispose();
    _emailRegCtrl.dispose();
    _passRegCtrl.dispose();
    super.dispose();
  }

  Future<void> _handleLogin() async {
    setState(() {
      _errorMsg = null;
      _loading = true;
    });
    try {
      await SupabaseService.signIn(_emailLoginCtrl.text, _passLoginCtrl.text);
      widget.onAuthenticated();
    } on AuthException catch (e) {
      setState(() {
        _errorMsg = e.message.toLowerCase().contains('confirm')
            ? 'Primero confirma tu correo con el enlace que te enviamos.'
            : 'Correo o contraseña incorrectos.';
      });
    } catch (_) {
      setState(() => _errorMsg = 'No se pudo iniciar sesión. Intenta de nuevo.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _handleSignUp() async {
    setState(() => _errorMsg = null);
    final cedula = '$_tipoCedula${_numCedCtrl.text.replaceAll(RegExp(r'\D'), '')}';
    final telefono = _telCtrl.text.replaceAll(RegExp(r'[^\d+]'), '');

    if (_nombreCtrl.text.trim().length < 3) {
      setState(() => _errorMsg = 'Ingresa tu nombre completo.');
      return;
    }
    if (!RegExp(r'^[VE]\d{6,9}$').hasMatch(cedula)) {
      setState(() => _errorMsg = 'Revisa tu cédula: deben ser de 6 a 9 números.');
      return;
    }
    if (!RegExp(r'^\+?\d{10,15}$').hasMatch(telefono)) {
      setState(() => _errorMsg = 'Revisa tu teléfono: deben ser de 10 a 15 números.');
      return;
    }
    if (_passRegCtrl.text.length < 8) {
      setState(() => _errorMsg = 'La contraseña debe tener mínimo 8 caracteres.');
      return;
    }
    if (!_acceptedTerms) {
      setState(() => _errorMsg = 'Debes aceptar los términos y condiciones.');
      return;
    }

    setState(() => _loading = true);
    try {
      final res = await SupabaseService.signUpClient(
        nombre: _nombreCtrl.text,
        cedula: cedula,
        telefono: telefono,
        email: _emailRegCtrl.text,
        password: _passRegCtrl.text,
      );
      if (res.session != null) {
        widget.onAuthenticated();
      } else {
        setState(() => _emailSent = true);
      }
    } on AuthException catch (e) {
      final m = e.message.toLowerCase();
      setState(() {
        if (m.contains('rate limit')) {
          _errorMsg = 'Se enviaron demasiados correos seguidos. Espera unos minutos.';
        } else if (m.contains('database error')) {
          _errorMsg = 'Esa cédula ya podría estar registrada o un dato es inválido.';
        } else if (m.contains('already')) {
          _errorMsg = 'Ese correo ya tiene una cuenta. Entra con tu contraseña.';
        } else {
          _errorMsg = 'No se pudo crear la cuenta. Intenta de nuevo.';
        }
      });
    } catch (_) {
      setState(() => _errorMsg = 'Error de conexión al registrar la cuenta.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: PagobyteColors.ink,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 34, 24, 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const PagobyteLogo(size: 50, darkSurface: true),
                  const SizedBox(height: 16),
                  const PagobyteWordmark(fontSize: 34, darkSurface: true),
                  const SizedBox(height: 6),
                  const Text(
                    'Tecnología en partes. Cuotas claras, a tu ritmo.',
                    style: TextStyle(color: Color(0xFFB9C3DE), fontSize: 15),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Container(
                width: double.infinity,
                decoration: const BoxDecoration(
                  color: PagobyteColors.paper,
                  borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
                ),
                child: SingleChildScrollView(
                  padding: const EdgeInsets.fromLTRB(22, 24, 22, 36),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Pestañas Entrar / Crear cuenta
                      Container(
                        padding: const EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          color: const Color(0xFFE5E9F4),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Row(
                          children: [
                            _tabButton('Entrar', _isLogin, () {
                              setState(() {
                                _isLogin = true;
                                _emailSent = false;
                                _errorMsg = null;
                              });
                            }),
                            _tabButton('Crear cuenta', !_isLogin, () {
                              setState(() {
                                _isLogin = false;
                                _emailSent = false;
                                _errorMsg = null;
                              });
                            }),
                          ],
                        ),
                      ),
                      const SizedBox(height: 18),
                      if (_emailSent) _buildEmailConfirmationCard()
                      else if (_isLogin) _buildLoginForm()
                      else _buildSignUpForm(),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _tabButton(String label, bool active, VoidCallback onTap) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: active ? Colors.white : Colors.transparent,
            borderRadius: BorderRadius.circular(9),
          ),
          child: Text(
            label,
            style: TextStyle(
              fontWeight: FontWeight.w700,
              color: active ? PagobyteColors.ink : PagobyteColors.muted,
            ),
          ),
        ),
      ),
    );
  }


  void _openPasswordRecoverySheet() {
    final emailCtrl = TextEditingController(text: _emailLoginCtrl.text.trim());
    final otpCtrl = TextEditingController();
    final newPassCtrl = TextEditingController();
    bool codeSent = false;
    bool busy = false;
    String? err;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: PagobyteColors.paper,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => StatefulBuilder(
        builder: (context, setModal) => Padding(
          padding: EdgeInsets.fromLTRB(
            20,
            20,
            20,
            MediaQuery.of(ctx).viewInsets.bottom + 24,
          ),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Recuperar contraseña', style: PagobyteTheme.heading(20)),
                const SizedBox(height: 6),
                Text(
                  codeSent
                      ? 'Ingresa el código de 6 dígitos que enviamos a tu correo y elige tu nueva contraseña.'
                      : 'Escribe el correo con el que te registraste y te enviaremos un código de 6 dígitos.',
                  style: const TextStyle(color: PagobyteColors.muted, fontSize: 13.5),
                ),
                const SizedBox(height: 14),
                TextField(
                  controller: emailCtrl,
                  enabled: !codeSent,
                  keyboardType: TextInputType.emailAddress,
                  decoration: const InputDecoration(labelText: 'Correo electrónico'),
                ),
                if (codeSent) ...[
                  const SizedBox(height: 10),
                  TextField(
                    controller: otpCtrl,
                    keyboardType: TextInputType.number,
                    maxLength: 6,
                    decoration: const InputDecoration(
                      labelText: 'Código de 6 dígitos',
                      counterText: '',
                    ),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: newPassCtrl,
                    obscureText: true,
                    decoration: const InputDecoration(
                      labelText: 'Nueva contraseña (mínimo 8 caracteres)',
                    ),
                  ),
                ],
                if (err != null) ...[
                  const SizedBox(height: 8),
                  Text(
                    err!,
                    style: const TextStyle(
                      color: PagobyteColors.bad,
                      fontWeight: FontWeight.w600,
                      fontSize: 13,
                    ),
                  ),
                ],
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: busy
                      ? null
                      : () async {
                          if (!codeSent) {
                            if (!emailCtrl.text.contains('@')) {
                              setModal(() => err = 'Ingresa un correo válido.');
                              return;
                            }
                            setModal(() {
                              busy = true;
                              err = null;
                            });
                            try {
                              await SupabaseService.sendPasswordResetOtp(emailCtrl.text);
                              setModal(() {
                                busy = false;
                                codeSent = true;
                              });
                            } catch (e) {
                              setModal(() {
                                busy = false;
                                err = 'No se pudo enviar el código: $e';
                              });
                            }
                          } else {
                            if (otpCtrl.text.trim().length < 6) {
                              setModal(() => err = 'Ingresa el código completo de 6 dígitos.');
                              return;
                            }
                            if (newPassCtrl.text.length < 8) {
                              setModal(() => err = 'La nueva contraseña debe tener mínimo 8 caracteres.');
                              return;
                            }
                            setModal(() {
                              busy = true;
                              err = null;
                            });
                            try {
                              await SupabaseService.verifyRecoveryOtpAndUpdatePassword(
                                email: emailCtrl.text,
                                token: otpCtrl.text,
                                newPassword: newPassCtrl.text,
                              );
                              if (ctx.mounted) Navigator.pop(ctx);
                              widget.onAuthenticated();
                            } catch (e) {
                              setModal(() {
                                busy = false;
                                err = 'Código inválido o expirado. Intenta de nuevo.';
                              });
                            }
                          }
                        },
                  child: Text(
                    busy
                        ? 'Procesando...'
                        : (codeSent ? 'Cambiar contraseña y entrar' : 'Enviar código al correo'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildLoginForm() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _fieldLabel('Correo'),
        TextField(
          controller: _emailLoginCtrl,
          keyboardType: TextInputType.emailAddress,
          decoration: const InputDecoration(hintText: 'tu@correo.com'),
        ),
        _fieldLabel('Contraseña'),
        TextField(
          controller: _passLoginCtrl,
          obscureText: true,
          decoration: const InputDecoration(hintText: '••••••••'),
        ),
        if (_errorMsg != null) _errorWidget(_errorMsg!),
        const SizedBox(height: 18),
        ElevatedButton(
          onPressed: _loading ? null : _handleLogin,
          child: Text(_loading ? 'Entrando...' : 'Entrar'),
        ),
        const SizedBox(height: 8),
        Center(
          child: TextButton(
            onPressed: _openPasswordRecoverySheet,
            child: const Text(
              '¿Olvidaste tu contraseña?',
              style: TextStyle(
                color: PagobyteColors.byteBlue,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSignUpForm() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _fieldLabel('Nombre completo'),
        TextField(
          controller: _nombreCtrl,
          textCapitalization: TextCapitalization.words,
          decoration: const InputDecoration(hintText: 'Nombre y apellido'),
        ),
        _fieldLabel('Cédula'),
        Row(
          children: [
            SizedBox(
              width: 78,
              child: DropdownButtonFormField<String>(
                value: _tipoCedula,
                items: const [
                  DropdownMenuItem(value: 'V', child: Text('V')),
                  DropdownMenuItem(value: 'E', child: Text('E')),
                ],
                onChanged: (v) {
                  if (v != null) setState(() => _tipoCedula = v);
                },
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: TextField(
                controller: _numCedCtrl,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(hintText: '12345678'),
              ),
            ),
          ],
        ),
        _fieldLabel('Teléfono de contacto'),
        TextField(
          controller: _telCtrl,
          keyboardType: TextInputType.phone,
          decoration: const InputDecoration(hintText: '04141234567'),
        ),
        _fieldLabel('Correo'),
        TextField(
          controller: _emailRegCtrl,
          keyboardType: TextInputType.emailAddress,
          decoration: const InputDecoration(hintText: 'tu@correo.com'),
        ),
        _fieldLabel('Contraseña (mínimo 8 caracteres)'),
        TextField(
          controller: _passRegCtrl,
          obscureText: true,
          decoration: const InputDecoration(hintText: '••••••••'),
        ),
        const SizedBox(height: 14),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: PagobyteColors.tint,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Checkbox(
                value: _acceptedTerms,
                activeColor: PagobyteColors.byteBlue,
                onChanged: (v) => setState(() => _acceptedTerms = v ?? false),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: Wrap(
                    children: [
                      const Text('Acepto los ', style: TextStyle(fontSize: 13.5)),
                      GestureDetector(
                        onTap: () => showTermsBottomSheet(context),
                        child: const Text(
                          'términos y condiciones',
                          style: TextStyle(
                            fontSize: 13.5,
                            color: PagobyteColors.byteBlue,
                            fontWeight: FontWeight.w700,
                            decoration: TextDecoration.underline,
                          ),
                        ),
                      ),
                      const Text(' de Pagobyte.', style: TextStyle(fontSize: 13.5)),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        if (_errorMsg != null) _errorWidget(_errorMsg!),
        const SizedBox(height: 16),
        ElevatedButton(
          onPressed: _loading ? null : _handleSignUp,
          child: Text(_loading ? 'Creando cuenta...' : 'Crear mi cuenta'),
        ),
        const SizedBox(height: 8),
        const Text(
          'Te enviaremos un correo para confirmar que eres tú.',
          style: TextStyle(color: PagobyteColors.muted, fontSize: 13),
        ),
      ],
    );
  }

  Widget _buildEmailConfirmationCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: PagobyteColors.tint,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Revisa tu correo', style: PagobyteTheme.heading(20)),
          const SizedBox(height: 8),
          const Text(
            'Te enviamos un enlace para confirmar tu cuenta. Después de confirmarla, vuelve aquí y entra con tu correo y contraseña.',
            style: TextStyle(fontSize: 14, height: 1.45),
          ),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: () => setState(() {
              _isLogin = true;
              _emailSent = false;
            }),
            child: const Text('Ir a Iniciar sesión'),
          ),
        ],
      ),
    );
  }

  Widget _fieldLabel(String text) {
    return Padding(
      padding: const EdgeInsets.only(top: 12, bottom: 6),
      child: Text(
        text,
        style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
      ),
    );
  }

  Widget _errorWidget(String msg) {
    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: Text(
        msg,
        style: const TextStyle(
          color: PagobyteColors.bad,
          fontSize: 13.5,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}
