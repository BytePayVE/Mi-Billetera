import 'package:flutter/material.dart';
import '../core/config.dart';
import '../core/theme.dart';
import '../services/supabase_service.dart';

class InicioTab extends StatefulWidget {
  final Map<String, dynamic> myProfile;
  final double? tasaBcv;
  final ValueChanged<int> onNavigateTab;

  const InicioTab({
    super.key,
    required this.myProfile,
    required this.tasaBcv,
    required this.onNavigateTab,
  });

  @override
  State<InicioTab> createState() => _InicioTabState();
}

class _InicioTabState extends State<InicioTab> {
  late Future<Map<String, dynamic>> _future;

  @override
  void initState() {
    super.initState();
    _future = SupabaseService.fetchInicioData();
  }

  Future<void> _reload() async {
    setState(() => _future = SupabaseService.fetchInicioData());
  }

  @override
  Widget build(BuildContext context) {
    final firstName = ((widget.myProfile['nombre'] as String?) ?? '')
        .trim()
        .split(' ')
        .first;

    return RefreshIndicator(
      onRefresh: _reload,
      child: FutureBuilder<Map<String, dynamic>>(
        future: _future,
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snap.hasError) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text(
                  'No se pudo cargar: ${snap.error}',
                  style: const TextStyle(color: PagobyteColors.bad),
                ),
              ),
            );
          }

          final data = snap.data!;
          final String frase = data['frase'] as String;
          final bool tieneOferta = data['tieneOferta'] as bool;
          final Map<String, dynamic>? proxima =
              data['proxima'] as Map<String, dynamic>?;

          return ListView(
            padding: const EdgeInsets.fromLTRB(18, 12, 18, 110),
            children: [
              // Hero oscuro tecnológico
              Container(
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                  color: PagobyteColors.ink,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      firstName.isNotEmpty ? 'Hola, $firstName' : 'Hola',
                      style: PagobyteTheme.heading(28, color: Colors.white),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      frase,
                      style: const TextStyle(
                        color: Color(0xFFC4CDE6),
                        fontSize: 15,
                        height: 1.4,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 14),

              // Banner de Oferta pendiente por aceptar
              if (tieneOferta) ...[
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: PagobyteColors.card,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: PagobyteColors.byteBlue, width: 1.8),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'TIENES UNA OFERTA',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w800,
                          color: PagobyteColors.byteBlue,
                        ),
                      ),
                      const SizedBox(height: 6),
                      const Text(
                        'Aprobamos tu solicitud. Revisa las condiciones y acepta tu compromiso para continuar.',
                      ),
                      const SizedBox(height: 12),
                      ElevatedButton(
                        onPressed: () => widget.onNavigateTab(2),
                        child: const Text('Ver mi oferta'),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 14),
              ],

              // Próximo pago o invitación a tienda
              if (proxima != null)
                _buildNextPaymentCard(proxima)
              else if (!tieneOferta)
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: PagobyteColors.card,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: PagobyteColors.line),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'TUS CUOTAS',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          color: PagobyteColors.muted,
                        ),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        'Todavía no tienes compras activas. Elige un producto y cuéntanos para qué lo necesitas: lo revisamos y te respondemos aquí.',
                      ),
                      const SizedBox(height: 14),
                      ElevatedButton(
                        onPressed: () => widget.onNavigateTab(1),
                        child: const Text('Ver la tienda'),
                      ),
                    ],
                  ),
                ),

              if (widget.tasaBcv != null) ...[
                const SizedBox(height: 14),
                Text(
                  'Tasa BCV de referencia: ${Formatters.bs(widget.tasaBcv!)} por dólar',
                  style: PagobyteTheme.mono(
                    12.5,
                    color: PagobyteColors.muted,
                    weight: FontWeight.w500,
                  ),
                ),
              ],
            ],
          );
        },
      ),
    );
  }

  Widget _buildNextPaymentCard(Map<String, dynamic> c) {
    final compra = c['compras'] as Map<String, dynamic>? ?? {};
    final producto = compra['productos'] as Map<String, dynamic>? ?? {};
    final int numero = (c['numero'] as num).toInt();
    final double montoUsd = (c['monto_usd'] as num).toDouble();
    final String? vence = c['fecha_vencimiento'] as String?;
    final double rec = compra['estado'] == 'activa'
        ? Formatters.calcularRecargoUsd(vence, montoUsd)
        : 0.0;
    final double total = Formatters.r2(montoUsd + rec);

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: PagobyteColors.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: PagobyteColors.line),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            numero == 0 ? 'TU INICIAL, LO PRIMERO' : 'TU PRÓXIMO PAGO',
            style: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: PagobyteColors.muted,
            ),
          ),
          const SizedBox(height: 6),
          Text(Formatters.usd(total), style: PagobyteTheme.mono(30)),
          const SizedBox(height: 6),
          Text(
            '${rec > 0 ? 'Incluye ${Formatters.usd(rec)} de recargo por atraso. ' : ''}'
            '${widget.tasaBcv != null ? 'Hoy equivale a ${Formatters.bs(total * widget.tasaBcv!)}. ' : ''}'
            '${numero == 0 ? 'Inicial' : 'Cuota $numero'} de ${producto['nombre'] ?? 'tu compra'}'
            '${numero == 0 ? '.' : ', vence el ${Formatters.diaCorto(vence)}.'}',
            style: const TextStyle(color: PagobyteColors.muted, fontSize: 13.5),
          ),
          const SizedBox(height: 14),
          ElevatedButton(
            onPressed: () => widget.onNavigateTab(2),
            child: const Text('Ver y reportar pago'),
          ),
        ],
      ),
    );
  }
}
