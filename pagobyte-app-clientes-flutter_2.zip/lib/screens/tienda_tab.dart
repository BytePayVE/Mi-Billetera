import 'package:flutter/material.dart';
import '../core/config.dart';
import '../core/theme.dart';
import '../services/supabase_service.dart';

class TiendaTab extends StatefulWidget {
  final ValueChanged<int> onNavigateTab;
  final ValueChanged<String> onShowNotice;

  const TiendaTab({
    super.key,
    required this.onNavigateTab,
    required this.onShowNotice,
  });

  @override
  State<TiendaTab> createState() => _TiendaTabState();
}

class _TiendaTabState extends State<TiendaTab> {
  late Future<Map<String, dynamic>> _future;

  @override
  void initState() {
    super.initState();
    _future = SupabaseService.fetchTiendaData();
  }

  Future<void> _reload() async {
    setState(() => _future = SupabaseService.fetchTiendaData());
  }

  void _openRequestSheet(Map<String, dynamic> p) {
    final int stock = (p['stock'] as num?)?.toInt() ?? 1;
    final int maxCant = stock < 5 ? stock : 5;
    int cantidad = 1;
    final motivoCtrl = TextEditingController();
    String? err;
    bool sending = false;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: PagobyteColors.paper,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => StatefulBuilder(
        builder: (context, setModal) => Padding(
          padding: EdgeInsets.fromLTRB(
            20,
            20,
            20,
            MediaQuery.of(ctx).viewInsets.bottom + 24,
          ),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(p['nombre'] ?? '', style: PagobyteTheme.heading(20)),
                const SizedBox(height: 4),
                Text(
                  '${p['descripcion'] ?? ''} Precio final: ${Formatters.usd(p['precio_usd'] ?? 0)}, sin intereses.',
                  style: const TextStyle(color: PagobyteColors.muted, fontSize: 13.5),
                ),
                const SizedBox(height: 14),
                const Text('Cantidad', style: TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 6),
                DropdownButtonFormField<int>(
                  value: cantidad,
                  items: List.generate(maxCant, (i) => i + 1)
                      .map((n) => DropdownMenuItem(value: n, child: Text('$n')))
                      .toList(),
                  onChanged: (v) {
                    if (v != null) setModal(() => cantidad = v);
                  },
                ),
                const SizedBox(height: 14),
                const Text('¿Para qué lo necesitas?', style: TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 6),
                TextField(
                  controller: motivoCtrl,
                  maxLines: 3,
                  onChanged: (_) => setModal(() {}),
                  decoration: const InputDecoration(
                    hintText: 'Cuéntanos con tus palabras para qué lo vas a usar y por qué lo necesitas ahora.',
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  motivoCtrl.text.trim().length < 20
                      ? 'Te faltan ${20 - motivoCtrl.text.trim().length} letras (mínimo 20).'
                      : 'Listo.',
                  style: const TextStyle(color: PagobyteColors.muted, fontSize: 12.5),
                ),
                if (err != null) ...[
                  const SizedBox(height: 8),
                  Text(err!, style: const TextStyle(color: PagobyteColors.bad, fontWeight: FontWeight.w600)),
                ],
                const SizedBox(height: 14),
                ElevatedButton(
                  onPressed: sending
                      ? null
                      : () async {
                          if (motivoCtrl.text.trim().length < 20) {
                            setModal(() => err = 'Escribe al menos 20 caracteres en el motivo.');
                            return;
                          }
                          setModal(() {
                            sending = true;
                            err = null;
                          });
                          try {
                            await SupabaseService.solicitarProducto(
                              productoId: p['id'] as String,
                              cantidad: cantidad,
                              motivo: motivoCtrl.text,
                            );
                            if (ctx.mounted) Navigator.pop(ctx);
                            widget.onShowNotice('Recibimos tu solicitud. La revisaremos pronto.');
                            widget.onNavigateTab(2);
                          } catch (e) {
                            setModal(() {
                              sending = false;
                              err = e.toString();
                            });
                          }
                        },
                  child: Text(sending ? 'Enviando...' : 'Enviar solicitud'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: _reload,
      child: FutureBuilder<Map<String, dynamic>>(
        future: _future,
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snap.hasError) {
            return Center(child: Text('Error: ${snap.error}'));
          }

          final productos = List<Map<String, dynamic>>.from(snap.data!['productos']);
          final bool bloqueado = snap.data!['bloqueado'] as bool;

          if (productos.isEmpty) {
            return const Center(child: Text('Pronto tendremos productos para ti.'));
          }

          return ListView(
            padding: const EdgeInsets.fromLTRB(18, 12, 18, 110),
            children: [
              if (bloqueado)
                Container(
                  margin: const EdgeInsets.only(bottom: 14),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: PagobyteColors.card,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: PagobyteColors.byteBlue, width: 1.5),
                  ),
                  child: const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'YA TIENES ALGO EN CURSO',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w800,
                          color: PagobyteColors.byteBlue,
                        ),
                      ),
                      SizedBox(height: 6),
                      Text(
                        'Puedes tener una solicitud o una compra a la vez. Podrás pedir otro producto cuando termines de pagar el actual.',
                      ),
                    ],
                  ),
                )
              else
                const Padding(
                  padding: EdgeInsets.only(bottom: 12),
                  child: Text(
                    'Elige lo que necesitas y cuéntanos para qué. Revisamos cada solicitud antes de aprobarla.',
                    style: TextStyle(color: PagobyteColors.muted, fontSize: 13.5),
                  ),
                ),
              ...productos.map((p) {
                final int stock = (p['stock'] as num?)?.toInt() ?? 0;
                return Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: PagobyteColors.card,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: PagobyteColors.line),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Text(
                              p['nombre'] ?? '',
                              style: PagobyteTheme.heading(16),
                            ),
                          ),
                          Text(
                            Formatters.usd(p['precio_usd'] ?? 0),
                            style: PagobyteTheme.mono(16, color: PagobyteColors.byteBlue),
                          ),
                        ],
                      ),
                      if ((p['descripcion'] ?? '').toString().isNotEmpty) ...[
                        const SizedBox(height: 6),
                        Text(
                          p['descripcion'],
                          style: const TextStyle(color: PagobyteColors.muted, fontSize: 13.5),
                        ),
                      ],
                      const SizedBox(height: 6),
                      const Text(
                        'Precio final, sin intereses. Se paga en cuotas, con la inicial primero.',
                        style: TextStyle(color: PagobyteColors.muted, fontSize: 12.5),
                      ),
                      if (stock <= 0) ...[
                        const SizedBox(height: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                          decoration: BoxDecoration(
                            color: PagobyteColors.badBg,
                            borderRadius: BorderRadius.circular(999),
                          ),
                          child: const Text(
                            'Agotado',
                            style: TextStyle(
                              color: PagobyteColors.bad,
                              fontWeight: FontWeight.w700,
                              fontSize: 12,
                            ),
                          ),
                        ),
                      ] else if (!bloqueado) ...[
                        const SizedBox(height: 12),
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: PagobyteColors.tint,
                            foregroundColor: PagobyteColors.byteBlue,
                          ),
                          onPressed: () => _openRequestSheet(p),
                          child: const Text('Solicitar este producto'),
                        ),
                      ],
                    ],
                  ),
                );
              }),
            ],
          );
        },
      ),
    );
  }
}
