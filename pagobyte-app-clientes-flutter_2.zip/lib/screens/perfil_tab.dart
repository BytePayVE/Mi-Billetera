import 'package:flutter/material.dart';
import '../core/config.dart';
import '../core/terms_data.dart';
import '../core/theme.dart';
import '../services/supabase_service.dart';

class PerfilTab extends StatefulWidget {
  const PerfilTab({super.key});

  @override
  State<PerfilTab> createState() => _PerfilTabState();
}

class _PerfilTabState extends State<PerfilTab> {
  late Future<Map<String, dynamic>> _future;

  @override
  void initState() {
    super.initState();
    _future = SupabaseService.fetchPerfilData();
  }

  Future<void> _reload() async {
    setState(() => _future = SupabaseService.fetchPerfilData());
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: _reload,
      child: FutureBuilder<Map<String, dynamic>>(
        future: _future,
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snap.hasError) {
            return Center(child: Text('Error: ${snap.error}'));
          }

          final c = snap.data!['cliente'] as Map<String, dynamic>?;
          final fases = List<Map<String, dynamic>>.from(snap.data!['fases'] ?? []);
          if (c == null) {
            return const Center(child: Text('Esta cuenta no tiene perfil de cliente.'));
          }

          final int faseActual = (c['fase'] as num?)?.toInt() ?? 1;
          final int puntos = (c['puntos'] as num?)?.toInt() ?? 0;
          final faseInfo = c['fases'] as Map<String, dynamic>?;
          final String faseNombre = (faseInfo?['nombre'] as String?) ?? 'Bit';
          final int maxCuotas = (faseInfo?['max_cuotas'] as num?)?.toInt() ?? 3;

          Map<String, dynamic>? sigFase;
          for (final f in fases) {
            if ((f['fase'] as num).toInt() == faseActual + 1) {
              sigFase = f;
              break;
            }
          }

          String metaTxt;
          if (sigFase == null) {
            metaTxt = 'Estás en la fase más alta.';
          } else {
            final int minPts = (sigFase['puntos_minimos'] as num).toInt();
            metaTxt = puntos >= minPts
                ? 'Ya cumples los puntos para la fase ${sigFase['nombre']}. Pagobyte te la confirmará.'
                : 'Te faltan ${minPts - puntos} puntos para la fase ${sigFase['nombre']}.';
          }

          return ListView(
            padding: const EdgeInsets.fromLTRB(18, 12, 18, 110),
            children: [
              Container(
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                  color: PagobyteColors.ink,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      c['nombre'] ?? '',
                      style: PagobyteTheme.heading(24, color: Colors.white),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Fase $faseActual, $faseNombre: puedes pagar hasta en $maxCuotas cuotas. $metaTxt',
                      style: const TextStyle(color: Color(0xFFC4CDE6), fontSize: 14, height: 1.4),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 14),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: PagobyteColors.card,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: PagobyteColors.line),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _lockedRow('Nombre completo', c['nombre'] ?? ''),
                    _lockedRow('Cédula', c['cedula'] ?? ''),
                    _lockedRow('Teléfono', c['telefono'] ?? ''),
                    _lockedRow('Correo', c['correo'] ?? ''),
                    _lockedRow('Puntos acumulados', '$puntos pts', showLock: false),
                    _lockedRow('Cliente desde', Formatters.fechaLarga(c['creado_en'] as String?), showLock: false),
                    _lockedRow(
                      'Términos aceptados',
                      c['terminos_version'] != null
                          ? '${c['terminos_version']} (${Formatters.fechaLarga(c['terminos_aceptados_en'] as String?)})'
                          : 'Sin registro',
                      showLock: false,
                      isLast: true,
                    ),
                    const SizedBox(height: 10),
                    const Text(
                      'Tu nombre, cédula, teléfono y correo no se pueden cambiar. Son la única forma en que validamos tu identidad y te contactamos. Si hay un error, escríbenos.',
                      style: TextStyle(color: PagobyteColors.muted, fontSize: 12.5),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 14),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: PagobyteColors.tint,
                  foregroundColor: PagobyteColors.byteBlue,
                ),
                onPressed: () => showTermsBottomSheet(context),
                child: const Text('Leer los términos y condiciones'),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _lockedRow(String label, String value, {bool showLock = true, bool isLast = false}) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(
        border: isLast ? null : const Border(bottom: BorderSide(color: PagobyteColors.line)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: PagobyteColors.muted, fontSize: 13)),
          const SizedBox(width: 12),
          Expanded(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Flexible(
                  child: Text(
                    value,
                    textAlign: TextAlign.right,
                    style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
                  ),
                ),
                if (showLock) ...[
                  const SizedBox(width: 6),
                  const Icon(Icons.lock_outline, size: 15, color: PagobyteColors.muted),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}
