import 'package:flutter/material.dart';
import '../core/theme.dart';
import '../services/supabase_service.dart';
import '../widgets/pagobyte_logo.dart';
import 'cuotas_tab.dart';
import 'inicio_tab.dart';
import 'perfil_tab.dart';
import 'tienda_tab.dart';

class HomeShell extends StatefulWidget {
  final VoidCallback onSignedOut;

  const HomeShell({super.key, required this.onSignedOut});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;
  bool _loading = true;
  Map<String, dynamic> _profile = {};
  double? _tasaBcv;

  @override
  void initState() {
    super.initState();
    _bootstrap();
  }

  Future<void> _bootstrap() async {
    try {
      final results = await Future.wait([
        SupabaseService.fetchMyBasicProfile(),
        SupabaseService.fetchLatestBcvRate(),
      ]);
      if (mounted) {
        setState(() {
          _profile = (results[0] as Map<String, dynamic>?) ?? {};
          _tasaBcv = results[1] as double?;
          _loading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _showNotice(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: PagobyteColors.ink,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    final tabs = [
      InicioTab(
        myProfile: _profile,
        tasaBcv: _tasaBcv,
        onNavigateTab: (i) => setState(() => _index = i),
      ),
      TiendaTab(
        onNavigateTab: (i) => setState(() => _index = i),
        onShowNotice: _showNotice,
      ),
      CuotasTab(
        myProfile: _profile,
        tasaBcv: _tasaBcv,
        onShowNotice: _showNotice,
      ),
      const PerfilTab(),
    ];

    return Scaffold(
      appBar: AppBar(
        backgroundColor: PagobyteColors.paper,
        elevation: 0,
        title: const Row(
          children: [
            PagobyteLogo(size: 26),
            SizedBox(width: 8),
            PagobyteWordmark(fontSize: 20),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () async {
              await SupabaseService.signOut();
              widget.onSignedOut();
            },
            child: const Text(
              'Salir',
              style: TextStyle(color: PagobyteColors.byteBlue, fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
      body: Stack(
        children: [
          tabs[_index],
          // Barra flotante inferior idéntica a la identidad de cliente.css
          Positioned(
            left: 14,
            right: 14,
            bottom: 14,
            child: SafeArea(
              top: false,
              child: Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: PagobyteColors.ink,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  children: [
                    _navBtn(0, Icons.home_outlined, 'Inicio'),
                    _navBtn(1, Icons.shopping_bag_outlined, 'Tienda'),
                    _navBtn(2, Icons.receipt_long_outlined, 'Cuotas'),
                    _navBtn(3, Icons.person_outline, 'Perfil'),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _navBtn(int idx, IconData icon, String label) {
    final bool active = _index == idx;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _index = idx),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: active ? PagobyteColors.cyan : Colors.transparent,
            borderRadius: BorderRadius.circular(14),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                icon,
                size: 21,
                color: active ? PagobyteColors.ink : const Color(0xFFA9B3CE),
              ),
              const SizedBox(height: 2),
              Text(
                label,
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  color: active ? PagobyteColors.ink : const Color(0xFFA9B3CE),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
