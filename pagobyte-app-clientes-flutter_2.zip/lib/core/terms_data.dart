import 'package:flutter/material.dart';
import 'config.dart';
import 'theme.dart';

class TermSection {
  final String title;
  final List<String> paragraphs;

  const TermSection(this.title, this.paragraphs);
}

const List<TermSection> kPagobyteTerms = [
  TermSection('Qué es Pagobyte', [
    'Pagobyte te permite solicitar productos de tecnología y pagarlos en partes: primero una inicial y luego cuotas. Al crear tu cuenta y usar la app aceptas estos términos.'
  ]),
  TermSection('Tu identidad y tus datos', [
    'Tu nombre, cédula, teléfono y correo son tu identificación en Pagobyte. Deben ser verdaderos y no se pueden cambiar desde la app: son la única forma en que validamos que eres tú y la única vía por la que te contactaremos. Si cometiste un error al registrarte, escríbenos.',
    'Usamos tus datos solo para identificarte, contactarte y verificar tus pagos. No los vendemos. Dar datos falsos o usar los de otra persona puede llevar a cancelar tu cuenta y tus compras, y a las acciones legales que correspondan.'
  ]),
  TermSection('Una solicitud a la vez', [
    'Pedir un producto no te garantiza recibirlo: Pagobyte revisa cada solicitud y puede aprobarla o no. Puedes tener una sola solicitud o compra en curso. Podrás pedir otro producto cuando termines de pagar el anterior.'
  ]),
  TermSection('Tu fase y tus puntos', [
    'La cantidad de cuotas que puedes elegir depende de tu fase: Bit (3 cuotas), Byte (hasta 4), Kilo (hasta 5), Mega (hasta 6) y Giga (hasta 9, según el producto).',
    'Cada pago verificado suma puntos: pagar a tiempo suma, y adelantar una cuota suma más. Un pago con recargo no suma. Con suficientes puntos Pagobyte puede subirte de fase, pero la decisión final es de Pagobyte.'
  ]),
  TermSection('Precios y cero intereses', [
    'Los precios están en dólares. El precio que ves es el precio final de venta: no cobramos intereses sobre las cuotas. El total y el monto de cada cuota no cambian después de aceptar la oferta. Los recargos por atraso se explican en el punto 10.'
  ]),
  TermSection('Tu compromiso de pago', [
    'Al aceptar una oferta te comprometes a pagar la inicial y todas las cuotas en las fechas indicadas. La inicial es lo primero: hasta que la verifiquemos, no se activan las cuotas ni se entrega el producto. Las cuotas empiezan a contar cuando verificamos tu inicial y vencen cada 15 días.'
  ]),
  TermSection('Adelantar cuotas', [
    'Puedes pagar una cuota antes de su fecha cuando quieras. Es decisión tuya, no tiene costo y suma puntos a tu favor.'
  ]),
  TermSection('Pagos en bolívares', [
    'Puedes pagar en bolívares. El monto se calcula con la tasa oficial del BCV más reciente registrada en la app cuando reportas el pago. Debes pagar el monto exacto que te muestra la app.'
  ]),
  TermSection('Cómo reportar y verificar un pago', [
    'Reporta cada pago con el método, el número de referencia, el teléfono desde el que pagaste, la cédula del titular, la fecha y una foto clara del comprobante. Pagobyte verifica que el dinero llegó antes de marcarlo como pagado. Un pago con datos falsos, con una referencia repetida o que no llegó será rechazado y la cuota seguirá pendiente.'
  ]),
  TermSection('Si te atrasas: recargos y consecuencias', [
    '1. Recargo. Si pasan 2 días desde el vencimiento de una cuota sin que pagues, se suma un recargo de \$5 a esa cuota. Si pasa una semana más sin pagar, el recargo sube otros \$5, y así cada semana, hasta un máximo igual al monto de la cuota.',
    '2. Contacto. El servicio de atención al cliente de Pagobyte te contactará por distintas vías, como llamadas, mensajes y correo, usando los datos con los que te registraste.',
    '3. Restricciones. Mientras tengas cuotas vencidas no puedes pedir nuevos productos, y Pagobyte puede bajar tu fase.',
    '4. Saldo completo. Si una cuota lleva más de 15 días vencida sin que hayamos acordado una solución, Pagobyte puede dar por vencido el plazo de las cuotas restantes y exigir el pago completo de lo que debas.',
    '5. Cobro. Si no pagas, Pagobyte puede reclamar lo adeudado por las vías legales que correspondan, incluidos el cobro extrajudicial y judicial.',
    'Si tienes un problema para pagar, avísanos antes del vencimiento. Preferimos buscar una solución contigo.'
  ]),
  TermSection('Entrega', [
    'El producto se entrega después de verificar tu inicial, por el medio que acordemos contigo.'
  ]),
  TermSection('La compra es definitiva', [
    'Una vez verificada tu inicial, la compra es definitiva e irrevocable y la inicial no se devuelve. Esto no afecta los derechos que la ley te reconoce si el producto llega con defectos.'
  ]),
  TermSection('Antes de la inicial', [
    'Puedes decidir no aceptar una oferta. Después de aceptarla, solo puedes echarte para atrás antes de que verifiquemos tu inicial, escribiéndonos.'
  ]),
  TermSection('Cambios y ley aplicable', [
    'Podemos actualizar estos términos. Si cambian, te lo mostraremos y te pediremos aceptar la nueva versión para nuevas compras. Estos términos se rigen por las leyes de la República Bolivariana de Venezuela.'
  ]),
];

void showTermsBottomSheet(BuildContext context) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: PagobyteColors.paper,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
    builder: (ctx) => DraggableScrollableSheet(
      initialChildSize: 0.85,
      minChildSize: 0.5,
      maxChildSize: 0.95,
      expand: false,
      builder: (_, scrollCtrl) => Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 18, 12, 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Términos y condiciones', style: PagobyteTheme.heading(20)),
                    Text(
                      'Versión ${AppConfig.terminosVersion}',
                      style: const TextStyle(color: PagobyteColors.muted, fontSize: 12),
                    ),
                  ],
                ),
                TextButton(
                  onPressed: () => Navigator.pop(ctx),
                  child: const Text('Cerrar', style: TextStyle(fontWeight: FontWeight.w700)),
                ),
              ],
            ),
          ),
          const Divider(height: 1, color: PagobyteColors.line),
          Expanded(
            child: ListView.builder(
              controller: scrollCtrl,
              padding: const EdgeInsets.all(20),
              itemCount: kPagobyteTerms.length,
              itemBuilder: (_, idx) {
                final sec = kPagobyteTerms[idx];
                return Padding(
                  padding: const EdgeInsets.only(bottom: 16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${idx + 1}. ${sec.title}',
                        style: PagobyteTheme.heading(15, color: PagobyteColors.byteBlue),
                      ),
                      const SizedBox(height: 4),
                      ...sec.paragraphs.map(
                        (p) => Padding(
                          padding: const EdgeInsets.only(top: 4),
                          child: Text(p, style: const TextStyle(fontSize: 13.5, height: 1.45)),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    ),
  );
}
