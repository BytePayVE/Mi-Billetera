import 'package:intl/intl.dart';

abstract class AppConfig {
  static const String supabaseUrl = 'https://huqyycvdakrlfvqugvvp.supabase.co';
  static const String supabaseAnonKey =
      'sb_publishable_V8aa6DTypFBmJB6mrajhOw_j732ro87';

  // Reglas de recargo sincronizadas con recargo_usd en Supabase
  static const double recargoBaseUsd = 5.0;
  static const double recargoSemanalUsd = 5.0;
  static const int diasGracia = 2;

  static const String terminosVersion = 'v3-2026-11';
}

class Formatters {
  static final NumberFormat _numFmt = NumberFormat('#,##0.00', 'es_VE');

  static double r2(num n) => (n * 100).roundToDouble() / 100.0;

  static String usd(num n) => '\$${_numFmt.format(n)}';

  static String bs(num n) => 'Bs ${_numFmt.format(n)}';

  static String diaCorto(String? isoDate) {
    if (isoDate == null || isoDate.isEmpty) return 'Por definir';
    try {
      final dt = DateTime.parse(isoDate);
      const meses = [
        'enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio',
        'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'
      ];
      return '${dt.day} de ${meses[dt.month - 1]}';
    } catch (_) {
      return isoDate;
    }
  }

  static String fechaLarga(String? isoTimestamp) {
    if (isoTimestamp == null || isoTimestamp.isEmpty) return 'Sin registro';
    try {
      final dt = DateTime.parse(isoTimestamp).toLocal();
      const meses = [
        'enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio',
        'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'
      ];
      return '${dt.day} de ${meses[dt.month - 1]} de ${dt.year}';
    } catch (_) {
      return isoTimestamp;
    }
  }

  static String hoyIsoCaracas() {
    final caracas = DateTime.now().toUtc().subtract(const Duration(hours: 4));
    final y = caracas.year.toString().padLeft(4, '0');
    final m = caracas.month.toString().padLeft(2, '0');
    final d = caracas.day.toString().padLeft(2, '0');
    return '$y-$m-$d';
  }

  static String franjaCaracas() {
    final caracas = DateTime.now().toUtc().subtract(const Duration(hours: 4));
    if (caracas.hour < 12) return 'manana';
    if (caracas.hour < 19) return 'tarde';
    return 'noche';
  }

  static double calcularRecargoUsd(String? fechaVencimiento, double montoUsd) {
    if (fechaVencimiento == null || fechaVencimiento.isEmpty) return 0.0;
    try {
      final hoyDt = DateTime.parse(hoyIsoCaracas());
      final venceDt = DateTime.parse(fechaVencimiento);
      final diasAtraso = hoyDt.difference(venceDt).inDays;
      if (diasAtraso < AppConfig.diasGracia) return 0.0;
      final semanasExtra = ((diasAtraso - AppConfig.diasGracia) / 7).floor();
      final calculado = r2(
        AppConfig.recargoBaseUsd + (AppConfig.recargoSemanalUsd * semanasExtra),
      );
      return calculado > montoUsd ? montoUsd : calculado;
    } catch (_) {
      return 0.0;
    }
  }
}
