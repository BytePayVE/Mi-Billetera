import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'core/config.dart';
import 'core/theme.dart';
import 'screens/auth_screen.dart';
import 'screens/home_shell.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(
    url: AppConfig.supabaseUrl,
    anonKey: AppConfig.supabaseAnonKey,
  );
  runApp(const PagobyteClientesApp());
}

class PagobyteClientesApp extends StatefulWidget {
  const PagobyteClientesApp({super.key});

  @override
  State<PagobyteClientesApp> createState() => _PagobyteClientesAppState();
}

class _PagobyteClientesAppState extends State<PagobyteClientesApp> {
  bool _hasSession = Supabase.instance.client.auth.currentSession != null;

  @override
  void initState() {
    super.initState();
    Supabase.instance.client.auth.onAuthStateChange.listen((data) {
      if (mounted) {
        setState(() => _hasSession = data.session != null);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pagobyte',
      debugShowCheckedModeBanner: false,
      theme: PagobyteTheme.build(),
      home: _hasSession
          ? HomeShell(onSignedOut: () => setState(() => _hasSession = false))
          : AuthScreen(onAuthenticated: () => setState(() => _hasSession = true)),
    );
  }
}
