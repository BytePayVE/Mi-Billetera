import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class NotificationService {
  static final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();
  static RealtimeChannel? _channel;
  static bool _initialized = false;

  static const String _channelId = 'pagobyte_push_v2';
  static const String _channelName = 'Mensajes y Alertas Pagobyte';
  static const String _channelDesc =
      'Notificaciones emergentes de pagos, ofertas y avisos de Pagobyte';
  static const String _lastNotifKey = 'pagobyte_last_pushed_notif_id';

  static Future<void> init() async {
    if (_initialized) return;
    if (kIsWeb) {
      _initialized = true;
      return;
    }

    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const settings = InitializationSettings(android: androidInit);
    await _plugin.initialize(settings);

    // Crear canal de máxima prioridad para que aparezca como banner emergente (estilo WhatsApp)
    final androidImpl = _plugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>();

    if (androidImpl != null) {
      const channel = AndroidNotificationChannel(
        _channelId,
        _channelName,
        description: _channelDesc,
        importance: Importance.max,
        playSound: true,
        enableVibration: true,
        showBadge: true,
      );
      await androidImpl.createNotificationChannel(channel);
      try {
        await androidImpl.requestNotificationsPermission();
      } catch (_) {}
    }

    try {
      final status = await Permission.notification.status;
      if (status.isDenied) {
        await Permission.notification.request();
      }
    } catch (_) {}

    _initialized = true;
  }

  static Future<void> showLocal({
    required int id,
    required String title,
    required String body,
  }) async {
    if (kIsWeb) return;
    final androidDetails = AndroidNotificationDetails(
      _channelId,
      _channelName,
      channelDescription: _channelDesc,
      importance: Importance.max,
      priority: Priority.max,
      playSound: true,
      enableVibration: true,
      visibility: NotificationVisibility.public,
      category: AndroidNotificationCategory.message,
      ticker: 'Pagobyte',
      styleInformation: BigTextStyleInformation(
        body,
        contentTitle: title,
        summaryText: 'Pagobyte',
      ),
    );
    final details = NotificationDetails(android: androidDetails);
    await _plugin.show(id, title, body, details);
  }

  static Future<void> _saveLastPushedId(String id) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_lastNotifKey, id);
    } catch (_) {}
  }

  static Future<String?> _getLastPushedId() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getString(_lastNotifKey);
    } catch (_) {
      return null;
    }
  }

  /// Revisa si llegaron notificaciones nuevas mientras la app estaba en pausa y las lanza en la barra del teléfono
  static Future<void> notifyLatestUnreadIfNeeded(
      List<Map<String, dynamic>> notifs) async {
    if (kIsWeb || notifs.isEmpty) return;
    final unreadList = notifs.where((n) => n['leida'] != true).toList();
    if (unreadList.isEmpty) return;

    final latest = unreadList.first;
    final latestId = (latest['id'] ?? '').toString();
    if (latestId.isEmpty) return;

    final lastPushed = await _getLastPushedId();
    if (lastPushed == latestId) return;

    await _saveLastPushedId(latestId);
    await showLocal(
      id: DateTime.now().millisecondsSinceEpoch.remainder(100000),
      title: (latest['titulo'] ?? 'Pagobyte').toString(),
      body: (latest['mensaje'] ?? '').toString(),
    );
  }

  static void subscribeToSupabaseNotifications({
    required String userId,
    required void Function(Map<String, dynamic> notif) onNewNotification,
  }) {
    unsubscribe();
    final client = Supabase.instance.client;
    _channel = client
        .channel('notificaciones_cliente_$userId')
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'notificaciones',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'cliente_id',
            value: userId,
          ),
          callback: (payload) async {
            final record = payload.newRecord;
            if (record.isEmpty) return;
            final recordId = (record['id'] ?? '').toString();
            if (recordId.isNotEmpty) {
              await _saveLastPushedId(recordId);
            }
            final title = (record['titulo'] ?? 'Pagobyte').toString();
            final body = (record['mensaje'] ?? '').toString();
            await showLocal(
              id: DateTime.now().millisecondsSinceEpoch.remainder(100000),
              title: title,
              body: body,
            );
            onNewNotification(record);
          },
        )
        .subscribe();
  }

  static void unsubscribe() {
    if (_channel != null) {
      Supabase.instance.client.removeChannel(_channel!);
      _channel = null;
    }
  }

  static Future<List<Map<String, dynamic>>> fetchMyNotifications() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) return [];
    try {
      final res = await Supabase.instance.client
          .from('notificaciones')
          .select('*')
          .eq('cliente_id', user.id)
          .order('creada_en', ascending: false)
          .limit(30);
      return List<Map<String, dynamic>>.from(res as List);
    } catch (_) {
      return [];
    }
  }

  static Future<void> markAllAsRead() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) return;
    try {
      await Supabase.instance.client
          .from('notificaciones')
          .update({'leida': true})
          .eq('cliente_id', user.id)
          .eq('leida', false);
    } catch (_) {}
  }
}
