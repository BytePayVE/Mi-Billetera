import 'package:flutter/material.dart';
import '../core/config.dart';
import '../core/theme.dart';

class CalculatorScreen extends StatefulWidget {
  final int fase;
  final int maxCuotas;
  final double? tasaBcv;

  const CalculatorScreen({
    super.key,
    required this.fase,
    required this.maxCuotas,
    required this.tasaBcv,
  });

  @override
  State<CalculatorScreen> createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen> {
  final _montoCtrl = TextEditingController(text: '10.00');
  late int _cuotasSeleccionadas;

  @override
  void initState() {
    super.initState();
    _cuotasSeleccionadas = widget.maxCuotas >= 3 ? 3 : widget.maxCuotas;
  }

  @override
  void dispose() {
    _montoCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final raw = double.tryParse(_montoCtrl.text.replaceAll(',', '.')) ?? 0.0;
    final double monto = raw < 0 ? 0.0 : raw;
    final double iniPct = AppConfig.inicialPorcentajePorFase(widget.fase);
    final double inicialUsd = Formatters.r2(monto * iniPct);
    final double restanteUsd = Formatters.r2(monto - inicialUsd);
    final double cuotaUsd = _cuotasSeleccionadas > 0
        ? Formatters.r2(restanteUsd / _cuotasSeleccionadas)
        : 0.0;

    final opcionesCuotas = <int>[2, 3, 4, 5, 6, 9]
        .where((q) => q <= widget.maxCuotas)
        .toList();

    return Scaffold(
      backgroundColor: PagobyteColors.paper,
      appBar: AppBar(
        backgroundColor: PagobyteColors.paper,
        elevation: 0,
        title: Text('Calculadora de Compra', style: PagobyteTheme.heading(18)),
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              gradient: PagobyteColors.heroGradient,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Simula tu compra desde \$5',
                  style: PagobyteTheme.heading(20, color: Colors.white),
                ),
                const SizedBox(height: 6),
                Text(
                  'Según tu Fase ${widget.fase}, tu inicial es del ${(iniPct * 100).round()}% con 0% de intereses.',
                  style: const TextStyle(color: Color(0xFFE0F2FE), fontSize: 13.5),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: PagobyteColors.card,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: PagobyteColors.line),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Precio del artículo en tienda (USD)',
                  style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: _montoCtrl,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  style: PagobyteTheme.mono(22, color: PagobyteColors.byteBlueDark),
                  decoration: const InputDecoration(
                    prefixText: '\$ ',
                    hintText: 'Ej. 8.00',
                  ),
                  onChanged: (_) => setState(() {}),
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [5, 8, 12, 20, 40].map((preset) {
                    return ActionChip(
                      label: Text('\$$preset', style: const TextStyle(fontWeight: FontWeight.w700)),
                      backgroundColor: PagobyteColors.softBlueBg,
                      onPressed: () {
                        _montoCtrl.text = preset.toStringAsFixed(2);
                        setState(() {});
                      },
                    );
                  }).toList(),
                ),
                const SizedBox(height: 16),
                const Text(
                  'Cantidad de cuotas quincenales',
                  style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  children: opcionesCuotas.map((q) {
                    final active = q == _cuotasSeleccionadas;
                    return ChoiceChip(
                      label: Text('$q cuotas'),
                      selected: active,
                      selectedColor: PagobyteColors.byteBlue,
                      backgroundColor: PagobyteColors.softBlueBg,
                      labelStyle: TextStyle(
                        color: active ? Colors.white : PagobyteColors.ink,
                        fontWeight: FontWeight.w700,
                      ),
                      onSelected: (_) => setState(() => _cuotasSeleccionadas = q),
                    );
                  }).toList(),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          if (monto > 0 && monto < 5)
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: PagobyteColors.warnBg,
                borderRadius: BorderRadius.circular(14),
              ),
              child: const Text(
                'El monto mínimo para compras con Pagobyte es de \$5.00 USD.',
                style: TextStyle(color: PagobyteColors.warn, fontWeight: FontWeight.w700, fontSize: 13),
              ),
            )
          else
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: PagobyteColors.card,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: PagobyteColors.byteBlue, width: 1.5),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Resumen estimado', style: PagobyteTheme.heading(16.5)),
                  const Divider(height: 22, color: PagobyteColors.line),
                  _row(
                    'Inicial hoy (${(iniPct * 100).round()}%)',
                    Formatters.usd(inicialUsd),
                    sub: widget.tasaBcv != null ? Formatters.bs(inicialUsd * widget.tasaBcv!) : null,
                    highlight: true,
                  ),
                  const SizedBox(height: 12),
                  _row(
                    '$_cuotasSeleccionadas cuotas quincenales',
                    '${Formatters.usd(cuotaUsd)} c/u',
                    sub: widget.tasaBcv != null ? '${Formatters.bs(cuotaUsd * widget.tasaBcv!)} c/u' : null,
                  ),
                  const Divider(height: 22, color: PagobyteColors.line),
                  _row('Intereses ordinarios', '\$0.00 (0%)', ok: true),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _row(String label, String val, {String? sub, bool highlight = false, bool ok = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
        Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              val,
              style: PagobyteTheme.mono(
                highlight ? 18 : 15,
                color: ok
                    ? PagobyteColors.ok
                    : (highlight ? PagobyteColors.byteBlueDark : PagobyteColors.ink),
              ),
            ),
            if (sub != null)
              Text(sub, style: const TextStyle(color: PagobyteColors.muted, fontSize: 12)),
          ],
        ),
      ],
    );
  }
}
