import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import '../core/config.dart';
import '../core/theme.dart';
import '../services/notification_service.dart';
import '../services/security_service.dart';
import '../services/supabase_service.dart';
import '../widgets/pagobyte_logo.dart';
import '../widgets/ui_kit.dart';
import 'cuotas_tab.dart';
import 'inicio_tab.dart';
import 'perfil_tab.dart';
import 'tienda_tab.dart';

class HomeShell extends StatefulWidget {
  final VoidCallback onSignedOut;

  const HomeShell({super.key, required this.onSignedOut});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;
  bool _loading = true;
  Map<String, dynamic> _profile = {};
  double? _tasaBcv;
  int _unreadCount = 0;
  bool _locked = false;
  bool _isOffline = false;
  Map<String, String>? _updateInfo;

  @override
  void initState() {
    super.initState();
    _checkBiometricLock();
    _initPermissionsAndNotifications();
    _bootstrap();
  }

  @override
  void dispose() {
    NotificationService.unsubscribe();
    super.dispose();
  }

  Future<void> _checkBiometricLock() async {
    final enabled = await SecurityService.isLockEnabled();
    if (!enabled) return;
    if (mounted) setState(() => _locked = true);
    final ok = await SecurityService.authenticate();
    if (ok && mounted) setState(() => _locked = false);
  }

  Future<void> _initPermissionsAndNotifications() async {
    if (!kIsWeb) {
      try {
        final status = await Permission.locationWhenInUse.status;
        if (status.isDenied) {
          await Permission.locationWhenInUse.request();
        }
      } catch (_) {}
    }

    await NotificationService.init();
    final user = SupabaseService.currentUser;
    if (user != null) {
      NotificationService.subscribeToSupabaseNotifications(
        userId: user.id,
        onNewNotification: (notif) {
          if (mounted) {
            setState(() => _unreadCount++);
            _showNotice('${notif['titulo'] ?? 'Aviso'}: ${notif['mensaje'] ?? ''}');
          }
        },
      );
      final notifs = await NotificationService.fetchMyNotifications();
      await NotificationService.notifyLatestUnreadIfNeeded(notifs);
      final unread = notifs.where((n) => n['leida'] != true).length;
      if (mounted) setState(() => _unreadCount = unread);
    }
  }

  Future<void> _bootstrap() async {
    try {
      final results = await Future.wait([
        SupabaseService.fetchMyBasicProfile(),
        SupabaseService.fetchLatestBcvRate(),
      ]);
      final prof = (results[0] as Map<String, dynamic>?) ?? {};
      final tasa = results[1] as double?;
      await SupabaseService.saveLocalCache('profile', {'profile': prof, 'tasa': tasa});
      final update = await SupabaseService.checkAppUpdate();
      if (mounted) {
        setState(() {
          _profile = prof;
          _tasaBcv = tasa;
          _isOffline = false;
          _updateInfo = update;
          _loading = false;
        });
      }
    } catch (_) {
      final cached = await SupabaseService.readLocalCache('profile');
      if (mounted) {
        setState(() {
          if (cached != null) {
            _profile = Map<String, dynamic>.from(cached['profile'] ?? {});
            _tasaBcv = (cached['tasa'] as num?)?.toDouble();
          }
          _isOffline = true;
          _loading = false;
        });
      }
    }
  }

  void _showNotice(String msg) {
    if (!mounted) return;
    final lower = msg.toLowerCase();
    final type = lower.contains('error') || lower.contains('no se pudo')
        ? ToastType.error
        : (lower.contains('listo') || lower.contains('aprob') || lower.contains('recibimos') || lower.contains('verific'))
            ? ToastType.success
            : ToastType.info;
    PagobyteToast.show(context, msg, type: type);
  }

  Future<void> _openNotificationsCenter() async {
    final notifs = await NotificationService.fetchMyNotifications();
    await NotificationService.markAllAsRead();
    if (mounted) setState(() => _unreadCount = 0);
    if (!mounted) return;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: PagobyteColors.paper,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => DraggableScrollableSheet(
        initialChildSize: 0.7,
        minChildSize: 0.4,
        maxChildSize: 0.9,
        expand: false,
        builder: (_, ctrl) => Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 18, 12, 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Notificaciones', style: PagobyteTheme.heading(20)),
                  TextButton(
                    onPressed: () => Navigator.pop(ctx),
                    child: const Text('Cerrar', style: TextStyle(fontWeight: FontWeight.w700)),
                  ),
                ],
              ),
            ),
            const Divider(height: 1, color: PagobyteColors.line),
            Expanded(
              child: notifs.isEmpty
                  ? const Center(
                      child: Text(
                        'No tienes notificaciones todavía.',
                        style: TextStyle(color: PagobyteColors.muted),
                      ),
                    )
                  : ListView.builder(
                      controller: ctrl,
                      padding: const EdgeInsets.all(16),
                      itemCount: notifs.length,
                      itemBuilder: (_, i) {
                        final n = notifs[i];
                        return Container(
                          margin: const EdgeInsets.only(bottom: 10),
                          padding: const EdgeInsets.all(14),
                          decoration: BoxDecoration(
                            color: PagobyteColors.card,
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(color: PagobyteColors.line),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                (n['titulo'] ?? 'Pagobyte').toString(),
                                style: PagobyteTheme.heading(15, color: PagobyteColors.byteBlue),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                (n['mensaje'] ?? '').toString(),
                                style: const TextStyle(fontSize: 13.5),
                              ),
                              const SizedBox(height: 6),
                              Text(
                                Formatters.fechaLarga(n['creada_en']?.toString()),
                                style: const TextStyle(color: PagobyteColors.muted, fontSize: 11.5),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_locked) {
      return Scaffold(
        backgroundColor: PagobyteColors.byteBlue,
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const PagobyteLogo(size: 56, darkSurface: true),
                const SizedBox(height: 18),
                Text('Pagobyte bloqueado', style: PagobyteTheme.heading(22, color: Colors.white)),
                const SizedBox(height: 8),
                const Text(
                  'Usa tu huella o PIN del teléfono para continuar.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Color(0xFFB9C3DE)),
                ),
                const SizedBox(height: 24),
                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: PagobyteColors.cyan,
                    foregroundColor: PagobyteColors.ink,
                  ),
                  icon: const Icon(Icons.fingerprint),
                  label: const Text('Desbloquear'),
                  onPressed: _checkBiometricLock,
                ),
              ],
            ),
          ),
        ),
      );
    }

    if (_loading) {
      return const Scaffold(body: SafeArea(child: PagobyteSkeletonList(count: 3, showHero: true)));
    }

    final tabs = [
      InicioTab(
        myProfile: _profile,
        tasaBcv: _tasaBcv,
        onNavigateTab: (i) => setState(() => _index = i),
      ),
      TiendaTab(
        myProfile: _profile,
        tasaBcv: _tasaBcv,
        onNavigateTab: (i) => setState(() => _index = i),
        onShowNotice: _showNotice,
      ),
      CuotasTab(
        myProfile: _profile,
        tasaBcv: _tasaBcv,
        onShowNotice: _showNotice,
      ),
      const PerfilTab(),
    ];

    return Scaffold(
      appBar: AppBar(
        backgroundColor: PagobyteColors.paper,
        elevation: 0,
        title: const Row(
          children: [
            PagobyteLogo(size: 26),
            SizedBox(width: 8),
            PagobyteWordmark(fontSize: 20),
          ],
        ),
        actions: [
          Stack(
            alignment: Alignment.center,
            children: [
              IconButton(
                icon: const Icon(Icons.notifications_outlined, color: PagobyteColors.ink),
                onPressed: _openNotificationsCenter,
              ),
              if (_unreadCount > 0)
                Positioned(
                  right: 6,
                  top: 6,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1.5),
                    decoration: BoxDecoration(
                      color: PagobyteColors.bad,
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Text(
                      _unreadCount > 9 ? '9+' : '$_unreadCount',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 10,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ),
            ],
          ),
          TextButton(
            onPressed: () async {
              NotificationService.unsubscribe();
              await SupabaseService.signOut();
              widget.onSignedOut();
            },
            child: const Text(
              'Salir',
              style: TextStyle(color: PagobyteColors.byteBlue, fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
      body: Stack(
        children: [
          Column(
            children: [
              if (_isOffline)
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  color: PagobyteColors.warnBg,
                  child: const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.wifi_off_rounded, size: 17, color: PagobyteColors.warn),
                      SizedBox(width: 8),
                      Text(
                        'Estás sin conexión • Mostrando vista rápida guardada',
                        style: TextStyle(
                          color: PagobyteColors.warn,
                          fontWeight: FontWeight.w700,
                          fontSize: 12.5,
                        ),
                      ),
                    ],
                  ),
                ),
              if (_updateInfo != null)
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  color: PagobyteColors.softBlueBg,
                  child: Row(
                    children: [
                      const Icon(Icons.system_update_rounded, size: 18, color: PagobyteColors.byteBlue),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'Nueva versión ${_updateInfo!['version']} disponible',
                          style: const TextStyle(
                            color: PagobyteColors.byteBlueDark,
                            fontWeight: FontWeight.w700,
                            fontSize: 12.5,
                          ),
                        ),
                      ),
                      TextButton(
                        onPressed: () {
                          SecurityService.openExternalUrl(_updateInfo!['url']!);
                        },
                        child: const Text('Actualizar', style: TextStyle(fontWeight: FontWeight.w800)),
                      ),
                    ],
                  ),
                ),
              Expanded(child: tabs[_index]),
            ],
          ),
          Positioned(
            left: 14,
            right: 14,
            bottom: 14,
            child: SafeArea(
              top: false,
              child: Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(color: PagobyteColors.line),
                  boxShadow: [
                    BoxShadow(
                      color: PagobyteColors.byteBlue.withOpacity(0.12),
                      blurRadius: 18,
                      offset: const Offset(0, 8),
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    _navBtn(0, Icons.home_rounded, 'Inicio'),
                    _navBtn(1, Icons.storefront_rounded, 'Tienda'),
                    _navBtn(2, Icons.payments_rounded, 'Pagos'),
                    _navBtn(3, Icons.person_rounded, 'Perfil'),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _navBtn(int idx, IconData icon, String label) {
    final bool active = _index == idx;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _index = idx),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: active ? PagobyteColors.softBlueBg : Colors.transparent,
            borderRadius: BorderRadius.circular(16),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                icon,
                size: 23,
                color: active ? PagobyteColors.byteBlue : PagobyteColors.muted,
              ),
              const SizedBox(height: 2),
              Text(
                label,
                style: TextStyle(
                  fontSize: 11.5,
                  fontWeight: FontWeight.w800,
                  color: active ? PagobyteColors.byteBlue : PagobyteColors.muted,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
