import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import '../core/config.dart';
import '../core/theme.dart';
import '../widgets/pagobyte_logo.dart';
import '../widgets/ui_kit.dart';

class SolvencyCertificateScreen extends StatefulWidget {
  final Map<String, dynamic> compra;
  final Map<String, dynamic> myProfile;

  const SolvencyCertificateScreen({
    super.key,
    required this.compra,
    required this.myProfile,
  });

  @override
  State<SolvencyCertificateScreen> createState() => _SolvencyCertificateScreenState();
}

class _SolvencyCertificateScreenState extends State<SolvencyCertificateScreen> {
  bool _generatingPdf = false;

  String get _compraId => (widget.compra['id'] ?? '').toString();
  String get _certCode =>
      'PB-SOLV-${_compraId.length >= 8 ? _compraId.substring(0, 8).toUpperCase() : _compraId.toUpperCase()}';
  String get _prodName =>
      ((widget.compra['productos'] as Map<String, dynamic>?)?['nombre'] ?? 'Producto Pagobyte').toString();
  double get _totalUsd => (widget.compra['total_usd'] as num?)?.toDouble() ?? 0.0;
  String get _nombre => (widget.myProfile['nombre'] ?? 'Cliente Pagobyte').toString();
  String get _cedula => (widget.myProfile['cedula'] ?? '').toString();
  String get _fechaHoy => Formatters.fechaLarga(DateTime.now().toIso8601String());

  Future<Uint8List> _buildSolvencyPdf() async {
    final doc = pw.Document(
      title: 'Certificado de Solvencia Digital $_certCode',
      author: 'Solvencia Digital Pagobyte',
    );

    const primaryBlue = PdfColor.fromInt(0xFF1D4ED8);
    const skyBlue = PdfColor.fromInt(0xFF38A3F1);
    const darkInk = PdfColor.fromInt(0xFF10203A);
    const mutedGray = PdfColor.fromInt(0xFF52627E);
    const okGreen = PdfColor.fromInt(0xFF0B7A5A);
    const okBg = PdfColor.fromInt(0xFFDDF3EA);
    const borderLine = PdfColor.fromInt(0xFFDCE5F4);
    const softBlue = PdfColor.fromInt(0xFFEAF2FF);

    pw.Widget pdfRow(String label, String value, {bool highlight = false}) {
      return pw.Container(
        padding: const pw.EdgeInsets.symmetric(vertical: 8, horizontal: 12),
        decoration: const pw.BoxDecoration(
          border: pw.Border(bottom: pw.BorderSide(color: borderLine, width: 0.8)),
        ),
        child: pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [
            pw.Text(
              label,
              style: const pw.TextStyle(color: mutedGray, fontSize: 10.5),
            ),
            pw.SizedBox(width: 12),
            pw.Expanded(
              child: pw.Text(
                value,
                textAlign: pw.TextAlign.right,
                style: pw.TextStyle(
                  color: highlight ? primaryBlue : darkInk,
                  fontSize: 11,
                  fontWeight: pw.FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
      );
    }

    doc.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(36),
        build: (pw.Context ctx) {
          return pw.Container(
            decoration: pw.BoxDecoration(
              border: pw.Border.all(color: primaryBlue, width: 1.6),
              borderRadius: pw.BorderRadius.circular(14),
            ),
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.stretch,
              children: [
                // Encabezado oficial Pagobyte
                pw.Container(
                  padding: const pw.EdgeInsets.symmetric(vertical: 24, horizontal: 26),
                  decoration: const pw.BoxDecoration(
                    color: primaryBlue,
                    borderRadius: pw.BorderRadius.vertical(top: pw.Radius.circular(12)),
                  ),
                  child: pw.Column(
                    children: [
                      pw.Text(
                        'PAGOBYTE',
                        style: pw.TextStyle(
                          color: PdfColors.white,
                          fontSize: 24,
                          fontWeight: pw.FontWeight.bold,
                          letterSpacing: 1.5,
                        ),
                      ),
                      pw.SizedBox(height: 6),
                      pw.Container(
                        padding: const pw.EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                        decoration: pw.BoxDecoration(
                          color: skyBlue,
                          borderRadius: pw.BorderRadius.circular(999),
                        ),
                        child: pw.Text(
                          'CERTIFICACIÓN DE SOLVENCIA DIGITAL',
                          style: pw.TextStyle(
                            color: PdfColors.white,
                            fontSize: 10.5,
                            fontWeight: pw.FontWeight.bold,
                            letterSpacing: 0.9,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                // Cuerpo único de certificación de solvencia
                pw.Padding(
                  padding: const pw.EdgeInsets.all(26),
                  child: pw.Column(
                    crossAxisAlignment: pw.CrossAxisAlignment.start,
                    children: [
                      pw.Center(
                        child: pw.Container(
                          padding: const pw.EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                          decoration: pw.BoxDecoration(
                            color: okBg,
                            borderRadius: pw.BorderRadius.circular(999),
                            border: pw.Border.all(color: okGreen, width: 1),
                          ),
                          child: pw.Text(
                            'VERIFICADO POR SOLVENCIA DIGITAL • OBLIGACIÓN SALDADA AL 100%',
                            style: pw.TextStyle(
                              color: okGreen,
                              fontSize: 10,
                              fontWeight: pw.FontWeight.bold,
                              letterSpacing: 0.5,
                            ),
                          ),
                        ),
                      ),
                      pw.SizedBox(height: 20),
                      pw.Text(
                        'Por medio del presente documento, el sistema de Solvencia Digital de PAGOBYTE certifica que el titular identificado a continuación ha cumplido satisfactoriamente con el pago total (100%) de la inicial y de todas las cuotas correspondientes a la obligación detallada, encontrándose completamente solvente y libre de saldos pendientes por este concepto.',
                        textAlign: pw.TextAlign.justify,
                        style: const pw.TextStyle(
                          color: darkInk,
                          fontSize: 11.5,
                          lineSpacing: 4,
                        ),
                      ),
                      pw.SizedBox(height: 22),

                      // Tabla limpia de datos de solvencia
                      pw.Container(
                        decoration: pw.BoxDecoration(
                          border: pw.Border.all(color: borderLine, width: 1),
                          borderRadius: pw.BorderRadius.circular(10),
                        ),
                        child: pw.Column(
                          children: [
                            pdfRow('Titular', _nombre),
                            pdfRow('Cédula de Identidad', _cedula),
                            pdfRow('Concepto / Producto saldado', _prodName),
                            pdfRow('Monto total saldado', Formatters.usd(_totalUsd), highlight: true),
                            pdfRow('Estado de la obligación', 'SOLVENTE (100% VERIFICADO)'),
                            pdfRow('Código de verificación digital', _certCode, highlight: true),
                            pdfRow('Fecha de emisión', _fechaHoy),
                          ],
                        ),
                      ),
                      pw.SizedBox(height: 24),

                      // Sello de verificación por Solvencia Digital + QR
                      pw.Container(
                        padding: const pw.EdgeInsets.all(14),
                        decoration: pw.BoxDecoration(
                          color: softBlue,
                          borderRadius: pw.BorderRadius.circular(10),
                          border: pw.Border.all(color: borderLine, width: 1),
                        ),
                        child: pw.Row(
                          crossAxisAlignment: pw.CrossAxisAlignment.center,
                          children: [
                            pw.BarcodeWidget(
                              barcode: pw.Barcode.qrCode(),
                              data: 'PAGOBYTE-SOLVENCIA-DIGITAL|$_certCode|$_cedula|${Formatters.usd(_totalUsd)}',
                              width: 68,
                              height: 68,
                              color: darkInk,
                            ),
                            pw.SizedBox(width: 14),
                            pw.Expanded(
                              child: pw.Column(
                                crossAxisAlignment: pw.CrossAxisAlignment.start,
                                children: [
                                  pw.Text(
                                    'SELLO DE SOLVENCIA DIGITAL VERIFICADA',
                                    style: pw.TextStyle(
                                      color: primaryBlue,
                                      fontSize: 10.5,
                                      fontWeight: pw.FontWeight.bold,
                                    ),
                                  ),
                                  pw.SizedBox(height: 4),
                                  pw.Text(
                                    'Documento emitido electrónicamente y validado por el registro de Solvencia Digital de Pagobyte. Código único: $_certCode.',
                                    style: const pw.TextStyle(
                                      color: mutedGray,
                                      fontSize: 9.5,
                                      lineSpacing: 3,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                pw.Spacer(),
                pw.Container(
                  padding: const pw.EdgeInsets.symmetric(vertical: 12, horizontal: 24),
                  decoration: const pw.BoxDecoration(
                    border: pw.Border(top: pw.BorderSide(color: borderLine, width: 0.8)),
                  ),
                  child: pw.Text(
                    'Este documento acredita únicamente la solvencia de la compra identificada con el código $_certCode.',
                    textAlign: pw.TextAlign.center,
                    style: const pw.TextStyle(color: mutedGray, fontSize: 9),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );

    return doc.save();
  }

  Future<void> _downloadPdf() async {
    if (_generatingPdf) return;
    setState(() => _generatingPdf = true);
    try {
      final bytes = await _buildSolvencyPdf();
      await Printing.sharePdf(
        bytes: bytes,
        filename: 'Certificado_Solvencia_$_certCode.pdf',
      );
      if (mounted) {
        PagobyteToast.show(
          context,
          'Certificado PDF generado correctamente.',
          type: ToastType.success,
        );
      }
    } catch (e) {
      if (mounted) {
        PagobyteToast.show(
          context,
          'No se pudo generar el PDF: $e',
          type: ToastType.error,
        );
      }
    } finally {
      if (mounted) setState(() => _generatingPdf = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: PagobyteColors.paper,
      appBar: AppBar(
        backgroundColor: PagobyteColors.paper,
        elevation: 0,
        title: Text('Certificado de Solvencia', style: PagobyteTheme.heading(18)),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Container(
              width: double.infinity,
              decoration: BoxDecoration(
                color: PagobyteColors.card,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: PagobyteColors.byteBlue, width: 1.6),
              ),
              child: Column(
                children: [
                  // Encabezado oficial azul claro
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(20),
                    decoration: const BoxDecoration(
                      gradient: PagobyteColors.heroGradient,
                      borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
                    ),
                    child: Column(
                      children: [
                        const Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            PagobyteLogo(size: 34, darkSurface: true),
                            SizedBox(width: 10),
                            PagobyteWordmark(fontSize: 26, darkSurface: true),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.20),
                            borderRadius: BorderRadius.circular(999),
                          ),
                          child: const Text(
                            'CERTIFICACIÓN DE SOLVENCIA DIGITAL',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w800,
                              fontSize: 11.5,
                              letterSpacing: 0.7,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Center(
                          child: Icon(Icons.verified_rounded, color: PagobyteColors.ok, size: 46),
                        ),
                        const SizedBox(height: 8),
                        Center(
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                            decoration: BoxDecoration(
                              color: PagobyteColors.okBg,
                              borderRadius: BorderRadius.circular(999),
                            ),
                            child: const Text(
                              'VERIFICADO POR SOLVENCIA DIGITAL',
                              style: TextStyle(
                                color: PagobyteColors.ok,
                                fontWeight: FontWeight.w800,
                                fontSize: 12,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 14),
                        const Text(
                          'El sistema de Solvencia Digital de PAGOBYTE certifica que el titular identificado ha cumplido con el pago total (100%) de la obligación descrita, quedando completamente solvente.',
                          textAlign: TextAlign.justify,
                          style: TextStyle(fontSize: 13.5, height: 1.5),
                        ),
                        const Divider(height: 26, color: PagobyteColors.line),
                        _infoRow('Titular', _nombre),
                        _infoRow('Cédula de Identidad', _cedula),
                        _infoRow('Producto saldado', _prodName),
                        _infoRow('Monto total saldado', Formatters.usd(_totalUsd), isMono: true),
                        _infoRow('Estado', 'Solvente (100%)'),
                        _infoRow('Código de verificación', _certCode, isMono: true),
                        _infoRow('Fecha de emisión', _fechaHoy),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            ElevatedButton.icon(
              icon: _generatingPdf
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2.2, color: Colors.white),
                    )
                  : const Icon(Icons.picture_as_pdf_rounded),
              label: Text(_generatingPdf ? 'Generando PDF...' : 'Descargar certificado en PDF'),
              onPressed: _generatingPdf ? null : _downloadPdf,
            ),
            const SizedBox(height: 10),
            OutlinedButton.icon(
              style: OutlinedButton.styleFrom(
                minimumSize: const Size(double.infinity, 46),
                side: const BorderSide(color: PagobyteColors.line),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              icon: const Icon(Icons.copy_rounded, size: 18, color: PagobyteColors.byteBlue),
              label: const Text(
                'Copiar código de verificación',
                style: TextStyle(color: PagobyteColors.byteBlue, fontWeight: FontWeight.w700),
              ),
              onPressed: () {
                Clipboard.setData(ClipboardData(text: _certCode));
                PagobyteToast.show(
                  context,
                  'Código de solvencia copiado al portapapeles.',
                  type: ToastType.info,
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _infoRow(String label, String value, {bool isMono = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: PagobyteColors.muted, fontSize: 12.5)),
          const SizedBox(width: 10),
          Flexible(
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: isMono
                  ? PagobyteTheme.mono(13.5, color: PagobyteColors.byteBlueDark)
                  : const TextStyle(fontWeight: FontWeight.w700, fontSize: 13.5),
            ),
          ),
        ],
      ),
    );
  }
}
