import 'package:flutter/material.dart';
import '../services/security_service.dart';
import 'payment_flow_screen.dart';
import 'solvency_certificate_screen.dart';
import '../core/config.dart';
import '../core/terms_data.dart';
import '../core/theme.dart';
import '../widgets/ui_kit.dart';
import '../services/supabase_service.dart';

class CuotasTab extends StatefulWidget {
  final Map<String, dynamic> myProfile;
  final double? tasaBcv;
  final ValueChanged<String> onShowNotice;

  const CuotasTab({
    super.key,
    required this.myProfile,
    required this.tasaBcv,
    required this.onShowNotice,
  });

  @override
  State<CuotasTab> createState() => _CuotasTabState();
}

class _CuotasTabState extends State<CuotasTab> {
  late Future<Map<String, dynamic>> _future;
  int _subTab = 0; // 0 = Pagos pendientes, 1 = Solvencias verificadas

  @override
  void initState() {
    super.initState();
    _future = SupabaseService.fetchCuotasData();
  }

  Future<void> _reload() async {
    setState(() => _future = SupabaseService.fetchCuotasData());
  }

  void _openOfferSheet(Map<String, dynamic> o) {
    final int n = (o['numero_cuotas'] as num).toInt();
    final double totalUsd = (o['total_usd'] as num).toDouble();
    final double inicialUsd = (o['inicial_usd'] as num).toDouble();
    final double resto = Formatters.r2(totalUsd - inicialUsd);
    final double cuota = Formatters.r2(resto / n);
    final double ultima = Formatters.r2(resto - cuota * (n - 1));
    final producto = (o['productos'] as Map<String, dynamic>?)?['nombre'] ?? 'Tu oferta';

    bool accepted = false;
    bool sending = false;
    String? err;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: PagobyteColors.paper,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => StatefulBuilder(
        builder: (context, setModal) => Padding(
          padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(ctx).viewInsets.bottom + 24),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(producto, style: PagobyteTheme.heading(20)),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: PagobyteColors.card,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: PagobyteColors.line),
                  ),
                  child: Column(
                    children: [
                      _simRow('Total a pagar', Formatters.usd(totalUsd), highlight: true),
                      _simRow(
                        'Inicial, lo primero',
                        '${Formatters.usd(inicialUsd)}${widget.tasaBcv != null ? ' (${Formatters.bs(inicialUsd * widget.tasaBcv!)})' : ''}',
                      ),
                      const Divider(height: 14, color: PagobyteColors.line),
                      ...List.generate(
                        n,
                        (i) => _simRow('Cuota ${i + 1}', Formatters.usd(i == n - 1 ? ultima : cuota)),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                const Text(
                  'Importante: una vez verificada tu inicial, la compra es definitiva e irrevocable y la inicial no se devuelve. Un atraso de 2 días suma \$5 de recargo.',
                  style: TextStyle(color: PagobyteColors.muted, fontSize: 12.5),
                ),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: PagobyteColors.tint,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Checkbox(
                        value: accepted,
                        activeColor: PagobyteColors.byteBlue,
                        onChanged: (v) => setModal(() => accepted = v ?? false),
                      ),
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.only(top: 8),
                          child: Wrap(
                            children: [
                              const Text('He leído los ', style: TextStyle(fontSize: 13)),
                              GestureDetector(
                                onTap: () => showTermsBottomSheet(context),
                                child: const Text(
                                  'términos y condiciones',
                                  style: TextStyle(
                                    fontSize: 13,
                                    color: PagobyteColors.byteBlue,
                                    fontWeight: FontWeight.w700,
                                    decoration: TextDecoration.underline,
                                  ),
                                ),
                              ),
                              Text(
                                ' y me comprometo a pagar la inicial de ${Formatters.usd(inicialUsd)} y las $n cuotas en sus fechas.',
                                style: const TextStyle(fontSize: 13),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                if (err != null) ...[
                  const SizedBox(height: 8),
                  Text(err!, style: const TextStyle(color: PagobyteColors.bad)),
                ],
                const SizedBox(height: 14),
                ElevatedButton(
                  onPressed: (!accepted || sending)
                      ? null
                      : () async {
                          setModal(() {
                            sending = true;
                            err = null;
                          });
                          try {
                            await SupabaseService.aceptarCompra(o['id'] as String);
                            if (ctx.mounted) Navigator.pop(ctx);
                            widget.onShowNotice('Compromiso registrado. Ahora paga tu inicial.');
                            _reload();
                          } catch (e) {
                            setModal(() {
                              sending = false;
                              err = e.toString();
                            });
                          }
                        },
                  child: Text(sending ? 'Registrando...' : 'Acepto mi compromiso'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _openPaymentFlow(Map<String, dynamic> compra, Map<String, dynamic> cuota, double recargoUsd) async {
    final ok = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) => PaymentFlowScreen(
          compra: compra,
          cuota: cuota,
          recargoUsd: recargoUsd,
          tasaBcv: widget.tasaBcv,
          myProfile: widget.myProfile,
        ),
      ),
    );
    if (ok == true) {
      widget.onShowNotice('Recibimos tu reporte. Lo revisaremos pronto.');
      _reload();
    }
  }

  Widget _simRow(String label, String value, {bool highlight = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(fontWeight: highlight ? FontWeight.w700 : FontWeight.w400)),
          Text(
            value,
            style: PagobyteTheme.mono(
              14,
              color: highlight ? PagobyteColors.byteBlue : PagobyteColors.ink,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: _reload,
      child: FutureBuilder<Map<String, dynamic>>(
        future: _future,
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const PagobyteSkeletonList(count: 3, showHero: true);
          }
          if (snap.hasError) {
            return Center(child: Text('Error: ${snap.error}'));
          }

          final bool offlineMode = snap.data!['offline'] == true;
          final ofertas = List<Map<String, dynamic>>.from(snap.data!['ofertas']);
          final solicitudes = List<Map<String, dynamic>>.from(snap.data!['solicitudes']);
          final allCompras = List<Map<String, dynamic>>.from(snap.data!['compras']);
          final comprasPendientes = allCompras.where((c) => c['estado'] != 'pagada' && c['estado'] != 'completada').toList();
          final comprasSolvencia = allCompras.where((c) => c['estado'] == 'pagada' || c['estado'] == 'completada').toList();

          return ListView(
            padding: const EdgeInsets.fromLTRB(18, 12, 18, 110),
            children: [
              if (offlineMode)
                Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: PagobyteColors.warnBg,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.wifi_off_rounded, size: 18, color: PagobyteColors.warn),
                      SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'Estás sin conexión. Vuelve a conectarte para reportar nuevos pagos.',
                          style: TextStyle(color: PagobyteColors.warn, fontSize: 12.5, fontWeight: FontWeight.w700),
                        ),
                      ),
                    ],
                  ),
                ),

              // Selector limpio: Pendientes vs Solvencias
              Container(
                padding: const EdgeInsets.all(4),
                margin: const EdgeInsets.only(bottom: 16),
                decoration: BoxDecoration(
                  color: PagobyteColors.softBlueBg,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: PagobyteColors.line),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: GestureDetector(
                        onTap: () => setState(() => _subTab = 0),
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          decoration: BoxDecoration(
                            color: _subTab == 0 ? PagobyteColors.byteBlue : Colors.transparent,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.schedule_rounded,
                                size: 17,
                                color: _subTab == 0 ? Colors.white : PagobyteColors.muted,
                              ),
                              const SizedBox(width: 6),
                              Text(
                                'Pendientes',
                                style: TextStyle(
                                  fontWeight: FontWeight.w800,
                                  fontSize: 13.5,
                                  color: _subTab == 0 ? Colors.white : PagobyteColors.muted,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Expanded(
                      child: GestureDetector(
                        onTap: () => setState(() => _subTab = 1),
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          decoration: BoxDecoration(
                            color: _subTab == 1 ? PagobyteColors.ok : Colors.transparent,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.verified_rounded,
                                size: 17,
                                color: _subTab == 1 ? Colors.white : PagobyteColors.muted,
                              ),
                              const SizedBox(width: 6),
                              Text(
                                'Solvencias (${comprasSolvencia.length})',
                                style: TextStyle(
                                  fontWeight: FontWeight.w800,
                                  fontSize: 13.5,
                                  color: _subTab == 1 ? Colors.white : PagobyteColors.muted,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              if (_subTab == 1) ...[
                if (comprasSolvencia.isEmpty)
                  Container(
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      color: PagobyteColors.card,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: PagobyteColors.line),
                    ),
                    child: const Column(
                      children: [
                        Icon(Icons.verified_outlined, size: 42, color: PagobyteColors.muted),
                        SizedBox(height: 10),
                        Text(
                          'Aún no tienes compras completadas.',
                          style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
                        ),
                        SizedBox(height: 4),
                        Text(
                          'Cuando completes todos los pagos de una compra, aquí aparecerá tu Certificado de Solvencia verificado.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: PagobyteColors.muted, fontSize: 13.5),
                        ),
                      ],
                    ),
                  )
                else
                  ...comprasSolvencia.map((c) => _buildSolvencyItemCard(c)),
              ] else ...[
                if (ofertas.isEmpty && solicitudes.isEmpty && comprasPendientes.isEmpty)
                  Container(
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      color: PagobyteColors.card,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: PagobyteColors.line),
                    ),
                    child: const Column(
                      children: [
                        Icon(Icons.check_circle_outline_rounded, size: 42, color: PagobyteColors.ok),
                        SizedBox(height: 10),
                        Text(
                          'No tienes pagos pendientes',
                          style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
                        ),
                        SizedBox(height: 4),
                        Text(
                          'Estás al día. Cuando solicites un producto en una tienda aliada, aquí verás tu plan de pagos.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: PagobyteColors.muted, fontSize: 13.5),
                        ),
                      ],
                    ),
                  ),
              if (ofertas.isNotEmpty) ...[
                Text('Oferta por aceptar', style: PagobyteTheme.heading(16)),
                const SizedBox(height: 8),
                ...ofertas.map((o) => Container(
                      margin: const EdgeInsets.only(bottom: 12),
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: PagobyteColors.card,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: PagobyteColors.byteBlue, width: 1.8),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Expanded(
                                child: Text(
                                  (o['productos'] as Map<String, dynamic>?)?['nombre'] ?? '',
                                  style: PagobyteTheme.heading(16),
                                ),
                              ),
                              Text(
                                Formatters.usd(o['total_usd'] ?? 0),
                                style: PagobyteTheme.mono(16, color: PagobyteColors.byteBlue),
                              ),
                            ],
                          ),
                          const SizedBox(height: 6),
                          Text(
                            'Inicial de ${Formatters.usd(o['inicial_usd'] ?? 0)} y ${o['numero_cuotas']} cuotas. Aprobada por Pagobyte.',
                            style: const TextStyle(color: PagobyteColors.muted, fontSize: 13.5),
                          ),
                          const SizedBox(height: 12),
                          ElevatedButton(
                            onPressed: () => _openOfferSheet(o),
                            child: const Text('Ver condiciones y aceptar'),
                          ),
                        ],
                      ),
                    )),
              ],
              if (solicitudes.isNotEmpty) ...[
                Text('Mi solicitud', style: PagobyteTheme.heading(16)),
                const SizedBox(height: 8),
                ...solicitudes.map((s) {
                  final pend = s['estado'] == 'pendiente';
                  return Container(
                    margin: const EdgeInsets.only(bottom: 12),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: PagobyteColors.card,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: PagobyteColors.line),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Text(
                                (s['productos'] as Map<String, dynamic>?)?['nombre'] ?? '',
                                style: PagobyteTheme.heading(15),
                              ),
                            ),
                            _badge(
                              pend ? 'En revisión' : 'No aprobada',
                              pend ? PagobyteColors.warnBg : PagobyteColors.badBg,
                              pend ? PagobyteColors.warn : PagobyteColors.bad,
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Text(
                          (s['nota_admin'] != null && s['nota_admin'].toString().isNotEmpty)
                              ? 'Respuesta: ${s['nota_admin']}'
                              : 'La estamos revisando. Te avisaremos aquí.',
                          style: const TextStyle(color: PagobyteColors.muted, fontSize: 13),
                        ),
                      ],
                    ),
                  );
                }),
              ],
              if (comprasPendientes.isNotEmpty) ...[
                Text('Mi compra', style: PagobyteTheme.heading(16)),
                const SizedBox(height: 8),
                ...comprasPendientes.map(_buildCompraCard),
              ],
              ],
            ],
          );
        },
      ),
    );
  }

  Widget _buildCompraCard(Map<String, dynamic> c) {
    final String estado = c['estado'] as String;
    final bool esperandoInicial = estado == 'esperando_inicial';
    final bool activa = estado == 'activa';
    final double totalUsd = (c['total_usd'] as num).toDouble();
    final cuotas = List<Map<String, dynamic>>.from(c['cuotas'] ?? [])
      ..sort((a, b) => (a['numero'] as num).compareTo(b['numero'] as num));

    final pagadas = cuotas.where((x) => x['estado'] == 'pagada').toList();
    final double pagadoUsd = pagadas.fold(0.0, (sum, x) => sum + (x['monto_usd'] as num).toDouble());

    bool esPendiente(Map<String, dynamic> x) =>
        x['estado'] == 'pendiente' || x['estado'] == 'vencida';

    Map<String, dynamic>? siguiente;
    for (final x in cuotas) {
      if (esPendiente(x) && (!esperandoInicial || x['numero'] == 0)) {
        siguiente = x;
        break;
      }
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: PagobyteColors.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: PagobyteColors.line),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Text(
                  (c['productos'] as Map<String, dynamic>?)?['nombre'] ?? '',
                  style: PagobyteTheme.heading(16),
                ),
              ),
              _badge(
                estado == 'pagada'
                    ? 'Pagada'
                    : esperandoInicial
                        ? 'Esperando inicial'
                        : 'En curso',
                estado == 'pagada'
                    ? PagobyteColors.okBg
                    : esperandoInicial
                        ? PagobyteColors.warnBg
                        : PagobyteColors.tint,
                estado == 'pagada'
                    ? PagobyteColors.ok
                    : esperandoInicial
                        ? PagobyteColors.warn
                        : PagobyteColors.byteBlue,
              ),
            ],
          ),
          const SizedBox(height: 10),
          // Barra segmentada de progreso
          Row(
            children: cuotas.map((x) {
              Color col = PagobyteColors.line;
              if (x['estado'] == 'pagada') col = PagobyteColors.byteBlue;
              else if (x['estado'] == 'reportada') col = PagobyteColors.cyan;
              else if (x['estado'] == 'vencida') col = PagobyteColors.bad;
              return Expanded(
                child: Container(
                  height: 8,
                  margin: const EdgeInsets.only(right: 4),
                  decoration: BoxDecoration(
                    color: col,
                    borderRadius: BorderRadius.circular(3),
                  ),
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 8),
          Text(
            '${pagadas.length} de ${cuotas.length} pagos. Has pagado ${Formatters.usd(pagadoUsd)} de ${Formatters.usd(totalUsd)}; falta ${Formatters.usd(Formatters.r2(totalUsd - pagadoUsd))}.',
            style: const TextStyle(color: PagobyteColors.muted, fontSize: 13),
          ),
          if (activa) ...[
            const SizedBox(height: 4),
            const Text(
              'Puedes adelantar cuotas cuando quieras: suma puntos para subir de fase.',
              style: TextStyle(color: PagobyteColors.byteBlue, fontSize: 12.5, fontWeight: FontWeight.w600),
            ),
          ],
          const SizedBox(height: 10),
          // Lista ordenada de cuotas
          ...cuotas.map((x) {
            final int numC = (x['numero'] as num).toInt();
            final double mUsd = (x['monto_usd'] as num).toDouble();
            final String? vence = x['fecha_vencimiento'] as String?;
            final double rec = (activa && esPendiente(x))
                ? Formatters.calcularRecargoUsd(vence, mUsd)
                : 0.0;
            final bool isSig = siguiente != null && siguiente['id'] == x['id'];
            final String stCuota = (x['estado'] ?? 'pendiente').toString();
            final String timelineTxt = stCuota == 'pagada'
                ? 'Enviado ✓ • Revisado ✓ • Verificado ✓'
                : stCuota == 'reportada'
                    ? 'Enviado ✓ • En revisión • Verificado'
                    : (esperandoInicial
                        ? (numC == 0 ? 'Págala primero' : 'Tras la inicial')
                        : Formatters.diaCorto(vence));

            Widget trailing;
            if (x['estado'] == 'pagada') {
              trailing = _badge('Pagada', PagobyteColors.okBg, PagobyteColors.ok);
            } else if (x['estado'] == 'reportada') {
              trailing = _badge('En revisión', PagobyteColors.warnBg, PagobyteColors.warn);
            } else if (isSig) {
              trailing = _badge(
                rec > 0 ? 'Vencida' : 'Toca pagar',
                rec > 0 ? PagobyteColors.badBg : PagobyteColors.tint,
                rec > 0 ? PagobyteColors.bad : PagobyteColors.byteBlue,
              );
            } else if (activa) {
              trailing = TextButton(
                style: TextButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  minimumSize: Size.zero,
                  side: const BorderSide(color: PagobyteColors.byteBlue),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
                onPressed: () => _openPaymentFlow(c, x, rec),
                child: const Text('Adelantar', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
              );
            } else {
              trailing = const Text('Tras inicial', style: TextStyle(fontSize: 11.5, color: PagobyteColors.muted));
            }

            return Container(
              margin: const EdgeInsets.only(bottom: 6),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
              decoration: BoxDecoration(
                color: isSig ? PagobyteColors.tint : PagobyteColors.paper,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                children: [
                  SizedBox(
                    width: 62,
                    child: Text(
                      numC == 0 ? 'Inicial' : 'Cuota $numC',
                      style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
                    ),
                  ),
                  Expanded(
                    child: Text(
                      timelineTxt,
                      style: const TextStyle(color: PagobyteColors.muted, fontSize: 12.5),
                    ),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(Formatters.usd(mUsd), style: PagobyteTheme.mono(13)),
                      if (rec > 0)
                        Text(
                          '+${Formatters.usd(rec)} mora',
                          style: const TextStyle(color: PagobyteColors.bad, fontSize: 11, fontWeight: FontWeight.w700),
                        ),
                    ],
                  ),
                  const SizedBox(width: 10),
                  trailing,
                ],
              ),
            );
          }),
          if (estado == 'pagada') ...[
            const SizedBox(height: 10),
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: PagobyteColors.ok,
                foregroundColor: Colors.white,
              ),
              icon: const Icon(Icons.verified_outlined),
              label: const Text('Ver Certificado de Solvencia Digital'),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => SolvencyCertificateScreen(
                      compra: c,
                      myProfile: widget.myProfile,
                    ),
                  ),
                );
              },
            ),
          ],
          if (siguiente != null) ...[
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: () {
                final rec = activa
                    ? Formatters.calcularRecargoUsd(
                        siguiente!['fecha_vencimiento'] as String?,
                        (siguiente['monto_usd'] as num).toDouble(),
                      )
                    : 0.0;
                _openPaymentFlow(c, siguiente!, rec);
              },
              child: Text(
                siguiente['numero'] == 0
                    ? 'Reportar el pago de la inicial'
                    : 'Reportar el pago de la cuota ${siguiente['numero']}',
              ),
            ),
            if (siguiente['fecha_vencimiento'] != null) ...[
              const SizedBox(height: 8),
              OutlinedButton.icon(
                style: OutlinedButton.styleFrom(
                  minimumSize: const Size(double.infinity, 44),
                  side: const BorderSide(color: PagobyteColors.byteBlue),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                icon: const Icon(Icons.calendar_month_outlined, color: PagobyteColors.byteBlue, size: 19),
                label: const Text(
                  'Agendar próxima cuota en Google Calendar',
                  style: TextStyle(color: PagobyteColors.byteBlue, fontWeight: FontWeight.w700, fontSize: 12.5),
                ),
                onPressed: () {
                  final prod = ((c['productos'] as Map<String, dynamic>?)?['nombre'] ?? 'Pagobyte').toString();
                  final numC = siguiente!['numero'];
                  final montoC = Formatters.usd((siguiente!['monto_usd'] as num).toDouble());
                  SecurityService.openGoogleCalendarReminder(
                    titulo: 'Pago Cuota $numC Pagobyte ($prod)',
                    detalles: 'Recuerda pagar tu cuota $numC de $prod por $montoC en la app Pagobyte a tasa BCV del día.',
                    fechaIso: siguiente!['fecha_vencimiento'].toString(),
                  );
                },
              ),
            ],
            const SizedBox(height: 8),
            OutlinedButton.icon(
              style: OutlinedButton.styleFrom(
                minimumSize: const Size(double.infinity, 44),
                side: const BorderSide(color: PagobyteColors.ok),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              icon: const Icon(Icons.support_agent, color: PagobyteColors.ok, size: 19),
              label: const Text(
                '¿Inconveniente con tu cuota? Escribir a WhatsApp',
                style: TextStyle(color: PagobyteColors.ok, fontWeight: FontWeight.w700, fontSize: 12.5),
              ),
              onPressed: () {
                final prod = ((c['productos'] as Map<String, dynamic>?)?['nombre'] ?? 'mi compra').toString();
                SecurityService.openWhatsAppSupport(
                  nombre: (widget.myProfile['nombre'] ?? 'Cliente').toString(),
                  cedula: (widget.myProfile['cedula'] ?? '').toString(),
                  contexto: 'Necesito asistencia con mi compra de $prod.',
                );
              },
            ),
          ],
        ],
      ),
    );
  }

  Widget _badge(String text, Color bg, Color fg) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(999)),
      child: Text(
        text,
        style: TextStyle(color: fg, fontSize: 11.5, fontWeight: FontWeight.w700),
      ),
    );
  }

  Widget _buildSolvencyItemCard(Map<String, dynamic> c) {
    final prod = ((c['productos'] as Map<String, dynamic>?)?['nombre'] ?? 'Compra Pagobyte').toString();
    final total = Formatters.usd((c['total_usd'] as num?)?.toDouble() ?? 0.0);
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: PagobyteColors.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: PagobyteColors.ok.withOpacity(0.45), width: 1.4),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(9),
                decoration: BoxDecoration(
                  color: PagobyteColors.okBg,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.verified_rounded, color: PagobyteColors.ok, size: 22),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(prod, style: PagobyteTheme.heading(16)),
                    const SizedBox(height: 2),
                    Text(
                      'Pagado y verificado • Total $total',
                      style: const TextStyle(color: PagobyteColors.ok, fontWeight: FontWeight.w700, fontSize: 12.5),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: PagobyteColors.ok,
              foregroundColor: Colors.white,
            ),
            icon: const Icon(Icons.workspace_premium_rounded, size: 19),
            label: const Text('Ver Certificado de Solvencia'),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => SolvencyCertificateScreen(
                    compra: c,
                    myProfile: widget.myProfile,
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

}
