import 'package:flutter/material.dart';
import '../core/config.dart';
import '../core/theme.dart';
import '../widgets/ui_kit.dart';
import '../services/supabase_service.dart';
import 'bytecode_screen.dart';

class TiendaTab extends StatefulWidget {
  final Map<String, dynamic> myProfile;
  final double? tasaBcv;
  final ValueChanged<int> onNavigateTab;
  final ValueChanged<String> onShowNotice;

  const TiendaTab({
    super.key,
    required this.myProfile,
    required this.tasaBcv,
    required this.onNavigateTab,
    required this.onShowNotice,
  });

  @override
  State<TiendaTab> createState() => _TiendaTabState();
}

class _TiendaTabState extends State<TiendaTab> {
  late Future<Map<String, dynamic>> _future;
  Map<String, dynamic>? _selectedStore;
  String _storeQuery = '';
  String _productQuery = '';
  String _selectedCategory = 'Todos';
  Set<String> _favorites = {};
  bool _onlyFavorites = false;

  @override
  void initState() {
    super.initState();
    _future = SupabaseService.fetchTiendaData();
    _loadFavorites();
  }


  Future<void> _loadFavorites() async {
    final favs = await SupabaseService.getFavoriteProductIds();
    if (mounted) setState(() => _favorites = favs);
  }

  Future<void> _reload() async {
    setState(() => _future = SupabaseService.fetchTiendaData());
  }

  int get _userMaxCuotas => (widget.myProfile['max_cuotas'] as num?)?.toInt() ?? 3;
  int get _userFase => (widget.myProfile['fase'] as num?)?.toInt() ?? 1;
  double get _userIniPct => AppConfig.inicialPorcentajePorFase(_userFase);
  String get _userFaseNombre => (widget.myProfile['fase_nombre'] ?? 'Bit').toString();

  void _openRequestSheet(Map<String, dynamic> p) {
    final int stock = (p['stock'] as num?)?.toInt() ?? 1;
    final int maxCant = stock < 5 ? stock : 5;
    final double precioUnit = (p['precio_usd'] as num?)?.toDouble() ?? 0.0;
    final int prodMax = (p['max_cuotas'] as num?)?.toInt() ?? 9;
    final int maxCuotasPlan = _userMaxCuotas < prodMax ? _userMaxCuotas : prodMax;

    int cantidad = 1;
    final motivoCtrl = TextEditingController();
    String? err;
    bool sending = false;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: PagobyteColors.paper,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => StatefulBuilder(
        builder: (context, setModal) {
          final double totalUsd = Formatters.r2(precioUnit * cantidad);
          final double inicialUsd = Formatters.r2(totalUsd * _userIniPct);
          final double cuotaUsd = Formatters.r2((totalUsd - inicialUsd) / maxCuotasPlan);

          return Padding(
            padding: EdgeInsets.fromLTRB(
              20,
              20,
              20,
              MediaQuery.of(ctx).viewInsets.bottom + 24,
            ),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(p['nombre'] ?? '', style: PagobyteTheme.heading(20)),
                  const SizedBox(height: 6),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: PagobyteColors.tint,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Simulador según tu Fase ($_userFaseNombre)',
                          style: const TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 12,
                            color: PagobyteColors.byteBlue,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('Inicial según tu fase (${(_userIniPct * 100).round()}%):', style: const TextStyle(fontSize: 13)),
                            Text(
                              '${Formatters.usd(inicialUsd)}${widget.tasaBcv != null ? ' (${Formatters.bs(inicialUsd * widget.tasaBcv!)})' : ''}',
                              style: PagobyteTheme.mono(13, color: PagobyteColors.ink),
                            ),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('$maxCuotasPlan cuotas quincenales:', style: const TextStyle(fontSize: 13)),
                            Text(
                              '${Formatters.usd(cuotaUsd)} c/u',
                              style: PagobyteTheme.mono(13, color: PagobyteColors.byteBlue),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  const Text('Cantidad', style: TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 6),
                  DropdownButtonFormField<int>(
                    value: cantidad,
                    items: List.generate(maxCant, (i) => i + 1)
                        .map((n) => DropdownMenuItem(value: n, child: Text('$n')))
                        .toList(),
                    onChanged: (v) {
                      if (v != null) setModal(() => cantidad = v);
                    },
                  ),
                  const SizedBox(height: 14),
                  const Text('¿Para qué lo necesitas?', style: TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 6),
                  TextField(
                    controller: motivoCtrl,
                    maxLines: 3,
                    onChanged: (_) => setModal(() {}),
                    decoration: const InputDecoration(
                      hintText: 'Cuéntanos con tus palabras para qué lo vas a usar y por qué lo necesitas ahora.',
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    motivoCtrl.text.trim().length < 20
                        ? 'Te faltan ${20 - motivoCtrl.text.trim().length} letras (mínimo 20).'
                        : 'Listo.',
                    style: const TextStyle(color: PagobyteColors.muted, fontSize: 12.5),
                  ),
                  if (err != null) ...[
                    const SizedBox(height: 8),
                    Text(err!, style: const TextStyle(color: PagobyteColors.bad, fontWeight: FontWeight.w600)),
                  ],
                  const SizedBox(height: 14),
                  ElevatedButton(
                    onPressed: sending
                        ? null
                        : () async {
                            if (motivoCtrl.text.trim().length < 20) {
                              setModal(() => err = 'Escribe al menos 20 caracteres en el motivo.');
                              return;
                            }
                            setModal(() {
                              sending = true;
                              err = null;
                            });
                            try {
                              await SupabaseService.solicitarProducto(
                                productoId: p['id'] as String,
                                cantidad: cantidad,
                                motivo: motivoCtrl.text,
                              );
                              if (ctx.mounted) Navigator.pop(ctx);
                              widget.onShowNotice('Recibimos tu solicitud. La revisaremos pronto.');
                              widget.onNavigateTab(2);
                            } catch (e) {
                              setModal(() {
                                sending = false;
                                err = e.toString();
                              });
                            }
                          },
                    child: Text(sending ? 'Enviando...' : 'Enviar solicitud'),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  List<Map<String, dynamic>> _productsForStore(
    Map<String, dynamic> store,
    List<Map<String, dynamic>> allProducts,
    bool isFallbackOfficial,
  ) {
    final storeId = (store['id'] ?? '').toString();
    final direct = allProducts.where((p) => (p['tienda_id'] ?? '').toString() == storeId).toList();
    if (direct.isNotEmpty) return direct;
    // Si la tienda aún no tiene productos asignados por tienda_id y es la tienda principal/única, muestra los sin asignar
    final unassigned = allProducts.where((p) => p['tienda_id'] == null || p['tienda_id'].toString().isEmpty).toList();
    if (isFallbackOfficial) return unassigned.isNotEmpty ? unassigned : allProducts;
    return unassigned;
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: _reload,
      child: FutureBuilder<Map<String, dynamic>>(
        future: _future,
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const PagobyteSkeletonList(count: 3, showHero: true);
          }
          if (snap.hasError) {
            return Center(child: Text('Error: ${snap.error}'));
          }

          final tiendasRaw = List<Map<String, dynamic>>.from(snap.data!['tiendas'] ?? []);
          final allProductos = List<Map<String, dynamic>>.from(snap.data!['productos'] ?? []);
          final bool bloqueado = snap.data!['bloqueado'] as bool;
          final bool isFallbackOfficial = tiendasRaw.isEmpty;

          final List<Map<String, dynamic>> tiendas = tiendasRaw.isNotEmpty
              ? tiendasRaw
              : [
                  {
                    'id': 'oficial',
                    'nombre_comercial': 'Tienda Oficial Pagobyte',
                    'codigo_numerico': '0001',
                  }
                ];

          // VISTA 1: CATÁLOGO DE TIENDAS (muestra el nombre de cada tienda)
          if (_selectedStore == null) {
            final filteredTiendas = _storeQuery.trim().isEmpty
                ? tiendas
                : tiendas.where((t) {
                    final n = (t['nombre_comercial'] ?? '').toString().toLowerCase();
                    final c = (t['codigo_numerico'] ?? '').toString().toLowerCase();
                    final q = _storeQuery.trim().toLowerCase();
                    return n.contains(q) || c.contains(q);
                  }).toList();

            return ListView(
              padding: const EdgeInsets.fromLTRB(18, 12, 18, 110),
              children: [
                if (!bloqueado)
                  Container(
                    margin: const EdgeInsets.only(bottom: 16),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      gradient: PagobyteColors.heroGradient,
                      borderRadius: BorderRadius.circular(18),
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.20),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Icon(Icons.dialpad_rounded, color: Colors.white, size: 24),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                '¿Estás en una Tienda Aliada?',
                                style: PagobyteTheme.heading(15.5, color: Colors.white),
                              ),
                              const SizedBox(height: 2),
                              const Text(
                                'Genera tu ByteCode de 6 dígitos y díctalo en caja.',
                                style: TextStyle(color: Color(0xFFE0F2FE), fontSize: 12.5),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 8),
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.white,
                            foregroundColor: PagobyteColors.byteBlueDark,
                            minimumSize: const Size(0, 40),
                            padding: const EdgeInsets.symmetric(horizontal: 14),
                          ),
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (_) => const ByteCodeScreen()),
                            );
                          },
                          child: const Text('ByteCode'),
                        ),
                      ],
                    ),
                  ),

                if (bloqueado)
                  Container(
                    margin: const EdgeInsets.only(bottom: 14),
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: PagobyteColors.warnBg,
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: const Row(
                      children: [
                        Icon(Icons.info_outline_rounded, color: PagobyteColors.warn, size: 20),
                        SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            'Ya tienes una compra o solicitud activa. Puedes explorar las tiendas y solicitar de nuevo al completar tus pagos.',
                            style: TextStyle(color: PagobyteColors.warn, fontSize: 12.5, fontWeight: FontWeight.w600),
                          ),
                        ),
                      ],
                    ),
                  ),

                Text('Tiendas Aliadas', style: PagobyteTheme.heading(20)),
                const SizedBox(height: 4),
                const Text(
                  'Toca una tienda para entrar y explorar su catálogo disponible.',
                  style: TextStyle(color: PagobyteColors.muted, fontSize: 13.5),
                ),
                const SizedBox(height: 12),

                if (tiendas.length > 3) ...[
                  TextField(
                    decoration: const InputDecoration(
                      hintText: 'Buscar tienda por nombre...',
                      prefixIcon: Icon(Icons.search_rounded, color: PagobyteColors.muted),
                    ),
                    onChanged: (v) => setState(() => _storeQuery = v),
                  ),
                  const SizedBox(height: 14),
                ],

                if (filteredTiendas.isEmpty)
                  Container(
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      color: PagobyteColors.card,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: PagobyteColors.line),
                    ),
                    child: const Text(
                      'No encontramos tiendas con ese nombre.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: PagobyteColors.muted),
                    ),
                  )
                else
                  ...filteredTiendas.map((t) {
                    final nombre = (t['nombre_comercial'] ?? 'Tienda Aliada').toString();
                    final codigo = (t['codigo_numerico'] ?? '').toString();
                    final storeProducts = _productsForStore(t, allProductos, isFallbackOfficial);
                    final int count = storeProducts.length;

                    return Container(
                      margin: const EdgeInsets.only(bottom: 12),
                      decoration: BoxDecoration(
                        color: PagobyteColors.card,
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(color: PagobyteColors.line),
                      ),
                      child: Material(
                        color: Colors.transparent,
                        borderRadius: BorderRadius.circular(18),
                        child: InkWell(
                          borderRadius: BorderRadius.circular(18),
                          onTap: () => setState(() {
                            _selectedStore = t;
                            _productQuery = '';
                            _selectedCategory = 'Todos';
                          }),
                          child: Padding(
                            padding: const EdgeInsets.all(16),
                            child: Row(
                              children: [
                                Container(
                                  width: 52,
                                  height: 52,
                                  decoration: BoxDecoration(
                                    color: PagobyteColors.softBlueBg,
                                    borderRadius: BorderRadius.circular(15),
                                  ),
                                  child: const Icon(
                                    Icons.storefront_rounded,
                                    color: PagobyteColors.byteBlue,
                                    size: 27,
                                  ),
                                ),
                                const SizedBox(width: 14),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(nombre, style: PagobyteTheme.heading(17)),
                                      const SizedBox(height: 4),
                                      Wrap(
                                        spacing: 8,
                                        runSpacing: 4,
                                        crossAxisAlignment: WrapCrossAlignment.center,
                                        children: [
                                          const PagobyteBadge(
                                            label: 'Verificada',
                                            backgroundColor: PagobyteColors.okBg,
                                            textColor: PagobyteColors.ok,
                                            showDot: true,
                                          ),
                                          Text(
                                            count == 1 ? '1 producto' : '$count productos',
                                            style: const TextStyle(
                                              color: PagobyteColors.muted,
                                              fontSize: 12.5,
                                              fontWeight: FontWeight.w600,
                                            ),
                                          ),
                                          if (codigo.isNotEmpty)
                                            Text(
                                              '• Cód. $codigo',
                                              style: const TextStyle(
                                                color: PagobyteColors.muted,
                                                fontSize: 12,
                                              ),
                                            ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                                const Column(
                                  children: [
                                    Icon(
                                      Icons.arrow_forward_ios_rounded,
                                      color: PagobyteColors.byteBlue,
                                      size: 18,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    );
                  }),
              ],
            );
          }

          // VISTA 2: CATÁLOGO DE LA TIENDA SELECCIONADA
          final storeName = (_selectedStore!['nombre_comercial'] ?? 'Tienda Aliada').toString();
          final storeProducts = _productsForStore(_selectedStore!, allProductos, isFallbackOfficial);

          final Set<String> catSet = {'Todos', 'Favoritos'};
          for (final p in storeProducts) {
            final c = (p['categoria'] ?? '').toString().trim();
            if (c.isNotEmpty) catSet.add(c);
          }
          final categories = catSet.toList();

          final visibleProducts = storeProducts.where((p) {
            final pid = (p['id'] ?? '').toString();
            final catOk = _selectedCategory == 'Todos'
                ? true
                : _selectedCategory == 'Favoritos'
                    ? _favorites.contains(pid)
                    : (p['categoria'] ?? '').toString().trim() == _selectedCategory;
            if (!catOk) return false;
            if (_productQuery.trim().isEmpty) return true;
            final q = _productQuery.trim().toLowerCase();
            final n = (p['nombre'] ?? '').toString().toLowerCase();
            final d = (p['descripcion'] ?? '').toString().toLowerCase();
            return n.contains(q) || d.contains(q);
          }).toList();

          return ListView(
            padding: const EdgeInsets.fromLTRB(18, 12, 18, 110),
            children: [
              Row(
                children: [
                  OutlinedButton.icon(
                    style: OutlinedButton.styleFrom(
                      foregroundColor: PagobyteColors.byteBlue,
                      side: const BorderSide(color: PagobyteColors.line),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    ),
                    icon: const Icon(Icons.arrow_back_rounded, size: 18),
                    label: const Text('Tiendas', style: TextStyle(fontWeight: FontWeight.w700)),
                    onPressed: () => setState(() => _selectedStore = null),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          storeName,
                          style: PagobyteTheme.heading(18),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        Text(
                          'Catálogo disponible (${storeProducts.length})',
                          style: const TextStyle(color: PagobyteColors.muted, fontSize: 12.5),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),

              if (storeProducts.isNotEmpty) ...[
                TextField(
                  decoration: InputDecoration(
                    hintText: 'Buscar en $storeName...',
                    prefixIcon: const Icon(Icons.search_rounded, color: PagobyteColors.muted),
                  ),
                  onChanged: (v) => setState(() => _productQuery = v),
                ),
                if (categories.length > 2) ...[
                  const SizedBox(height: 10),
                  SizedBox(
                    height: 36,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      itemCount: categories.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 8),
                      itemBuilder: (_, idx) {
                        final cat = categories[idx];
                        final active = cat == _selectedCategory;
                        return ChoiceChip(
                          label: Text(cat),
                          selected: active,
                          selectedColor: PagobyteColors.byteBlue,
                          backgroundColor: PagobyteColors.card,
                          labelStyle: TextStyle(
                            color: active ? Colors.white : PagobyteColors.ink,
                            fontWeight: FontWeight.w700,
                            fontSize: 12.5,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(999),
                            side: BorderSide(
                              color: active ? PagobyteColors.byteBlue : PagobyteColors.line,
                            ),
                          ),
                          onSelected: (_) => setState(() => _selectedCategory = cat),
                        );
                      },
                    ),
                  ),
                ],
                const SizedBox(height: 14),
              ],

              if (visibleProducts.isEmpty)
                Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: PagobyteColors.card,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: PagobyteColors.line),
                  ),
                  child: Column(
                    children: [
                      const Icon(Icons.inventory_2_outlined, size: 38, color: PagobyteColors.muted),
                      const SizedBox(height: 8),
                      Text(
                        storeProducts.isEmpty
                            ? 'Esta tienda aún no tiene productos publicados.'
                            : 'No hay productos que coincidan con tu búsqueda.',
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: PagobyteColors.muted),
                      ),
                    ],
                  ),
                )
              else
                ...visibleProducts.map((p) {
                  final double precio = (p['precio_usd'] as num?)?.toDouble() ?? 0.0;
                  final int stock = (p['stock'] as num?)?.toInt() ?? 0;
                  final bool agotado = stock <= 0;
                  final double inicial = Formatters.r2(precio * _userIniPct);

                  return Container(
                    margin: const EdgeInsets.only(bottom: 12),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: PagobyteColors.card,
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: PagobyteColors.line),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if ((p['imagen_url'] ?? '').toString().trim().isNotEmpty) ...[
                          ClipRRect(
                            borderRadius: BorderRadius.circular(14),
                            child: Image.network(
                              p['imagen_url'].toString(),
                              height: 165,
                              width: double.infinity,
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => const SizedBox.shrink(),
                            ),
                          ),
                          const SizedBox(height: 12),
                        ],
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      if ((p['categoria'] ?? '').toString().isNotEmpty)
                                        PagobyteBadge(label: p['categoria'].toString()),
                                      const SizedBox(width: 6),
                                      GestureDetector(
                                        onTap: () async {
                                          final updated = await SupabaseService.toggleFavoriteProduct((p['id'] ?? '').toString());
                                          if (mounted) setState(() => _favorites = updated);
                                        },
                                        child: Icon(
                                          _favorites.contains((p['id'] ?? '').toString())
                                              ? Icons.favorite_rounded
                                              : Icons.favorite_border_rounded,
                                          size: 20,
                                          color: _favorites.contains((p['id'] ?? '').toString())
                                              ? PagobyteColors.bad
                                              : PagobyteColors.muted,
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    (p['nombre'] ?? '').toString(),
                                    style: PagobyteTheme.heading(16.5),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 10),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Text(
                                  Formatters.usd(precio),
                                  style: PagobyteTheme.mono(20, color: PagobyteColors.byteBlueDark),
                                ),
                                Text(
                                  'Inicial ${Formatters.usd(inicial)}',
                                  style: const TextStyle(
                                    color: PagobyteColors.muted,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                        if ((p['descripcion'] ?? '').toString().isNotEmpty) ...[
                          const SizedBox(height: 6),
                          Text(
                            p['descripcion'].toString(),
                            style: const TextStyle(color: PagobyteColors.muted, fontSize: 13.5, height: 1.35),
                          ),
                        ],
                        const SizedBox(height: 12),
                        if (agotado)
                          OutlinedButton.icon(
                            style: OutlinedButton.styleFrom(
                              minimumSize: const Size(double.infinity, 44),
                              side: const BorderSide(color: PagobyteColors.line),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            ),
                            icon: const Icon(Icons.notifications_active_outlined, size: 18),
                            label: const Text('Agotado — Avisarme cuando vuelva'),
                            onPressed: () async {
                              try {
                                await SupabaseService.registerStockAlert(p['id'].toString());
                                widget.onShowNotice('Listo: te avisaremos apenas vuelva el stock.');
                              } catch (e) {
                                widget.onShowNotice('No se pudo registrar la alerta.');
                              }
                            },
                          )
                        else
                          ElevatedButton(
                            onPressed: bloqueado ? null : () => _openRequestSheet(p),
                            child: Text(bloqueado ? 'Tienes una compra activa' : 'Solicitar en cuotas'),
                          ),
                      ],
                    ),
                  );
                }),
            ],
          );
        },
      ),
    );
  }
}
