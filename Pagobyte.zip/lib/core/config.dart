import 'package:intl/intl.dart';

abstract class AppConfig {
  static const String supabaseUrl = String.fromEnvironment('SUPABASE_URL', defaultValue: 'https://huqyycvdakrlfvqugvvp.supabase.co');
  static const String supabaseAnonKey = String.fromEnvironment('SUPABASE_ANON_KEY', defaultValue: 'sb_publishable_V8aa6DTypFBmJB6mrajhOw_j732ro87');

  // Reglas de recargo sincronizadas con recargo_usd en Supabase
  static const double recargoBaseUsd = 5.0;
  static const double recargoSemanalUsd = 5.0;
  static const int diasGracia = 2;

  static const String appVersion = '1.0.14';
  static const String webUrl = 'https://pagobyte.com';
  static const String terminosVersion = 'v9-2026-11-LEGAL-FULL';

  // Número oficial de soporte WhatsApp (formato internacional sin +)
  static const String whatsappSoporte = '584140000000';
  static const double inicialMinPorcentaje = 0.40;

  static double cupoReferencialPorFase(int fase) {
    switch (fase) {
      case 1:
        return 80.0;
      case 2:
        return 150.0;
      case 3:
        return 250.0;
      case 4:
        return 400.0;
      default:
        return 700.0;
    }
  }

  static double inicialPorcentajePorFase(int fase) {
    if (fase >= 5) return 0.30; // Premio Fase Giga: 30%
    if (fase == 4) return 0.35; // Premio Fase Mega: 35%
    return inicialMinPorcentaje; // Estándar 40%
  }

}

class Formatters {
  static final NumberFormat _numFmt = NumberFormat('#,##0.00', 'es_VE');

  static double r2(num n) => (n * 100).roundToDouble() / 100.0;

  static String usd(num n) => '\$${_numFmt.format(n)}';

  static String bs(num n) => 'Bs ${_numFmt.format(n)}';

  static String diaCorto(String? isoDate) {
    if (isoDate == null || isoDate.isEmpty) return 'Por definir';
    try {
      final dt = DateTime.parse(isoDate);
      const meses = [
        'enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio',
        'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'
      ];
      return '${dt.day} de ${meses[dt.month - 1]}';
    } catch (_) {
      return isoDate;
    }
  }

  static String fechaLarga(String? isoTimestamp) {
    if (isoTimestamp == null || isoTimestamp.isEmpty) return 'Sin registro';
    try {
      final dt = DateTime.parse(isoTimestamp).toLocal();
      const meses = [
        'enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio',
        'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'
      ];
      return '${dt.day} de ${meses[dt.month - 1]} de ${dt.year}';
    } catch (_) {
      return isoTimestamp;
    }
  }

  static String hoyIsoCaracas() {
    final caracas = DateTime.now().toUtc().subtract(const Duration(hours: 4));
    final y = caracas.year.toString().padLeft(4, '0');
    final m = caracas.month.toString().padLeft(2, '0');
    final d = caracas.day.toString().padLeft(2, '0');
    return '$y-$m-$d';
  }

  static String franjaCaracas() {
    final caracas = DateTime.now().toUtc().subtract(const Duration(hours: 4));
    if (caracas.hour < 12) return 'manana';
    if (caracas.hour < 19) return 'tarde';
    return 'noche';
  }

  static double calcularRecargoUsd(String? fechaVencimiento, double montoUsd) {
    if (fechaVencimiento == null || fechaVencimiento.isEmpty) return 0.0;
    try {
      final hoyDt = DateTime.parse(hoyIsoCaracas());
      final venceDt = DateTime.parse(fechaVencimiento);
      final diasAtraso = hoyDt.difference(venceDt).inDays;
      if (diasAtraso < AppConfig.diasGracia) return 0.0;
      final semanasExtra = ((diasAtraso - AppConfig.diasGracia) / 7).floor();
      final calculado = r2(
        AppConfig.recargoBaseUsd + (AppConfig.recargoSemanalUsd * semanasExtra),
      );
      return calculado > montoUsd ? montoUsd : calculado;
    } catch (_) {
      return 0.0;
    }
  }
}
