import 'dart:async';
import 'package:flutter/material.dart';
import '../core/theme.dart';
import '../services/supabase_service.dart';
import '../widgets/pagobyte_logo.dart';

class ByteCodeScreen extends StatefulWidget {
  const ByteCodeScreen({super.key});

  @override
  State<ByteCodeScreen> createState() => _ByteCodeScreenState();
}

class _ByteCodeScreenState extends State<ByteCodeScreen> {
  String? _code;
  int _secondsLeft = 0;
  bool _loading = true;
  String? _error;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _generateNewCode();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _generateNewCode() async {
    _timer?.cancel();
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final res = await SupabaseService.generarByteCode();
      if (!mounted) return;
      setState(() {
        _code = res['codigo'] as String;
        _secondsLeft = 180;
        _loading = false;
      });
      _timer = Timer.periodic(const Duration(seconds: 1), (t) {
        if (!mounted) {
          t.cancel();
          return;
        }
        if (_secondsLeft <= 1) {
          t.cancel();
          setState(() => _secondsLeft = 0);
        } else {
          setState(() => _secondsLeft--);
        }
      });
    } catch (e) {
      if (mounted) {
        setState(() {
          _loading = false;
          _error = 'No se pudo generar el ByteCode: $e';
        });
      }
    }
  }

  String _formatTimer(int sec) {
    final m = (sec ~/ 60).toString().padLeft(2, '0');
    final s = (sec % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: PagobyteColors.ink,
      appBar: AppBar(
        backgroundColor: PagobyteColors.ink,
        foregroundColor: Colors.white,
        elevation: 0,
        title: Text('Mi ByteCode', style: PagobyteTheme.heading(18, color: Colors.white)),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: PagobyteColors.card,
              borderRadius: BorderRadius.circular(22),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const PagobyteLogo(size: 40),
                const SizedBox(height: 12),
                Text('Código de Compra en 1 Toque', style: PagobyteTheme.heading(19)),
                const SizedBox(height: 6),
                const Text(
                  'Díctale estos 6 dígitos al cajero de la Tienda Aliada. Sin cámaras ni QR.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: PagobyteColors.muted, fontSize: 13),
                ),
                const SizedBox(height: 22),
                if (_loading)
                  const CircularProgressIndicator()
                else if (_error != null)
                  Text(_error!, style: const TextStyle(color: PagobyteColors.bad))
                else ...[
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                    decoration: BoxDecoration(
                      color: PagobyteColors.tint,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: PagobyteColors.byteBlue, width: 1.8),
                    ),
                    child: Text(
                      '${_code!.substring(0, 3)} ${_code!.substring(3)}',
                      style: PagobyteTheme.mono(34, color: PagobyteColors.byteBlue),
                    ),
                  ),
                  const SizedBox(height: 14),
                  Text(
                    _secondsLeft > 0
                        ? 'Válido por ${_formatTimer(_secondsLeft)}'
                        : 'Código expirado',
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                      color: _secondsLeft > 0 ? PagobyteColors.ok : PagobyteColors.bad,
                    ),
                  ),
                ],
                const SizedBox(height: 20),
                ElevatedButton.icon(
                  icon: const Icon(Icons.refresh),
                  label: const Text('Generar nuevo ByteCode'),
                  onPressed: _loading ? null : _generateNewCode,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
