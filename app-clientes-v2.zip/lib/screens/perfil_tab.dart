import 'package:flutter/material.dart';
import '../core/config.dart';
import '../core/terms_data.dart';
import '../core/theme.dart';
import '../widgets/ui_kit.dart';
import '../services/security_service.dart';
import '../services/supabase_service.dart';

class PerfilTab extends StatefulWidget {
  const PerfilTab({super.key});

  @override
  State<PerfilTab> createState() => _PerfilTabState();
}

class _PerfilTabState extends State<PerfilTab> {
  late Future<Map<String, dynamic>> _future;
  bool _biometricEnabled = false;
  bool _biometricAvailable = false;

  @override
  void initState() {
    super.initState();
    _future = SupabaseService.fetchPerfilData();
    _loadBiometricState();
  }

  Future<void> _loadBiometricState() async {
    final avail = await SecurityService.canUseDeviceAuth();
    final enabled = await SecurityService.isLockEnabled();
    if (mounted) {
      setState(() {
        _biometricAvailable = avail;
        _biometricEnabled = enabled;
      });
    }
  }

  Future<void> _reload() async {
    setState(() => _future = SupabaseService.fetchPerfilData());
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: _reload,
      child: FutureBuilder<Map<String, dynamic>>(
        future: _future,
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const PagobyteSkeletonList(count: 3, showHero: true);
          }
          if (snap.hasError) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text('No se pudo cargar tu perfil.', style: TextStyle(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 8),
                    ElevatedButton(onPressed: _reload, child: const Text('Reintentar')),
                  ],
                ),
              ),
            );
          }

          final c = snap.data?['cliente'] as Map<String, dynamic>?;
          final fases = List<Map<String, dynamic>>.from(snap.data?['fases'] ?? []);
          if (c == null) {
            return const Center(child: Text('Esta cuenta aún no tiene perfil de cliente.'));
          }

          final int faseActual = (c['fase'] as num?)?.toInt() ?? 1;
          final int puntos = (c['puntos'] as num?)?.toInt() ?? 0;

          Map<String, dynamic>? faseObj;
          Map<String, dynamic>? sigFase;
          for (final f in fases) {
            final numFase = (f['fase'] as num?)?.toInt() ?? 0;
            if (numFase == faseActual) faseObj = f;
            if (numFase == faseActual + 1) sigFase = f;
          }

          final String faseNombre = (faseObj?['nombre'] as String?) ?? 'Bit';
          final int maxCuotas = (faseObj?['max_cuotas'] as num?)?.toInt() ?? 3;

          String metaTxt;
          if (sigFase == null) {
            metaTxt = 'Estás en la fase más alta.';
          } else {
            final int minPts = (sigFase['puntos_minimos'] as num?)?.toInt() ?? 100;
            metaTxt = puntos >= minPts
                ? 'Ya cumples los puntos para la fase ${sigFase['nombre']}. Pagobyte te la confirmará.'
                : 'Te faltan ${minPts - puntos} puntos para la fase ${sigFase['nombre']}.';
          }

          final String nombre = (c['nombre'] ?? 'Cliente').toString();
          final String cedula = (c['cedula'] ?? 'Sin registro').toString();
          final String telefono = (c['telefono'] ?? 'Sin registro').toString();
          final String correo = (c['correo'] ?? SupabaseService.currentUser?.email ?? '').toString();

          return ListView(
            padding: const EdgeInsets.fromLTRB(18, 12, 18, 110),
            children: [
              Container(
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                  color: PagobyteColors.ink,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(nombre, style: PagobyteTheme.heading(24, color: Colors.white)),
                    const SizedBox(height: 8),
                    Text(
                      'Fase $faseActual, $faseNombre: puedes pagar hasta en $maxCuotas cuotas. $metaTxt',
                      style: const TextStyle(color: Color(0xFFC4CDE6), fontSize: 14, height: 1.4),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 14),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: PagobyteColors.card,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: PagobyteColors.line),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _lockedRow('Nombre completo', nombre),
                    _lockedRow('Cédula', cedula),
                    _lockedRow('Teléfono', telefono),
                    _lockedRow('Correo', correo),
                    _lockedRow('Puntos acumulados', '$puntos pts', showLock: false),
                    _lockedRow('Cliente desde', Formatters.fechaLarga(c['creado_en']?.toString()), showLock: false),
                    _lockedRow(
                      'Términos aceptados',
                      c['terminos_version'] != null
                          ? '${c['terminos_version']}'
                          : AppConfig.terminosVersion,
                      showLock: false,
                      isLast: true,
                    ),
                    const SizedBox(height: 10),
                    const Text(
                      'Tu nombre, cédula, teléfono y correo no se pueden cambiar. Son la única forma en que validamos tu identidad y te contactamos. Si hay un error, escríbenos.',
                      style: TextStyle(color: PagobyteColors.muted, fontSize: 12.5),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 14),
              if (_biometricAvailable) ...[
                Container(
                  margin: const EdgeInsets.only(bottom: 14),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                  decoration: BoxDecoration(
                    color: PagobyteColors.card,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: PagobyteColors.line),
                  ),
                  child: SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    activeColor: PagobyteColors.byteBlue,
                    title: const Text(
                      'Bloqueo con huella o PIN',
                      style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
                    ),
                    subtitle: const Text(
                      'Solicita tu huella o PIN del teléfono al abrir Pagobyte.',
                      style: TextStyle(fontSize: 12, color: PagobyteColors.muted),
                    ),
                    value: _biometricEnabled,
                    onChanged: (val) async {
                      if (val) {
                        final ok = await SecurityService.authenticate(
                          reason: 'Verifica tu huella o PIN para activar el bloqueo de Pagobyte',
                        );
                        if (!ok) return;
                      }
                      await SecurityService.setLockEnabled(val);
                      if (mounted) setState(() => _biometricEnabled = val);
                    },
                  ),
                ),
              ],
              ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: PagobyteColors.ok,
                  foregroundColor: Colors.white,
                ),
                icon: const Icon(Icons.chat_outlined),
                label: const Text('Soporte directo por WhatsApp'),
                onPressed: () {
                  SecurityService.openWhatsAppSupport(
                    nombre: nombre,
                    cedula: cedula,
                  );
                },
              ),
              const SizedBox(height: 10),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: PagobyteColors.tint,
                  foregroundColor: PagobyteColors.byteBlue,
                ),
                onPressed: () => showTermsBottomSheet(context),
                child: const Text('Leer Términos y Política de Privacidad'),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _lockedRow(String label, String value, {bool showLock = true, bool isLast = false}) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(
        border: isLast ? null : const Border(bottom: BorderSide(color: PagobyteColors.line)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: PagobyteColors.muted, fontSize: 13)),
          const SizedBox(width: 12),
          Expanded(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Flexible(
                  child: Text(
                    value,
                    textAlign: TextAlign.right,
                    style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
                  ),
                ),
                if (showLock) ...[
                  const SizedBox(width: 6),
                  const Icon(Icons.lock_outline, size: 15, color: PagobyteColors.muted),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}
