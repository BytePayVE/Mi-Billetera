import 'package:flutter/material.dart';
import '../core/config.dart';
import '../core/terms_data.dart';
import '../core/theme.dart';
import '../widgets/pagobyte_logo.dart';

class ContractReadingScreen extends StatefulWidget {
  const ContractReadingScreen({super.key});

  @override
  State<ContractReadingScreen> createState() => _ContractReadingScreenState();
}

class _ContractReadingScreenState extends State<ContractReadingScreen> {
  final ScrollController _scrollCtrl = ScrollController();
  double _progress = 0.0;
  bool _completed = false;
  bool _checked = false;

  @override
  void initState() {
    super.initState();
    _scrollCtrl.addListener(_onScroll);
  }

  void _onScroll() {
    if (!_scrollCtrl.hasClients) return;
    final maxExtent = _scrollCtrl.position.maxScrollExtent;
    if (maxExtent <= 0) {
      setState(() {
        _progress = 1.0;
        _completed = true;
      });
      return;
    }
    final ratio = (_scrollCtrl.offset / maxExtent).clamp(0.0, 1.0);
    if (ratio > _progress) {
      setState(() {
        _progress = ratio;
        if (ratio >= 0.98) {
          _progress = 1.0;
          _completed = true;
        }
      });
    }
  }

  @override
  void dispose() {
    _scrollCtrl.removeListener(_onScroll);
    _scrollCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final int pct = (_progress * 100).round();

    return Scaffold(
      backgroundColor: PagobyteColors.paper,
      appBar: AppBar(
        backgroundColor: PagobyteColors.ink,
        foregroundColor: Colors.white,
        elevation: 0,
        title: Row(
          children: [
            const PagobyteLogo(size: 24, darkSurface: true),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                'Contrato Legal Obligatorio',
                style: PagobyteTheme.heading(17, color: Colors.white),
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          // Barra de progreso de lectura en vivo (0% -> 100%)
          Container(
            width: double.infinity,
            color: PagobyteColors.ink2,
            padding: const EdgeInsets.fromLTRB(18, 12, 18, 14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      _completed
                          ? 'Lectura completada al 100%'
                          : 'Desliza hasta el final para habilitar el registro',
                      style: TextStyle(
                        color: _completed ? PagobyteColors.cyan : const Color(0xFFC4CDE6),
                        fontSize: 12.5,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    Text(
                      '$pct%',
                      style: PagobyteTheme.mono(
                        15,
                        color: _completed ? PagobyteColors.cyan : Colors.white,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                ClipRRect(
                  borderRadius: BorderRadius.circular(999),
                  child: LinearProgressIndicator(
                    value: _progress,
                    minHeight: 8,
                    backgroundColor: Colors.white12,
                    color: _completed ? PagobyteColors.cyan : PagobyteColors.byteBlue,
                  ),
                ),
              ],
            ),
          ),

          // Cuerpo completo del contrato (Términos + Política de Privacidad)
          Expanded(
            child: ListView(
              controller: _scrollCtrl,
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 36),
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: PagobyteColors.card,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: PagobyteColors.line),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'CONTRATO DE ADHESIÓN, TÉRMINOS DE USO Y POLÍTICA DE PROTECCIÓN DE DATOS — PAGOBYTE',
                        style: PagobyteTheme.heading(16),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        'Versión legal: ${AppConfig.terminosVersion} • República Bolivariana de Venezuela',
                        style: const TextStyle(color: PagobyteColors.muted, fontSize: 12),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        'Lee detenidamente cada cláusula. Este documento posee plena validez jurídica conforme al Código Civil, la Ley sobre Mensajes de Datos y Firmas Electrónicas y la Ley Especial contra los Delitos Informáticos.',
                        style: TextStyle(fontSize: 13, height: 1.45),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                Text(
                  'PARTE I — TÉRMINOS Y CONDICIONES DE USO Y COMPROMISO DE PAGO',
                  style: PagobyteTheme.heading(15, color: PagobyteColors.ink),
                ),
                const Divider(height: 20, color: PagobyteColors.byteBlue, thickness: 1.5),
                ...kPagobyteTerms.asMap().entries.map((entry) {
                  final i = entry.key;
                  final sec = entry.value;
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'CLÁUSULA ${i + 1}. ${sec.title}',
                          style: PagobyteTheme.heading(14, color: PagobyteColors.byteBlue),
                        ),
                        const SizedBox(height: 4),
                        ...sec.paragraphs.map(
                          (p) => Padding(
                            padding: const EdgeInsets.only(top: 5),
                            child: Text(
                              p,
                              textAlign: TextAlign.justify,
                              style: const TextStyle(fontSize: 13.5, height: 1.5),
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                }),
                const SizedBox(height: 14),
                Text(
                  'PARTE II — POLÍTICA DE PRIVACIDAD Y PROTECCIÓN DE DATOS PERSONALES',
                  style: PagobyteTheme.heading(15, color: PagobyteColors.ink),
                ),
                const Divider(height: 20, color: PagobyteColors.byteBlue, thickness: 1.5),
                ...kPagobytePrivacy.asMap().entries.map((entry) {
                  final i = entry.key;
                  final sec = entry.value;
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'ARTÍCULO ${i + 1}. ${sec.title}',
                          style: PagobyteTheme.heading(14, color: PagobyteColors.byteBlue),
                        ),
                        const SizedBox(height: 4),
                        ...sec.paragraphs.map(
                          (p) => Padding(
                            padding: const EdgeInsets.only(top: 5),
                            child: Text(
                              p,
                              textAlign: TextAlign.justify,
                              style: const TextStyle(fontSize: 13.5, height: 1.5),
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                }),
                const SizedBox(height: 14),
                Text(
                  'PARTE III — ANEXOS DE GARANTÍAS, COBRANZA Y POLÍTICA ANTIFRAUDE',
                  style: PagobyteTheme.heading(15, color: PagobyteColors.ink),
                ),
                const Divider(height: 20, color: PagobyteColors.byteBlue, thickness: 1.5),
                ...kPagobyteAnexos.map((sec) {
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          sec.title,
                          style: PagobyteTheme.heading(14, color: PagobyteColors.byteBlue),
                        ),
                        const SizedBox(height: 4),
                        ...sec.paragraphs.map(
                          (p) => Padding(
                            padding: const EdgeInsets.only(top: 5),
                            child: Text(
                              p,
                              textAlign: TextAlign.justify,
                              style: const TextStyle(fontSize: 13.5, height: 1.5),
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                }),

                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: PagobyteColors.okBg,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.verified_user, color: PagobyteColors.ok),
                      SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          'Has llegado al final del contrato. Ahora puedes marcar la casilla inferior y aceptar para continuar con tu registro.',
                          style: TextStyle(
                            color: PagobyteColors.ok,
                            fontWeight: FontWeight.w700,
                            fontSize: 12.5,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // Barra inferior fija de aceptación
          Container(
            padding: const EdgeInsets.fromLTRB(18, 12, 18, 20),
            decoration: const BoxDecoration(
              color: PagobyteColors.card,
              border: Border(top: BorderSide(color: PagobyteColors.line)),
            ),
            child: SafeArea(
              top: false,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    children: [
                      Checkbox(
                        value: _checked,
                        activeColor: PagobyteColors.byteBlue,
                        onChanged: _completed
                            ? (v) => setState(() => _checked = v ?? false)
                            : null,
                      ),
                      Expanded(
                        child: Text(
                          _completed
                              ? 'Declaro haber leído el 100% del contrato y acepto sus Términos y Política de Privacidad.'
                              : 'Completa la lectura al 100% ($pct%) para habilitar esta casilla.',
                          style: TextStyle(
                            fontSize: 12.5,
                            fontWeight: FontWeight.w600,
                            color: _completed ? PagobyteColors.ink : PagobyteColors.muted,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  ElevatedButton(
                    onPressed: (_completed && _checked)
                        ? () => Navigator.pop(context, true)
                        : null,
                    child: Text(
                      _completed
                          ? 'Acepto el Contrato y continuar registro'
                          : 'Falta leer el ${100 - pct}% del contrato',
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
