import 'package:flutter/material.dart';
import '../core/config.dart';
import '../core/theme.dart';
import '../services/security_service.dart';
import '../services/supabase_service.dart';
import '../widgets/ui_kit.dart';
import 'bytecode_screen.dart';

class InicioTab extends StatefulWidget {
  final Map<String, dynamic> myProfile;
  final double? tasaBcv;
  final ValueChanged<int> onNavigateTab;

  const InicioTab({
    super.key,
    required this.myProfile,
    required this.tasaBcv,
    required this.onNavigateTab,
  });

  @override
  State<InicioTab> createState() => _InicioTabState();
}

class _InicioTabState extends State<InicioTab> {
  late Future<Map<String, dynamic>> _future;

  @override
  void initState() {
    super.initState();
    _future = SupabaseService.fetchInicioData();
  }

  Future<void> _reload() async {
    setState(() => _future = SupabaseService.fetchInicioData());
  }

  @override
  Widget build(BuildContext context) {
    final firstName = ((widget.myProfile['nombre'] as String?) ?? '')
        .trim()
        .split(' ')
        .first;
    final int faseNum = (widget.myProfile['fase'] as num?)?.toInt() ?? 1;
    final double cupo = AppConfig.cupoReferencialPorFase(faseNum);
    final int iniPct = (AppConfig.inicialPorcentajePorFase(faseNum) * 100).round();

    return RefreshIndicator(
      onRefresh: _reload,
      child: FutureBuilder<Map<String, dynamic>>(
        future: _future,
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const PagobyteSkeletonList(count: 3, showHero: true);
          }
          if (snap.hasError) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text(
                  'No se pudo cargar: ${snap.error}',
                  style: const TextStyle(color: PagobyteColors.bad, fontSize: 15),
                ),
              ),
            );
          }

          final data = snap.data!;
          final String frase = data['frase'] as String;
          final bool tieneOferta = data['tieneOferta'] as bool;
          final Map<String, dynamic>? proxima =
              data['proxima'] as Map<String, dynamic>?;

          return ListView(
            padding: const EdgeInsets.fromLTRB(18, 12, 18, 110),
            children: [
              // Hero azul claro agradable y legible
              Container(
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                  gradient: PagobyteColors.heroGradient,
                  borderRadius: BorderRadius.circular(22),
                  boxShadow: [
                    BoxShadow(
                      color: PagobyteColors.byteBlue.withOpacity(0.24),
                      blurRadius: 20,
                      offset: const Offset(0, 10),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Text(
                            firstName.isNotEmpty ? 'Hola, $firstName' : 'Hola',
                            style: PagobyteTheme.heading(26, color: Colors.white),
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.20),
                            borderRadius: BorderRadius.circular(999),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(Icons.verified_rounded, color: Colors.white, size: 15),
                              const SizedBox(width: 5),
                              Text(
                                'Fase $faseNum',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 12.5,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(
                      frase,
                      style: const TextStyle(
                        color: Color(0xFFE8F2FF),
                        fontSize: 15,
                        height: 1.4,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.16),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: Colors.white.withOpacity(0.32)),
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 42,
                            height: 42,
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.22),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: const Icon(
                              Icons.account_balance_wallet_rounded,
                              color: Colors.white,
                              size: 22,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Row(
                                  children: [
                                    Text(
                                      'CUPO REFERENCIAL',
                                      style: TextStyle(
                                        color: Color(0xFFE0F2FE),
                                        fontSize: 11.5,
                                        fontWeight: FontWeight.w800,
                                        letterSpacing: 0.4,
                                      ),
                                    ),
                                    SizedBox(width: 5),
                                    PagobyteTooltip(
                                      message: 'Monto estimado según tu Fase actual. Sube de Fase pagando a tiempo o adelantando pagos.',
                                      child: Icon(Icons.info_outline_rounded, size: 15, color: Colors.white),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  'Hasta ${Formatters.usd(cupo)}',
                                  style: PagobyteTheme.mono(23, color: Colors.white),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(999),
                            ),
                            child: Text(
                              'Inicial $iniPct%',
                              style: const TextStyle(
                                color: PagobyteColors.byteBlueDark,
                                fontWeight: FontWeight.w800,
                                fontSize: 12.5,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              // Accesos rápidos con íconos claros para todo público
              Row(
                children: [
                  _quickAction(
                    icon: Icons.dialpad_rounded,
                    label: 'ByteCode',
                    color: PagobyteColors.byteBlue,
                    bg: PagobyteColors.softBlueBg,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const ByteCodeScreen()),
                      );
                    },
                  ),
                  const SizedBox(width: 10),
                  _quickAction(
                    icon: Icons.storefront_rounded,
                    label: 'Tienda',
                    color: const Color(0xFF0284C7),
                    bg: const Color(0xFFE0F2FE),
                    onTap: () => widget.onNavigateTab(1),
                  ),
                  const SizedBox(width: 10),
                  _quickAction(
                    icon: Icons.payments_rounded,
                    label: 'Pagos',
                    color: PagobyteColors.ok,
                    bg: PagobyteColors.okBg,
                    onTap: () => widget.onNavigateTab(2),
                  ),
                  const SizedBox(width: 10),
                  _quickAction(
                    icon: Icons.support_agent_rounded,
                    label: 'Ayuda',
                    color: const Color(0xFF7C3AED),
                    bg: const Color(0xFFF3E8FF),
                    onTap: () {
                      SecurityService.openWhatsAppSupport(
                        nombre: (widget.myProfile['nombre'] ?? 'Cliente').toString(),
                        cedula: (widget.myProfile['cedula'] ?? '').toString(),
                        contexto: 'Necesito ayuda con mi cuenta.',
                      );
                    },
                  ),
                ],
              ),
              const SizedBox(height: 16),

              // Banner de Oferta pendiente por aceptar
              if (tieneOferta) ...[
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: PagobyteColors.card,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: PagobyteColors.byteBlue, width: 1.8),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: PagobyteColors.softBlueBg,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: const Icon(Icons.local_offer_rounded, color: PagobyteColors.byteBlue, size: 20),
                          ),
                          const SizedBox(width: 10),
                          const Text(
                            'TIENES UNA OFERTA',
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w800,
                              color: PagobyteColors.byteBlue,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      const Text(
                        'Aprobamos tu solicitud. Revisa las condiciones y acepta tu compromiso para continuar.',
                        style: TextStyle(fontSize: 14.5, height: 1.4),
                      ),
                      const SizedBox(height: 14),
                      ElevatedButton.icon(
                        icon: const Icon(Icons.check_circle_outline_rounded, size: 20),
                        onPressed: () => widget.onNavigateTab(2),
                        label: const Text('Ver mi oferta'),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 14),
              ],

              // Próximo pago o invitación a tienda
              if (proxima != null)
                _buildNextPaymentCard(proxima)
              else if (!tieneOferta)
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: PagobyteColors.card,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: PagobyteColors.line),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: PagobyteColors.softBlueBg,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: const Icon(Icons.event_available_rounded, color: PagobyteColors.byteBlue, size: 20),
                          ),
                          const SizedBox(width: 10),
                          const Text(
                            'TUS PAGOS',
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w800,
                              color: PagobyteColors.muted,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      const Text(
                        'Todavía no tienes compras activas. Elige un producto en la tienda y cuéntanos para qué lo necesitas: lo revisamos y te respondemos aquí.',
                        style: TextStyle(fontSize: 14.5, height: 1.45),
                      ),
                      const SizedBox(height: 14),
                      ElevatedButton.icon(
                        icon: const Icon(Icons.storefront_rounded, size: 20),
                        onPressed: () => widget.onNavigateTab(1),
                        label: const Text('Explorar tienda'),
                      ),
                    ],
                  ),
                ),

              if (widget.tasaBcv != null) ...[
                const SizedBox(height: 14),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  decoration: BoxDecoration(
                    color: PagobyteColors.softBlueBg,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: PagobyteColors.line),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.currency_exchange_rounded, color: PagobyteColors.byteBlue, size: 20),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          'Tasa BCV de referencia: ${Formatters.bs(widget.tasaBcv!)} por dólar',
                          style: PagobyteTheme.mono(
                            13.5,
                            color: PagobyteColors.ink,
                            weight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],

              const SizedBox(height: 14),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: PagobyteColors.card,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: PagobyteColors.line),
                ),
                child: const Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(Icons.info_outline_rounded, color: PagobyteColors.muted, size: 18),
                    SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'Pagobyte no está autorizado por SUDEBAN para intermediar o fungir como pasarela de pagos. Es una plataforma tecnológica que facilita compras a plazo en comercios aliados; los pagos se abonan directamente en las cuentas bancarias de los comercios.',
                        style: TextStyle(
                          color: PagobyteColors.muted,
                          fontSize: 12,
                          height: 1.45,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _quickAction({
    required IconData icon,
    required String label,
    required Color color,
    required Color bg,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: Material(
        color: PagobyteColors.card,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 6),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: PagobyteColors.line),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: bg,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(icon, color: color, size: 22),
                ),
                const SizedBox(height: 6),
                Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 12.5,
                    fontWeight: FontWeight.w700,
                    color: PagobyteColors.ink,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildNextPaymentCard(Map<String, dynamic> c) {
    final compra = c['compras'] as Map<String, dynamic>? ?? {};
    final producto = compra['productos'] as Map<String, dynamic>? ?? {};
    final int numero = (c['numero'] as num).toInt();
    final double montoUsd = (c['monto_usd'] as num).toDouble();
    final String? vence = c['fecha_vencimiento'] as String?;
    final double rec = compra['estado'] == 'activa'
        ? Formatters.calcularRecargoUsd(vence, montoUsd)
        : 0.0;
    final double total = Formatters.r2(montoUsd + rec);

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: PagobyteColors.card,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: PagobyteColors.line),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: PagobyteColors.softBlueBg,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(Icons.payments_rounded, color: PagobyteColors.byteBlue, size: 20),
              ),
              const SizedBox(width: 10),
              Text(
                numero == 0 ? 'TU INICIAL, LO PRIMERO' : 'TU PRÓXIMO PAGO',
                style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                  color: PagobyteColors.muted,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            Formatters.usd(total),
            style: PagobyteTheme.mono(32, color: PagobyteColors.byteBlueDark),
          ),
          const SizedBox(height: 6),
          Text(
            '${rec > 0 ? 'Incluye ${Formatters.usd(rec)} de recargo por atraso. ' : ''}'
            '${widget.tasaBcv != null ? 'Hoy equivale a ${Formatters.bs(total * widget.tasaBcv!)}. ' : ''}'
            '${numero == 0 ? 'Inicial' : 'Pago $numero'} de ${producto['nombre'] ?? 'tu compra'}'
            '${numero == 0 ? '.' : ', vence el ${Formatters.diaCorto(vence)}.'}',
            style: const TextStyle(color: PagobyteColors.muted, fontSize: 14, height: 1.4),
          ),
          const SizedBox(height: 14),
          ElevatedButton.icon(
            icon: const Icon(Icons.upload_file_rounded, size: 20),
            onPressed: () => widget.onNavigateTab(2),
            label: const Text('Ver y reportar pago'),
          ),
        ],
      ),
    );
  }
}
