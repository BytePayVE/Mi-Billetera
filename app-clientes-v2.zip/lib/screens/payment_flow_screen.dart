import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import '../core/config.dart';
import '../core/theme.dart';
import '../services/supabase_service.dart';

class PaymentFlowScreen extends StatefulWidget {
  final Map<String, dynamic> compra;
  final Map<String, dynamic> cuota;
  final double recargoUsd;
  final double? tasaBcv;
  final Map<String, dynamic> myProfile;

  const PaymentFlowScreen({
    super.key,
    required this.compra,
    required this.cuota,
    required this.recargoUsd,
    required this.tasaBcv,
    required this.myProfile,
  });

  @override
  State<PaymentFlowScreen> createState() => _PaymentFlowScreenState();
}

class _PaymentFlowScreenState extends State<PaymentFlowScreen> {
  // 0: Selección, 1: Método, 2: Confirmar banco/monto, 3: Datos con Copiar + Ya pagué, 4: Comprobante
  int _step = 0;
  String _selectedMethod = 'Pago móvil';

  // Datos bancarios del comercio receptor (se adaptan dinámicamente si la compra trae datos de tienda)
  late final String _bankName;
  late final String _rif;
  late final String _phone;

  final _refCtrl = TextEditingController();
  late final TextEditingController _telCtrl;
  late final TextEditingController _cedCtrl;
  Uint8List? _imageBytes;
  String? _imageName;
  bool _sending = false;
  String? _err;

  final _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    _telCtrl = TextEditingController(text: (widget.myProfile['telefono'] ?? '').toString());
    _cedCtrl = TextEditingController(text: (widget.myProfile['cedula'] ?? '').toString());

    _bankName = (widget.compra['banco_destino'] ?? 'Banco de Venezuela (0102)').toString();
    _rif = (widget.compra['rif_destino'] ?? 'J-50037446-1').toString();
    _phone = (widget.compra['telefono_destino'] ?? '0414-1234567').toString();
  }

  @override
  void dispose() {
    _refCtrl.dispose();
    _telCtrl.dispose();
    _cedCtrl.dispose();
    super.dispose();
  }

  double get _baseUsd => (widget.cuota['monto_usd'] as num).toDouble();
  double get _totalUsd => Formatters.r2(_baseUsd + widget.recargoUsd);
  double get _totalBs => widget.tasaBcv != null ? Formatters.r2(_totalUsd * widget.tasaBcv!) : 0.0;
  int get _numero => (widget.cuota['numero'] as num).toInt();

  void _copy(String label, String value) {
    Clipboard.setData(ClipboardData(text: value));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('$label copiado'),
        duration: const Duration(seconds: 2),
        backgroundColor: PagobyteColors.ink,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  Future<void> _submitPayment() async {
    if (_refCtrl.text.trim().length < 4) {
      setState(() => _err = 'Ingresa un número de referencia válido.');
      return;
    }
    if (_imageBytes == null) {
      setState(() => _err = 'Sube la captura del comprobante.');
      return;
    }
    setState(() {
      _sending = true;
      _err = null;
    });
    try {
      await SupabaseService.reportarPago(
        cuotaId: widget.cuota['id'] as String,
        metodo: _selectedMethod,
        referencia: _refCtrl.text,
        telefono: _telCtrl.text,
        cedula: _cedCtrl.text,
        fechaIso: Formatters.hoyIsoCaracas(),
        imageBytes: _imageBytes!,
      );
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      setState(() {
        _sending = false;
        _err = e.toString();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final titles = [
      'Selección de cuota',
      'Método de pago',
      'Confirmar destino',
      'Último paso',
      'Reportar comprobante',
    ];

    return Scaffold(
      backgroundColor: PagobyteColors.paper,
      appBar: AppBar(
        backgroundColor: PagobyteColors.card,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: PagobyteColors.ink),
          onPressed: () {
            if (_step > 0) {
              setState(() => _step--);
            } else {
              Navigator.pop(context, false);
            }
          },
        ),
        title: Text(titles[_step], style: PagobyteTheme.heading(18)),
      ),
      body: Column(
        children: [
          // Indicador de progreso superior
          LinearProgressIndicator(
            value: (_step + 1) / 5,
            backgroundColor: PagobyteColors.line,
            color: PagobyteColors.byteBlue,
            minHeight: 3,
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: _buildCurrentStep(),
            ),
          ),
          if (_step < 4) _buildBottomBar(),
        ],
      ),
    );
  }

  Widget _buildCurrentStep() {
    switch (_step) {
      case 0:
        return _stepSelection();
      case 1:
        return _stepMethod();
      case 2:
        return _stepConfirmBank();
      case 3:
        return _stepCopyDetails();
      default:
        return _stepUploadProof();
    }
  }

  // PASO 1: Selección de cuota
  Widget _stepSelection() {
    final prodName = ((widget.compra['productos'] as Map<String, dynamic>?)?['nombre'] ?? 'Compra Pagobyte').toString();
    final totalCompra = (widget.compra['total_usd'] as num?)?.toDouble() ?? _totalUsd;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('¿Cuánto vas a pagar?', style: PagobyteTheme.heading(24)),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: PagobyteColors.card,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: PagobyteColors.line),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: PagobyteColors.tint,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(Icons.storefront, color: PagobyteColors.byteBlue, size: 20),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(prodName, style: PagobyteTheme.heading(16)),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Total de la orden', style: TextStyle(color: PagobyteColors.muted, fontSize: 13)),
                  Text(Formatters.usd(totalCompra), style: PagobyteTheme.mono(13.5)),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: PagobyteColors.card,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: PagobyteColors.byteBlue, width: 1.8),
          ),
          child: Row(
            children: [
              const Icon(Icons.radio_button_checked, color: PagobyteColors.byteBlue),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _numero == 0 ? 'Cuota Inicial' : 'Cuota $_numero',
                      style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
                    ),
                    if (widget.recargoUsd > 0)
                      Text(
                        'Incluye ${Formatters.usd(widget.recargoUsd)} de recargo por atraso',
                        style: const TextStyle(color: PagobyteColors.bad, fontSize: 12),
                      ),
                  ],
                ),
              ),
              Text(Formatters.usd(_totalUsd), style: PagobyteTheme.mono(16, color: PagobyteColors.byteBlue)),
            ],
          ),
        ),
      ],
    );
  }

  // PASO 2: Método de pago
  Widget _stepMethod() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('¿Cómo vas a pagar?', style: PagobyteTheme.heading(24)),
        const SizedBox(height: 16),
        _methodCard('Pago móvil', 'Confirmación rápida al BCV', Icons.phone_android),
        const SizedBox(height: 12),
        _methodCard('Transferencia', 'Puede demorar hasta 48 hrs', Icons.swap_horiz),
        const SizedBox(height: 12),
        _methodCard('Otro', 'Depósito o método acordado', Icons.account_balance_wallet_outlined),
      ],
    );
  }

  Widget _methodCard(String title, String subtitle, IconData icon) {
    final bool selected = _selectedMethod == title;
    return GestureDetector(
      onTap: () => setState(() {
        _selectedMethod = title;
        _step = 2;
      }),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: PagobyteColors.card,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: selected ? PagobyteColors.byteBlue : PagobyteColors.line,
            width: selected ? 1.8 : 1.2,
          ),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: selected ? PagobyteColors.tint : PagobyteColors.paper,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: selected ? PagobyteColors.byteBlue : PagobyteColors.ink),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                  Text(subtitle, style: const TextStyle(color: PagobyteColors.muted, fontSize: 12.5)),
                ],
              ),
            ),
            const Icon(Icons.chevron_right, color: PagobyteColors.muted),
          ],
        ),
      ),
    );
  }

  // PASO 3: Confirmar banco destino y monto
  Widget _stepConfirmBank() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Confirma el banco de destino y el monto', style: PagobyteTheme.heading(23)),
        const SizedBox(height: 20),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: PagobyteColors.card,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: PagobyteColors.line),
          ),
          child: Column(
            children: [
              Row(
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: PagobyteColors.tint,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(Icons.account_balance, color: PagobyteColors.byteBlue),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Banco destino', style: TextStyle(color: PagobyteColors.muted, fontSize: 12.5)),
                        Text(_bankName, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                      ],
                    ),
                  ),
                ],
              ),
              const Divider(height: 26, color: PagobyteColors.line),
              Row(
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: PagobyteColors.tint,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(Icons.payments_outlined, color: PagobyteColors.byteBlue),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Monto exacto', style: TextStyle(color: PagobyteColors.muted, fontSize: 12.5)),
                        Text(
                          widget.tasaBcv != null
                              ? '${Formatters.bs(_totalBs)} (${Formatters.usd(_totalUsd)})'
                              : Formatters.usd(_totalUsd),
                          style: PagobyteTheme.mono(15.5, color: PagobyteColors.ink),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  // PASO 4: Último paso (Datos con botones Copiar + Copiar todos + Ya pagué)
  Widget _stepCopyDetails() {
    final montoStr = widget.tasaBcv != null
        ? '${Formatters.bs(_totalBs)} / ${Formatters.usd(_totalUsd)}'
        : Formatters.usd(_totalUsd);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Los comercios tienen datos bancarios únicos. Asegúrate de realizar tu pago directamente a esta cuenta.',
          style: TextStyle(color: PagobyteColors.muted, fontSize: 13.5),
        ),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: PagobyteColors.tint,
            borderRadius: BorderRadius.circular(999),
          ),
          child: const Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.verified, size: 15, color: PagobyteColors.byteBlue),
              SizedBox(width: 6),
              Text(
                'Cuenta verificada del comercio',
                style: TextStyle(color: PagobyteColors.byteBlue, fontWeight: FontWeight.w700, fontSize: 12),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: PagobyteColors.card,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: PagobyteColors.line),
          ),
          child: Column(
            children: [
              _copyRow('Destino', _bankName, _bankName),
              const Divider(height: 20, color: PagobyteColors.line),
              _copyRow('RIF', _rif, _rif),
              const Divider(height: 20, color: PagobyteColors.line),
              _copyRow('Teléfono', _phone, _phone),
              const Divider(height: 20, color: PagobyteColors.line),
              _copyRow('Monto', montoStr, widget.tasaBcv != null ? _totalBs.toStringAsFixed(2) : _totalUsd.toStringAsFixed(2)),
            ],
          ),
        ),
        const SizedBox(height: 14),
        OutlinedButton.icon(
          style: OutlinedButton.styleFrom(
            side: const BorderSide(color: PagobyteColors.line),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(999)),
          ),
          icon: const Icon(Icons.copy_all, size: 18, color: PagobyteColors.ink),
          label: const Text('Copiar todos', style: TextStyle(color: PagobyteColors.ink, fontWeight: FontWeight.w700)),
          onPressed: () {
            _copy(
              'Todos los datos',
              'Banco: $_bankName\nRIF: $_rif\nTeléfono: $_phone\nMonto: $montoStr',
            );
          },
        ),
      ],
    );
  }

  Widget _copyRow(String label, String displayVal, String copyVal) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13.5)),
              const SizedBox(height: 2),
              Text(displayVal, style: const TextStyle(color: PagobyteColors.muted, fontSize: 14)),
            ],
          ),
        ),
        TextButton(
          onPressed: () => _copy(label, copyVal),
          child: const Text(
            'Copiar',
            style: TextStyle(
              color: PagobyteColors.byteBlue,
              fontWeight: FontWeight.w700,
              decoration: TextDecoration.underline,
            ),
          ),
        ),
      ],
    );
  }

  // PASO 5: Subir referencia y captura tras pulsar "Ya pagué"
  Widget _stepUploadProof() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Registra tu comprobante', style: PagobyteTheme.heading(22)),
        const SizedBox(height: 6),
        const Text(
          'Ingresa los datos del pago que acabas de realizar para que Pagobyte lo verifique.',
          style: TextStyle(color: PagobyteColors.muted, fontSize: 13.5),
        ),
        const SizedBox(height: 16),
        TextField(
          controller: _refCtrl,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'Número de referencia'),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _telCtrl,
          keyboardType: TextInputType.phone,
          decoration: const InputDecoration(labelText: 'Teléfono desde el que pagaste'),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _cedCtrl,
          decoration: const InputDecoration(labelText: 'Cédula del titular de la cuenta'),
        ),
        const SizedBox(height: 14),
        OutlinedButton.icon(
          style: OutlinedButton.styleFrom(
            minimumSize: const Size(double.infinity, 50),
            side: const BorderSide(color: PagobyteColors.byteBlue),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
          icon: const Icon(Icons.upload_file),
          label: Text(
            _imageName != null ? 'Comprobante: $_imageName' : 'Subir foto o captura del pago',
            overflow: TextOverflow.ellipsis,
          ),
          onPressed: () async {
            final picked = await _picker.pickImage(
              source: ImageSource.gallery,
              maxWidth: 1280,
              imageQuality: 82,
            );
            if (picked != null) {
              final bytes = await picked.readAsBytes();
              setState(() {
                _imageBytes = bytes;
                _imageName = picked.name;
              });
            }
          },
        ),
        if (_err != null) ...[
          const SizedBox(height: 10),
          Text(_err!, style: const TextStyle(color: PagobyteColors.bad, fontWeight: FontWeight.w600)),
        ],
        const SizedBox(height: 18),
        ElevatedButton(
          onPressed: _sending ? null : _submitPayment,
          child: Text(_sending ? 'Enviando...' : 'Enviar para verificación'),
        ),
      ],
    );
  }

  Widget _buildBottomBar() {
    final String btnLabel = _step == 3 ? 'Ya pagué' : 'Continuar';
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 14, 20, 22),
      decoration: const BoxDecoration(
        color: PagobyteColors.card,
        border: Border(top: BorderSide(color: PagobyteColors.line)),
      ),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Total', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                Text(
                  widget.tasaBcv != null
                      ? '${Formatters.bs(_totalBs)} / ${Formatters.usd(_totalUsd)}'
                      : Formatters.usd(_totalUsd),
                  style: PagobyteTheme.mono(15, color: PagobyteColors.ink),
                ),
              ],
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: PagobyteColors.ink,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(999)),
              ),
              onPressed: () => setState(() => _step++),
              child: Text(btnLabel),
            ),
          ],
        ),
      ),
    );
  }
}
