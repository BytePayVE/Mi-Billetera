import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../core/config.dart';
import '../core/theme.dart';
import '../widgets/pagobyte_logo.dart';

class SolvencyCertificateScreen extends StatelessWidget {
  final Map<String, dynamic> compra;
  final Map<String, dynamic> myProfile;

  const SolvencyCertificateScreen({
    super.key,
    required this.compra,
    required this.myProfile,
  });

  @override
  Widget build(BuildContext context) {
    final String compraId = (compra['id'] ?? '').toString();
    final String certCode = 'PB-SOLV-${compraId.length >= 8 ? compraId.substring(0, 8).toUpperCase() : compraId.toUpperCase()}';
    final String prodName = ((compra['productos'] as Map<String, dynamic>?)?['nombre'] ?? 'Producto Pagobyte').toString();
    final double totalUsd = (compra['total_usd'] as num?)?.toDouble() ?? 0.0;
    final String nombre = (myProfile['nombre'] ?? 'Cliente Pagobyte').toString();
    final String cedula = (myProfile['cedula'] ?? '').toString();
    final String fechaHoy = Formatters.fechaLarga(DateTime.now().toIso8601String());

    return Scaffold(
      backgroundColor: PagobyteColors.paper,
      appBar: AppBar(
        backgroundColor: PagobyteColors.paper,
        elevation: 0,
        title: Text('Certificado de Solvencia', style: PagobyteTheme.heading(18)),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Container(
              width: double.infinity,
              decoration: BoxDecoration(
                color: PagobyteColors.card,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: PagobyteColors.byteBlue, width: 1.8),
              ),
              child: Column(
                children: [
                  // Encabezado oficial
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(20),
                    decoration: const BoxDecoration(
                      color: PagobyteColors.ink,
                      borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
                    ),
                    child: Column(
                      children: [
                        const Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            PagobyteLogo(size: 34, darkSurface: true),
                            SizedBox(width: 10),
                            PagobyteWordmark(fontSize: 26, darkSurface: true),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                          decoration: BoxDecoration(
                            color: PagobyteColors.cyan.withOpacity(0.18),
                            borderRadius: BorderRadius.circular(999),
                          ),
                          child: const Text(
                            'CERTIFICADO DE SOLVENCIA DIGITAL',
                            style: TextStyle(
                              color: PagobyteColors.cyan,
                              fontWeight: FontWeight.w800,
                              fontSize: 11.5,
                              letterSpacing: 0.8,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Center(
                          child: Icon(Icons.verified, color: PagobyteColors.ok, size: 46),
                        ),
                        const SizedBox(height: 10),
                        const Center(
                          child: Text(
                            'OBLIGACIÓN SALDADA AL 100%',
                            style: TextStyle(
                              color: PagobyteColors.ok,
                              fontWeight: FontWeight.w800,
                              fontSize: 14,
                            ),
                          ),
                        ),
                        const SizedBox(height: 14),
                        Text(
                          'La Organización PAGOBYTE hace constar que el titular identificado a continuación ha cumplido satisfactoriamente con el pago total de la cuota inicial y todas las cuotas correspondientes a su compra, quedando totalmente solvente y habilitado para nuevas solicitudes.',
                          textAlign: TextAlign.justify,
                          style: const TextStyle(fontSize: 13.5, height: 1.5),
                        ),
                        const Divider(height: 26, color: PagobyteColors.line),
                        _infoRow('Titular', nombre),
                        _infoRow('Cédula de Identidad', cedula),
                        _infoRow('Producto adquirido', prodName),
                        _infoRow('Monto total saldado', Formatters.usd(totalUsd)),
                        _infoRow('Código de verificación', certCode, isMono: true),
                        _infoRow('Fecha de emisión', fechaHoy),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            ElevatedButton.icon(
              icon: const Icon(Icons.copy),
              label: const Text('Copiar código de solvencia'),
              onPressed: () {
                Clipboard.setData(ClipboardData(text: certCode));
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Código de solvencia copiado al portapapeles.'),
                    backgroundColor: PagobyteColors.ink,
                    behavior: SnackBarBehavior.floating,
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _infoRow(String label, String value, {bool isMono = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: PagobyteColors.muted, fontSize: 12.5)),
          const SizedBox(width: 10),
          Flexible(
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: isMono
                  ? PagobyteTheme.mono(13, color: PagobyteColors.byteBlue)
                  : const TextStyle(fontWeight: FontWeight.w700, fontSize: 13.5),
            ),
          ),
        ],
      ),
    );
  }
}
