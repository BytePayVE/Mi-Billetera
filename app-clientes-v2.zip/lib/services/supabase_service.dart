import 'dart:typed_data';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../core/config.dart';

class SupabaseService {
  static SupabaseClient get client => Supabase.instance.client;

  static User? get currentUser => client.auth.currentUser;

  static Future<void> signIn(String email, String password) async {
    await client.auth.signInWithPassword(
      email: email.trim(),
      password: password,
    );
  }

  static Future<AuthResponse> signUpClient({
    required String nombre,
    required String cedula,
    required String telefono,
    required String email,
    required String password,
    required String estado,
    required String ciudad,
    required String tipoZona,
    required String direccionDetalle,
    required Uint8List cedulaPhotoBytes,
    required Uint8List selfiePhotoBytes,
  }) async {
    if (cedulaPhotoBytes.lengthInBytes > 5 * 1024 * 1024 || selfiePhotoBytes.lengthInBytes > 5 * 1024 * 1024) {
      throw Exception('Las fotografías no pueden superar los 5 MB cada una.');
    }
    final cleanCed = cedula.trim().toUpperCase();
    final ts = DateTime.now().millisecondsSinceEpoch;
    final cedPath = 'kyc/${cleanCed}_cedula_$ts.jpg';
    final selfiePath = 'kyc/${cleanCed}_selfie_$ts.jpg';

    // Subir evidencias KYC al bucket kyc_documentos (si no existe, usa comprobantes como respaldo)
    String finalCedPath = cedPath;
    String finalSelfiePath = selfiePath;
    try {
      await client.storage.from('kyc_documentos').uploadBinary(
            cedPath,
            cedulaPhotoBytes,
            fileOptions: const FileOptions(contentType: 'image/jpeg'),
          );
      await client.storage.from('kyc_documentos').uploadBinary(
            selfiePath,
            selfiePhotoBytes,
            fileOptions: const FileOptions(contentType: 'image/jpeg'),
          );
    } catch (_) {
      // Respaldo en metadata si el bucket aún no fue creado en Supabase
      finalCedPath = 'pendiente_bucket_$cedPath';
      finalSelfiePath = 'pendiente_bucket_$selfiePath';
    }

    final res = await client.auth.signUp(
      email: email.trim(),
      password: password,
      data: {
        'nombre': nombre.trim(),
        'cedula': cleanCed,
        'telefono': telefono.trim(),
        'estado': estado.trim(),
        'ciudad': ciudad.trim(),
        'tipo_zona': tipoZona.trim(),
        'direccion_detalle': direccionDetalle.trim(),
        'foto_cedula_path': finalCedPath,
        'foto_selfie_path': finalSelfiePath,
        'terminos': AppConfig.terminosVersion,
      },
    );

    // Si la sesión quedó activa inmediatamente, actualizar también la tabla clientes
    if (res.user != null && res.session != null) {
      try {
        await client.from('clientes').update({
          'estado': estado.trim(),
          'ciudad': ciudad.trim(),
          'tipo_zona': tipoZona.trim(),
          'direccion_detalle': direccionDetalle.trim(),
          'foto_cedula_path': finalCedPath,
          'foto_selfie_path': finalSelfiePath,
        }).eq('id', res.user!.id);
      } catch (_) {}
    }

    return res;
  }


  static Future<void> sendPasswordResetOtp(String email) async {
    await client.auth.resetPasswordForEmail(email.trim());
  }

  static Future<void> verifyRecoveryOtpAndUpdatePassword({
    required String email,
    required String token,
    required String newPassword,
  }) async {
    await client.auth.verifyOTP(
      type: OtpType.recovery,
      email: email.trim(),
      token: token.trim(),
    );
    await client.auth.updateUser(
      UserAttributes(password: newPassword),
    );
  }

  static Future<void> signOut() async {
    await client.auth.signOut();
  }

  static Future<Map<String, dynamic>?> fetchMyBasicProfile() async {
    final user = currentUser;
    if (user == null) return null;
    try {
      final cli = await client
          .from('clientes')
          .select('nombre, cedula, telefono, fase')
          .eq('id', user.id)
          .maybeSingle();
      if (cli == null) return null;
      final int fase = (cli['fase'] as num?)?.toInt() ?? 1;
      int maxCuotas = 3;
      String faseNombre = 'Bit';
      try {
        final f = await client
            .from('fases')
            .select('nombre, max_cuotas')
            .eq('fase', fase)
            .maybeSingle();
        if (f != null) {
          maxCuotas = (f['max_cuotas'] as num?)?.toInt() ?? 3;
          faseNombre = (f['nombre'] ?? 'Bit').toString();
        }
      } catch (_) {}
      return {
        ...cli,
        'max_cuotas': maxCuotas,
        'fase_nombre': faseNombre,
      };
    } catch (_) {
      return await client
          .from('clientes')
          .select('nombre, cedula, telefono')
          .eq('id', user.id)
          .maybeSingle();
    }
  }



  static Future<void> suscribirAlertaStock(String productoId) async {
    final user = currentUser;
    if (user == null) throw Exception('Debes iniciar sesión.');
    await client.from('alertas_stock').upsert(
      {
        'cliente_id': user.id,
        'producto_id': productoId,
        'notificado': false,
      },
      onConflict: 'cliente_id,producto_id',
    );
  }

  static Future<Map<String, dynamic>> generarByteCode() async {
    final user = currentUser;
    if (user == null) throw Exception('Debes iniciar sesión.');
    final rand = 100000 + (DateTime.now().microsecondsSinceEpoch % 900000);
    final code = rand.toString();
    final expira = DateTime.now().toUtc().add(const Duration(minutes: 3)).toIso8601String();
    await client.from('bytecodes_compra').insert({
      'cliente_id': user.id,
      'codigo': code,
      'expira_en': expira,
    });
    return {'codigo': code, 'expira_en': expira};
  }

  static Future<Map<String, dynamic>?> fetchProductById(String productoId) async {
    return await client
        .from('productos')
        .select('id, nombre, descripcion, categoria, precio_usd, stock, max_cuotas')
        .eq('id', productoId)
        .maybeSingle();
  }

  static Future<double?> fetchLatestBcvRate() async {
    final res = await client
        .from('tasas_bcv')
        .select('tasa_bs')
        .order('fecha', ascending: false)
        .limit(1);
    if (res.isEmpty) return null;
    return (res.first['tasa_bs'] as num?)?.toDouble();
  }

  static Future<Map<String, dynamic>> fetchInicioData() async {
    final franja = Formatters.franjaCaracas();
    final results = await Future.wait([
      client.from('saludos').select('mensaje').eq('franja', franja),
      client
          .from('cuotas')
          .select('numero, monto_usd, fecha_vencimiento, compras!inner(estado, productos(nombre))')
          .inFilter('estado', ['pendiente', 'vencida'])
          .inFilter('compras.estado', ['esperando_inicial', 'activa'])
          .order('fecha_vencimiento')
          .limit(10),
      client.from('compras').select('id').eq('estado', 'por_aceptar'),
    ]);

    final saludos = List<Map<String, dynamic>>.from(results[0] as List);
    final cuotas = List<Map<String, dynamic>>.from(results[1] as List);
    final ofertas = List<Map<String, dynamic>>.from(results[2] as List);

    final String frase = saludos.isNotEmpty
        ? (saludos[DateTime.now().millisecond % saludos.length]['mensaje'] as String)
        : 'Qué gusto verte por aquí.';

    Map<String, dynamic>? proxima;
    for (final q in cuotas) {
      final compra = q['compras'] as Map<String, dynamic>?;
      if (compra?['estado'] == 'activa' || q['numero'] == 0) {
        proxima = q;
        break;
      }
    }

    return {
      'frase': frase,
      'proxima': proxima,
      'tieneOferta': ofertas.isNotEmpty,
    };
  }

  static Future<Map<String, dynamic>> fetchTiendaData() async {
    final results = await Future.wait([
      client
          .from('productos')
          .select('id, nombre, descripcion, categoria, precio_usd, stock, max_cuotas')
          .order('nombre'),
      client
          .from('compras')
          .select('id')
          .inFilter('estado', ['por_aceptar', 'esperando_inicial', 'activa']),
      client.from('solicitudes').select('id').eq('estado', 'pendiente'),
    ]);

    final productos = List<Map<String, dynamic>>.from(results[0] as List);
    final comprasEnCurso = (results[1] as List).length;
    final solicitudesPend = (results[2] as List).length;

    return {
      'productos': productos,
      'bloqueado': (comprasEnCurso + solicitudesPend) > 0,
    };
  }

  static Future<Map<String, dynamic>> fetchCuotasData() async {
    final results = await Future.wait([
      client
          .from('compras')
          .select('id, total_usd, inicial_usd, numero_cuotas, cantidad, productos(nombre)')
          .eq('estado', 'por_aceptar'),
      client
          .from('solicitudes')
          .select('id, estado, nota_admin, cantidad, creada_en, productos(nombre)')
          .inFilter('estado', ['pendiente', 'rechazada'])
          .order('creada_en', ascending: false)
          .limit(5),
      client
          .from('compras')
          .select('id, estado, total_usd, productos(nombre), cuotas(id, numero, monto_usd, estado, fecha_vencimiento)')
          .inFilter('estado', ['esperando_inicial', 'activa', 'pagada'])
          .order('creado_en', ascending: false),
    ]);

    return {
      'ofertas': List<Map<String, dynamic>>.from(results[0] as List),
      'solicitudes': List<Map<String, dynamic>>.from(results[1] as List),
      'compras': List<Map<String, dynamic>>.from(results[2] as List),
    };
  }

  static Future<Map<String, dynamic>> fetchPerfilData() async {
    final user = currentUser;
    if (user == null) return {'cliente': null, 'fases': []};

    Map<String, dynamic>? cliente;
    List<Map<String, dynamic>> fases = [];

    try {
      cliente = await client
          .from('clientes')
          .select('*')
          .eq('id', user.id)
          .maybeSingle();
    } catch (_) {
      cliente = {
        'nombre': user.userMetadata?['nombre'] ?? 'Cliente Pagobyte',
        'cedula': user.userMetadata?['cedula'] ?? 'Sin registrar',
        'telefono': user.userMetadata?['telefono'] ?? 'Sin registrar',
        'correo': user.email ?? '',
        'fase': 1,
        'puntos': 0,
      };
    }

    try {
      final resFases = await client
          .from('fases')
          .select('*')
          .order('fase');
      fases = List<Map<String, dynamic>>.from(resFases as List);
    } catch (_) {
      fases = [
        {'fase': 1, 'nombre': 'Bit', 'max_cuotas': 3, 'puntos_minimos': 0},
        {'fase': 2, 'nombre': 'Byte', 'max_cuotas': 4, 'puntos_minimos': 70},
        {'fase': 3, 'nombre': 'Kilo', 'max_cuotas': 5, 'puntos_minimos': 150},
        {'fase': 4, 'nombre': 'Mega', 'max_cuotas': 6, 'puntos_minimos': 250},
        {'fase': 5, 'nombre': 'Giga', 'max_cuotas': 9, 'puntos_minimos': 400},
      ];
    }

    return {
      'cliente': cliente,
      'fases': fases,
    };
  }

  static Future<void> solicitarProducto({
    required String productoId,
    required int cantidad,
    required String motivo,
  }) async {
    await client.rpc('solicitar_producto', params: {
      'p_producto_id': productoId,
      'p_cantidad': cantidad,
      'p_motivo': motivo.trim(),
    });
  }

  static Future<void> aceptarCompra(String compraId) async {
    await client.rpc('aceptar_compra', params: {
      'p_compra_id': compraId,
      'p_terminos': AppConfig.terminosVersion,
    });
  }

  static Future<void> reportarPago({
    required String cuotaId,
    required String metodo,
    required String referencia,
    required String telefono,
    required String cedula,
    required String fechaIso,
    required Uint8List imageBytes,
  }) async {
    final user = currentUser;
    if (user == null) throw Exception('Sesión expirada.');

    final path = '${user.id}/${DateTime.now().millisecondsSinceEpoch}.jpg';
    await client.storage.from('comprobantes').uploadBinary(
          path,
          imageBytes,
          fileOptions: const FileOptions(contentType: 'image/jpeg'),
        );

    String cleanCed = cedula.toUpperCase().replaceAll(RegExp(r'[^VE0-9]'), '');
    if (RegExp(r'^\d').hasMatch(cleanCed)) cleanCed = 'V$cleanCed';

    await client.rpc('reportar_pago', params: {
      'p_cuota_id': cuotaId,
      'p_metodo': metodo,
      'p_referencia': referencia.trim(),
      'p_telefono': telefono.replaceAll(RegExp(r'[^\d+]'), ''),
      'p_cedula': cleanCed,
      'p_fecha': fechaIso,
      'p_comprobante': path,
    });
  }
}
