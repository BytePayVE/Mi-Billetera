import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/services.dart';
import 'package:local_auth/local_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import '../core/config.dart';

class SecurityService {
  static final LocalAuthentication _auth = LocalAuthentication();
  static const String _prefKey = 'pagobyte_biometric_lock_enabled';

  static Future<bool> isLockEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_prefKey) ?? false;
  }

  static Future<void> setLockEnabled(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_prefKey, enabled);
  }

  static Future<bool> canUseDeviceAuth() async {
    if (kIsWeb) return false;
    try {
      final canCheck = await _auth.canCheckBiometrics;
      final isSupported = await _auth.isDeviceSupported();
      return canCheck || isSupported;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> authenticate({
    String reason = 'Confirma tu identidad para acceder a Pagobyte',
  }) async {
    if (kIsWeb) return true;
    try {
      return await _auth.authenticate(
        localizedReason: reason,
        options: const AuthenticationOptions(
          stickyAuth: true,
          biometricOnly: false,
        ),
      );
    } on PlatformException {
      return false;
    } catch (_) {
      return false;
    }
  }


  static Future<bool> openGoogleCalendarReminder({
    required String titulo,
    required String detalles,
    required String fechaIso, // YYYY-MM-DD
  }) async {
    final cleanDate = fechaIso.replaceAll('-', '');
    if (cleanDate.length != 8) return false;
    final datesParam = '${cleanDate}T130000Z/${cleanDate}T140000Z';
    final uri = Uri.parse(
      'https://calendar.google.com/calendar/render?action=TEMPLATE'
      '&text=${Uri.encodeComponent(titulo)}'
      '&details=${Uri.encodeComponent(detalles)}'
      '&dates=$datesParam',
    );
    try {
      return await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {
      return false;
    }
  }

  static Future<bool> openWhatsAppSupport({
    required String nombre,
    required String cedula,
    String? contexto,
  }) async {
    final msg = StringBuffer()
      ..write('Hola equipo de Pagobyte, soy $nombre (C.I.: $cedula). ');
    if (contexto != null && contexto.isNotEmpty) {
      msg.write(contexto);
    } else {
      msg.write('Necesito asistencia con mi cuenta.');
    }
    final uri = Uri.parse(
      'https://wa.me/${AppConfig.whatsappSoporte}?text=${Uri.encodeComponent(msg.toString())}',
    );
    try {
      return await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {
      return false;
    }
  }
}
