import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class NotificationService {
  static final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();
  static RealtimeChannel? _channel;
  static bool _initialized = false;

  static Future<void> init() async {
    if (_initialized) return;
    if (kIsWeb) {
      _initialized = true;
      return;
    }
    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const settings = InitializationSettings(android: androidInit);
    await _plugin.initialize(settings);

    try {
      final status = await Permission.notification.status;
      if (status.isDenied) {
        await Permission.notification.request();
      }
    } catch (_) {}

    _initialized = true;
  }

  static Future<void> showLocal({
    required int id,
    required String title,
    required String body,
  }) async {
    if (kIsWeb) return;
    const androidDetails = AndroidNotificationDetails(
      'pagobyte_alerts',
      'Alertas Pagobyte',
      channelDescription: 'Notificaciones de cuotas, ofertas y pagos verificados',
      importance: Importance.max,
      priority: Priority.high,
    );
    const details = NotificationDetails(android: androidDetails);
    await _plugin.show(id, title, body, details);
  }

  static void subscribeToSupabaseNotifications({
    required String userId,
    required void Function(Map<String, dynamic> notif) onNewNotification,
  }) {
    unsubscribe();
    final client = Supabase.instance.client;
    _channel = client
        .channel('notificaciones_cliente_$userId')
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'notificaciones',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'cliente_id',
            value: userId,
          ),
          callback: (payload) {
            final record = payload.newRecord;
            if (record.isEmpty) return;
            final title = (record['titulo'] ?? 'Pagobyte').toString();
            final body = (record['mensaje'] ?? '').toString();
            showLocal(
              id: DateTime.now().millisecondsSinceEpoch.remainder(100000),
              title: title,
              body: body,
            );
            onNewNotification(record);
          },
        )
        .subscribe();
  }

  static void unsubscribe() {
    if (_channel != null) {
      Supabase.instance.client.removeChannel(_channel!);
      _channel = null;
    }
  }

  static Future<List<Map<String, dynamic>>> fetchMyNotifications() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) return [];
    try {
      final res = await Supabase.instance.client
          .from('notificaciones')
          .select('*')
          .eq('cliente_id', user.id)
          .order('creada_en', ascending: false)
          .limit(30);
      return List<Map<String, dynamic>>.from(res as List);
    } catch (_) {
      return [];
    }
  }

  static Future<void> markAllAsRead() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) return;
    try {
      await Supabase.instance.client
          .from('notificaciones')
          .update({'leida': true})
          .eq('cliente_id', user.id)
          .eq('leida', false);
    } catch (_) {}
  }
}
