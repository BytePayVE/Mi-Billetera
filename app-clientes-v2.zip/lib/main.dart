import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'core/config.dart';
import 'core/theme.dart';
import 'screens/auth_screen.dart';
import 'screens/home_shell.dart';
import 'screens/splash_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(
    url: AppConfig.supabaseUrl,
    anonKey: AppConfig.supabaseAnonKey,
  );
  runApp(const PagobyteClientesApp());
}

class PagobyteClientesApp extends StatefulWidget {
  const PagobyteClientesApp({super.key});

  @override
  State<PagobyteClientesApp> createState() => _PagobyteClientesAppState();
}

class _PagobyteClientesAppState extends State<PagobyteClientesApp> {
  bool _showSplash = true;
  bool _hasSession = Supabase.instance.client.auth.currentSession != null;

  @override
  void initState() {
    super.initState();
    Supabase.instance.client.auth.onAuthStateChange.listen((data) {
      if (mounted) {
        setState(() => _hasSession = data.session != null);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    Widget current;
    if (_showSplash) {
      current = SplashScreen(
        key: const ValueKey('splash'),
        onFinished: () {
          if (mounted) setState(() => _showSplash = false);
        },
      );
    } else if (_hasSession) {
      current = HomeShell(
        key: const ValueKey('home'),
        onSignedOut: () => setState(() => _hasSession = false),
      );
    } else {
      current = AuthScreen(
        key: const ValueKey('auth'),
        onAuthenticated: () => setState(() => _hasSession = true),
      );
    }

    return MaterialApp(
      title: 'Pagobyte',
      debugShowCheckedModeBanner: false,
      theme: PagobyteTheme.build(),
      home: AnimatedSwitcher(
        duration: const Duration(milliseconds: 380),
        child: current,
      ),
    );
  }
}
