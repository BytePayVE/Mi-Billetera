import 'package:flutter/material.dart';
import 'config.dart';
import 'theme.dart';

class TermSection {
  final String title;
  final List<String> paragraphs;

  const TermSection(this.title, this.paragraphs);
}

const List<TermSection> kPagobyteTerms = [
  TermSection('IDENTIFICACIÓN DE LA PLATAFORMA Y ACEPTACIÓN CONTRACTUAL', [
    'El presente Contrato de Adhesión, Términos y Condiciones de Uso y Compromiso de Pago (en lo sucesivo, "EL CONTRATO") regula el acceso, registro y utilización de la aplicación móvil y ecosistema tecnológico PAGOBYTE (en lo sucesivo, "LA ORGANIZACIÓN" o "PAGOBYTE").',
    'Al completar el proceso de lectura obligatoria al cien por ciento (100%), marcar la casilla de conformidad y presionar el botón de registro, el solicitante (en lo sucesivo, "EL CLIENTE") declara ser mayor de edad, civilmente hábil conforme al Código Civil de la República Bolivariana de Venezuela, y manifiesta su consentimiento libre, expreso e inequívoco de someterse a todas y cada una de las cláusulas aquí contenidas. Conforme a los artículos 1.133, 1.159 y 1.160 del Código Civil venezolano, este contrato tiene fuerza de ley entre las partes y obliga no solo a lo expresado en él, sino a todas las consecuencias que se derivan según la equidad, el uso y la ley.'
  ]),
  TermSection('NATURALEZA JURÍDICA Y DESLINDE EXPRESO ANTE SUDEBAN Y SENIAT', [
    'PAGOBYTE opera exclusiva y estrictamente como una plataforma tecnológica de registro, gestión de solicitudes, control de cronogramas y verificación documental para compras a plazo (en cuotas) realizadas en comercios aliados o mediante el catálogo autorizado.',
    'En cumplimiento con el Decreto con Rango, Valor y Fuerza de Ley de Instituciones del Sector Bancario (Gaceta Oficial Extraordinaria N° 6.154 del 19 de noviembre de 2014), se deja constancia expresa de que PAGOBYTE NO ES UNA INSTITUCIÓN BANCARIA, NO CAPTA FONDOS DEL PÚBLICO, NO REALIZA INTERMEDIACIÓN FINANCIERA Y NO ESTÁ AUTORIZADA POR LA SUPERINTENDENCIA DE INSTITUCIONES DEL SECTOR BANCARIO (SUDEBAN) PARA FUNGIR COMO PASARELA DE PAGOS.',
    'Todos los desembolsos correspondientes a la cuota inicial y a las cuotas sucesivas son transferidos o depositados directamente por EL CLIENTE hacia las cuentas bancarias o Pago Móvil del comercio vendedor o beneficiario autorizado, al tipo de cambio oficial publicado por el Banco Central de Venezuela (BCV) vigente para el día efectivo del pago. La facturación fiscal ante el SENIAT corresponde directamente al comercio vendedor que entrega el bien.'
  ]),
  TermSection('VALIDEZ JURÍDICA DEL CONTRATO ELECTRÓNICO Y FIRMA DIGITAL', [
    'De conformidad con lo dispuesto en los artículos 4, 5, 6, 16 y 17 del Decreto con Fuerza de Ley sobre Mensajes de Datos y Firmas Electrónicas (Gaceta Oficial N° 37.148 del 28 de febrero de 2001), los mensajes de datos, registros electrónicos de aceptación, marcas de tiempo (timestamps), direcciones IP, registros de auditoría en base de datos, fotografías de identidad y comprobantes de pago transmitidos a través de PAGOBYTE poseen la misma eficacia probatoria que la ley otorga a los documentos escritos firmados de puño y letra.',
    'EL CLIENTE renuncia expresamente a desconocer la validez o eficacia probatoria de su aceptación digital, de las ofertas aceptadas en la aplicación y de los registros almacenados en los servidores seguros de LA ORGANIZACIÓN.'
  ]),
  TermSection('VERIFICACIÓN DE IDENTIDAD (KYC), DOMICILIO Y DECLARACIÓN JURADA', [
    'Para acceder a las funcionalidades de la aplicación, EL CLIENTE debe suministrar de forma obligatoria: (a) nombre y apellido completos tal como figuran en su documento de identidad, (b) número de Cédula de Identidad venezolana (V/E), (c) número telefónico personal activo con WhatsApp, (d) correo electrónico personal verificable, (e) dirección exacta de residencia indicando Estado, Ciudad, tipo de zona (Urbanización, Barrio, Caserío, Villa o Sector) y punto de referencia, (f) fotografía frontal nítida de su Cédula de Identidad vigente, y (g) fotografía personal (selfie) del rostro del titular.',
    'EL CLIENTE declara bajo fe de juramento que toda la información y evidencias fotográficas consignadas son auténticas, verídicas y de su exclusiva titularidad. La falsedad en estos datos constituirá causal de rechazo inmediato, nulidad de beneficios y activación de acciones penales y civiles.'
  ]),
  TermSection('INMUTABILIDAD DE DATOS LEGALES Y DOMICILIO CONTRACTUAL', [
    'Los datos de identidad (nombre completo, cédula, teléfono, correo electrónico y domicilio declarado) constituyen el aval legal y el domicilio contractual de EL CLIENTE para todo efecto de notificación, verificación de pagos y cobranza. Por razones estrictas de seguridad jurídica, dichos campos permanecerán bloqueados contra edición directa dentro de la aplicación.',
    'Cualquier solicitud de corrección por error material comprobable deberá ser gestionada exclusivamente ante el equipo de soporte oficial de PAGOBYTE previa consignación de recaudos probatorios y siempre que EL CLIENTE se encuentre totalmente solvente.'
  ]),
  TermSection('APLICACIÓN DE LA LEY ESPECIAL CONTRA LOS DELITOS INFORMÁTICOS', [
    'El uso indebido de la plataforma queda expresamente sujeto a las disposiciones de la Ley Especial contra los Delitos Informáticos (Gaceta Oficial N° 37.313 del 30 de octubre de 2001), incluyendo de manera enunciativa y no limitativa: acceso indebido a sistemas protegidos (Art. 6), sabotaje o daño a sistemas (Art. 7), posesión de equipos o prestación de servicios de sabotaje (Art. 9), espionaje informático (Art. 11), falsificación de documentos electrónicos (Art. 12), hurto electrónico (Art. 13), fraude informático (Art. 14), obtención indebida de bienes o servicios (Art. 15) y apropiación de propiedad intelectual (Art. 25).',
    'Cualquier intento de manipular precios, vulnerar la seguridad de la base de datos, falsificar capturas digitales o suplantar identidades será documentado con registros técnicos de auditoría y denunciado de inmediato ante el Cuerpo de Investigaciones Científicas, Penales y Criminalísticas (CICPC — División de Delitos Informáticos) y el Ministerio Público.'
  ]),
  TermSection('RÉGIMEN DE SOLICITUDES Y LÍMITE DE UNA OPERACIÓN ACTIVA', [
    'El envío de una solicitud de producto no obliga a PAGOBYTE ni a los comercios aliados a aprobarla. Cada solicitud será evaluada discrecionalmente según el perfil, historial, disponibilidad de inventario y verificación KYC de EL CLIENTE.',
    'Cada cuenta verificada podrá mantener únicamente UNA (1) solicitud pendiente o UNA (1) compra financiada activa a la vez. Solo al verificarse el pago del cien por ciento (100%) de las cuotas de la compra en curso se habilitará la posibilidad de enviar una nueva solicitud.'
  ]),
  TermSection('PRECIOS FINALES, CERO INTERESES ORDINARIOS Y SISTEMA DE FASES', [
    'Todos los precios reflejados en el catálogo están expresados en dólares estadounidenses (USD) y corresponden al precio final de venta acordado comercialmente. Las cuotas fraccionadas no generan intereses ordinarios ni recargos adicionales de IVA sobre el monto previamente fijado en la oferta aceptada.',
    'La cantidad máxima de cuotas quincenales depende del nivel o Fase alcanzada por EL CLIENTE: Fase 1 Bit (hasta 3 cuotas), Fase 2 Byte (hasta 4 cuotas), Fase 3 Kilo (hasta 5 cuotas), Fase 4 Mega (hasta 6 cuotas) y Fase 5 Giga (hasta 9 cuotas, sujeto a la categoría y valor del producto). El cumplimiento puntual y el adelanto de cuotas acumulan puntos que permiten optar a ascensos de Fase, cuya aprobación final corresponde a LA ORGANIZACIÓN.'
  ]),
  TermSection('CUOTA INICIAL MÍNIMA E IRREVOCABILIDAD DE LA COMPRA', [
    'Toda compra aprobada exige el pago previo de una cuota inicial equivalente como mínimo al cuarenta por ciento (40%) del precio final. Hasta tanto la cuota inicial no sea reportada por EL CLIENTE y verificada efectivamente en la cuenta bancaria receptora, el contrato de compra no entra en fase activa, no se entrega el producto y no corre el cronograma de cuotas.',
    'Una vez verificada la cuota inicial y entregado el bien, la compra adquiere carácter DEFINITIVO E IRREVOCABLE: no procede arrepentimiento, devolución del producto ni reembolso total o parcial de la cuota inicial, quedando a salvo únicamente los derechos de garantía legal en caso de defectos comprobables de fabricación.'
  ]),
  TermSection('DERECHO AL ADELANTO DE CUOTAS', [
    'EL CLIENTE podrá adelantar el pago de una, varias o la totalidad de sus cuotas pendientes antes de sus fechas de vencimiento sin penalidad ni comisión alguna. Cada pago adelantado debidamente verificado sumará puntos adicionales en el historial de EL CLIENTE para acelerar su ascenso de Fase.'
  ]),
  TermSection('PAGOS EN BOLÍVARES Y TASA OFICIAL BCV', [
    'Los pagos efectuados en moneda de curso legal (bolívares) se calcularán estrictamente con base en el tipo de cambio oficial publicado por el Banco Central de Venezuela (BCV) vigente para el día en que EL CLIENTE realiza y reporta el pago. EL CLIENTE asume la obligación de transferir el monto exacto indicado en la aplicación; pagos incompletos no liberarán la cuota hasta cubrir la diferencia.'
  ]),
  TermSection('COMPROBANTES FALSOS, SUSPENSIÓN PERMANENTE Y DENUNCIA FORMAL', [
    'Todo pago reportado mediante la aplicación será sometido a auditoría bancaria real. Si EL CLIENTE sube un comprobante falso, editado, manipulado digitalmente, reutiliza un número de referencia ya empleado o reporta una transferencia inexistente, LA ORGANIZACIÓN aplicará de forma inmediata e inapelable la SUSPENSIÓN PERMANENTE de la cuenta y el bloqueo de la cédula en todo el ecosistema de tiendas aliadas.',
    'Adicionalmente, LA ORGANIZACIÓN se reserva el derecho irrenunciable de interponer DENUNCIA PENAL FORMAL ante el Ministerio Público y el CICPC contra EL CLIENTE por la presunta comisión de los delitos de estafa (Art. 462 del Código Penal), forjamiento o uso de documento privado falso (Arts. 319 y 321 del Código Penal) y fraude informático (Arts. 12 y 14 de la Ley Especial contra los Delitos Informáticos), consignando como acervo probatorio el expediente KYC (cédula, selfie, dirección, teléfono, correo) y los registros digitales del fraude.'
  ]),
  TermSection('MORA, RECARGOS ACUMULATIVOS Y COBRANZA EXTRAJUDICIAL/JUDICIAL', [
    'Las cuotas vencen cada quince (15) días continuos contados desde la verificación de la inicial. Si transcurren dos (2) días continuos posteriores a la fecha de vencimiento sin que EL CLIENTE haya realizado y reportado el pago válido, se generará automáticamente un recargo por mora de CINCO DÓLARES ESTADOUNIDENSES (\$5.00 USD) o su equivalente en bolívares a tasa BCV.',
    'De persistir el incumplimiento a la semana siguiente, el recargo se incrementará en CINCO DÓLARES (\$5.00 USD) adicionales por cada semana de atraso acumulada, hasta un tope máximo equivalente al valor nominal de la cuota vencida.',
    'Durante la mora, EL CLIENTE autoriza expresamente a LA ORGANIZACIÓN y al comercio acreedor a contactarlo por vía telefónica, SMS, WhatsApp, correo electrónico y notificaciones en la aplicación. Superados quince (15) días de atraso sin regularización, LA ORGANIZACIÓN podrá dar por vencido de pleno derecho el plazo de todas las cuotas restantes (cláusula de aceleración), exigir el saldo total adeudado más recargos, incluir la cédula en el buró interno compartido de morosidad e iniciar las acciones de cobranza extrajudicial y demanda judicial ante los tribunales competentes, siendo por cuenta de EL CLIENTE las costas y costos procesales conforme al Código de Procedimiento Civil.'
  ]),
  TermSection('EXONERACIÓN DE RESPONSABILIDAD Y DEFENSA ANTE RECLAMOS INFUNDADOS', [
    'PAGOBYTE no será responsable por fallas de conectividad del operador telefónico de EL CLIENTE, interrupciones de la banca nacional (Pago Móvil o transferencias interbancarias) ni por retrasos imputables a datos bancarios ingresados erróneamente por el usuario.',
    'En caso de que EL CLIENTE promueva denuncias, reclamos administrativos o demandas judiciales infundadas, temerarias o contrarias a los hechos registrados en la plataforma, LA ORGANIZACIÓN hará valer el presente contrato electrónico, el registro de lectura al 100%, los comprobantes de entrega, las evidencias KYC y el historial de auditoría como plena defensa jurídica, reservándose el derecho de reclamar daños y perjuicios conforme al artículo 1.185 del Código Civil venezolano.'
  ]),
  TermSection('PROPIEDAD INTELECTUAL Y MARCA PAGOBYTE', [
    'El nombre comercial PAGOBYTE, su isotipo de cuatro bloques, paleta cromática, código fuente, interfaces, textos legales y diseños son propiedad exclusiva de LA ORGANIZACIÓN y están protegidos por la Ley sobre el Derecho de Autor y la Ley de Propiedad Industrial. Queda prohibida su copia, ingeniería inversa o uso comercial no autorizado.'
  ]),
  TermSection('MODIFICACIONES, LEGISLACIÓN APLICABLE Y JURISDICCIÓN', [
    'LA ORGANIZACIÓN podrá actualizar estos Términos y Condiciones por motivos operativos o legales, notificando la nueva versión dentro de la aplicación. El presente contrato se rige íntegramente por las leyes de la República Bolivariana de Venezuela (Constitución Nacional, Código Civil, Código de Comercio, Código Penal, Ley sobre Mensajes de Datos y Firmas Electrónicas y Ley Especial contra los Delitos Informáticos). Para todos los efectos derivados de este contrato, las partes eligen como domicilio especial y exclusivo la jurisdicción de los tribunales competentes del Estado Lara, Venezuela.'
  ]),
];

const List<TermSection> kPagobytePrivacy = [
  TermSection('FUNDAMENTO CONSTITUCIONAL Y PRINCIPIO DE HABEAS DATA', [
    'La presente Política de Privacidad y Protección de Datos Personales se dicta en estricto acatamiento de los artículos 28 y 60 de la Constitución de la República Bolivariana de Venezuela, que consagran el derecho de toda persona a conocer el uso y finalidad de la información que sobre sí misma o sobre sus bienes conste en registros oficiales o privados, así como la protección del honor, la vida privada y la confidencialidad.'
  ]),
  TermSection('CATEGORÍAS DE DATOS PERSONALES RECOPILADOS', [
    'Para operar de forma segura, PAGOBYTE recopila únicamente los datos estrictamente necesarios: (1) Datos identificativos: nombre completo, número de cédula (V/E), fotografía frontal de la cédula y fotografía personal (selfie); (2) Datos de contacto: teléfono móvil, WhatsApp y correo electrónico; (3) Datos de ubicación y domicilio: Estado, Ciudad, tipo de zona residencial, dirección exacta y permiso de geolocalización en uso; (4) Datos transaccionales: historial de solicitudes, cuotas, referencias bancarias y capturas de comprobantes de pago.'
  ]),
  TermSection('CONSENTIMIENTO EXPRESO E INFORMADO', [
    'Al completar la lectura obligatoria y aceptar este documento al registrarse, EL CLIENTE otorga su consentimiento expreso, previo e informado para que PAGOBYTE recopile, almacene, procese y audite los datos antes descritos, incluyendo las fotografías de identidad y domicilio, exclusivamente para los fines legítimos detallados en esta política.'
  ]),
  TermSection('FINALIDADES DEL TRATAMIENTO DE DATOS', [
    'Los datos recopilados serán utilizados exclusivamente para: (a) verificar la identidad real de EL CLIENTE y prevenir suplantaciones o fraudes (procedimiento KYC); (b) evaluar la capacidad de aprobación y asignación de Fases y cuotas; (c) emitir contratos digitales, cronogramas y constancias de solvencia; (d) enviar notificaciones operativas de vencimiento, aprobación o mora directamente desde la base de datos de la plataforma; y (e) sustentar gestiones de cobranza extrajudicial o acciones judiciales en caso de impago o fraude.'
  ]),
  TermSection('ALMACENAMIENTO SEGURO Y CONTROL DE ACCESO RESTRINGIDO', [
    'Todos los datos de texto y evidencias fotográficas (cédula, selfie y comprobantes) se almacenan en infraestructura en la nube con cifrado en tránsito (TLS/HTTPS) y en reposo. Las imágenes de identidad se alojan en repositorios privados (buckets sin acceso público) protegidos mediante políticas de seguridad a nivel de fila (Row Level Security), siendo accesibles únicamente por administradores autenticados de LA ORGANIZACIÓN.'
  ]),
  TermSection('PROHIBICIÓN DE VENTA DE DATOS Y CESIÓN LIMITADA', [
    'PAGOBYTE declara y garantiza que NO VENDE, NO ALQUILA y NO COMERCIALIZA los datos personales de sus clientes a terceros ni a agencias de publicidad. Los datos únicamente podrán ser comunicados a: (1) el comercio aliado específico donde EL CLIENTE realice su compra financiada; (2) proveedores de infraestructura tecnológica bajo estándares de confidencialidad; y (3) autoridades judiciales, Ministerio Público, CICPC o cuerpos de seguridad del Estado venezolano cuando exista orden judicial, requerimiento legal o denuncia formal por fraude o incumplimiento.'
  ]),
  TermSection('PLAZO DE CONSERVACIÓN DE LA INFORMACIÓN', [
    'Los datos personales, contratos electrónicos y evidencias KYC se conservarán activos mientras EL CLIENTE mantenga su cuenta o exista alguna obligación pendiente. Finalizada la relación comercial, la información podrá conservarse bloqueada durante el lapso legal de prescripción de obligaciones mercantiles y civiles establecido en el Código Civil y el Código de Comercio venezolano para la defensa ante eventuales reclamaciones.'
  ]),
  TermSection('USO DE PERMISOS DEL DISPOSITIVO (CÁMARA, UBICACIÓN Y NOTIFICACIONES)', [
    'La aplicación solicita acceso a la cámara y galería únicamente para capturar las fotos de verificación de identidad (KYC) y los comprobantes de pago; permiso de ubicación en uso para validar la zona de operación comercial; y permiso de notificaciones locales para alertar sobre ofertas, verificaciones y fechas de pago directamente desde la base de datos de PAGOBYTE sin compartir identificadores con redes publicitarias de terceros.'
  ]),
  TermSection('DERECHOS DEL TITULAR DE LOS DATOS', [
    'EL CLIENTE podrá ejercer en todo momento su derecho constitucional de acceso consultando sus datos registrados en la pestaña "Perfil" de la aplicación. Asimismo, podrá solicitar la rectificación de datos inexactos o la actualización de información escribiendo al canal oficial de soporte de PAGOBYTE, sujeto a verificación de identidad y solvencia.'
  ]),
  TermSection('RESPONSABILIDAD DE CUSTODIA DE CREDENCIALES', [
    'EL CLIENTE es el único responsable de resguardar su correo electrónico y contraseña de acceso a la aplicación. Toda operación, aceptación de oferta o reporte de pago realizado desde su sesión autenticada se presumirá ejecutado válidamente por el titular de la cuenta.'
  ]),
];


const List<TermSection> kPagobyteAnexos = [
  TermSection('ANEXO I — POLÍTICA DE GARANTÍAS Y DEVOLUCIONES', [
    'Todos los productos ofrecidos a través del ecosistema PAGOBYTE son vendidos y entregados directamente por los Comercios Aliados o el inventario autorizado. En consecuencia, la garantía por defectos de fábrica es cubierta exclusivamente por el comercio vendedor conforme al Serial o IMEI registrado al momento de la entrega física.',
    'Una vez verificada la cuota inicial y entregado el producto conforme al Cliente, la compra es definitiva e irrevocable: PAGOBYTE no gestiona devoluciones por cambio de opinión ni reembolsos de iniciales o cuotas ya abonadas a las cuentas bancarias de los comercios.'
  ]),
  TermSection('ANEXO II — POLÍTICA DE COBRANZA, MORA Y ACUERDOS DE PAGO', [
    'PAGOBYTE enviará recordatorios preventivos antes de cada fecha de vencimiento quincenal mediante notificaciones en la aplicación, correo electrónico o WhatsApp. Transcurridos dos (2) días de atraso se aplica automáticamente el recargo de cinco dólares (\$5.00 USD) y cinco dólares (\$5.00 USD) por cada semana adicional hasta el tope de la cuota vencida.',
    'En caso de dificultad comprobable, EL CLIENTE podrá contactar a soporte antes de cumplir quince (15) días de mora para solicitar un Acuerdo de Pago formal, el cual congelará recargos adicionales únicamente mientras se cumpla el abono y la nueva fecha límite pactada. El incumplimiento del acuerdo reactiva el saldo total acelerado y la cobranza judicial.'
  ]),
  TermSection('ANEXO III — POLÍTICA ANTIFRAUDE Y SUSPENSIÓN PERMANENTE', [
    'El sistema monitorea automáticamente patrones de riesgo, incluyendo teléfonos repetidos, direcciones duplicadas, suplantación de identidad y reutilización de números de referencia bancaria.',
    'Cualquier carga de comprobante editado, falso o referencia duplicada produce la suspensión permanente inmediata en el Buró Interno de PAGOBYTE (compartido con todas las tiendas aliadas) y faculta a LA ORGANIZACIÓN a consignar el expediente KYC (cédula, selfie, domicilio y trazabilidad digital) ante el CICPC y el Ministerio Público para las denuncias penales correspondientes.'
  ]),
];

void showTermsBottomSheet(BuildContext context, {int initialTab = 0}) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: PagobyteColors.paper,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
    builder: (ctx) => DefaultTabController(
      length: 3,
      initialIndex: initialTab,
      child: DraggableScrollableSheet(
        initialChildSize: 0.90,
        minChildSize: 0.55,
        maxChildSize: 0.96,
        expand: false,
        builder: (_, scrollCtrl) => Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 12, 6),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Marco Legal Pagobyte', style: PagobyteTheme.heading(20)),
                      Text(
                        'Versión ${AppConfig.terminosVersion}',
                        style: const TextStyle(color: PagobyteColors.muted, fontSize: 12),
                      ),
                    ],
                  ),
                  TextButton(
                    onPressed: () => Navigator.pop(ctx),
                    child: const Text('Cerrar', style: TextStyle(fontWeight: FontWeight.w700)),
                  ),
                ],
              ),
            ),
            const TabBar(
              labelColor: PagobyteColors.byteBlue,
              unselectedLabelColor: PagobyteColors.muted,
              indicatorColor: PagobyteColors.byteBlue,
              tabs: [
                Tab(text: 'Términos (16)'),
                Tab(text: 'Privacidad (10)'),
                Tab(text: 'Anexos (3)'),
              ],
            ),
            Expanded(
              child: TabBarView(
                children: [
                  _buildTermsList(kPagobyteTerms, scrollCtrl),
                  _buildTermsList(kPagobytePrivacy, scrollCtrl),
                  _buildTermsList(kPagobyteAnexos, scrollCtrl),
                ],
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

Widget _buildTermsList(List<TermSection> sections, ScrollController ctrl) {
  return ListView.builder(
    controller: ctrl,
    padding: const EdgeInsets.all(20),
    itemCount: sections.length,
    itemBuilder: (_, idx) {
      final sec = sections[idx];
      return Padding(
        padding: const EdgeInsets.only(bottom: 18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'CLÁUSULA ${idx + 1}. ${sec.title}',
              style: PagobyteTheme.heading(14.5, color: PagobyteColors.byteBlue),
            ),
            const SizedBox(height: 5),
            ...sec.paragraphs.map(
              (p) => Padding(
                padding: const EdgeInsets.only(top: 5),
                child: Text(
                  p,
                  textAlign: TextAlign.justify,
                  style: const TextStyle(fontSize: 13.5, height: 1.5),
                ),
              ),
            ),
          ],
        ),
      );
    },
  );
}
