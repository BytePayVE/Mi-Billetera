import 'package:flutter/material.dart';
import '../core/theme.dart';

enum ToastType { info, success, warning, error }

/// 01. TOAST: Aviso flotante elegante con ícono y barra de estado
class PagobyteToast {
  static void show(
    BuildContext context,
    String message, {
    ToastType type = ToastType.info,
    Duration duration = const Duration(seconds: 3),
  }) {
    if (!context.mounted) return;
    Color accent;
    IconData icon;
    switch (type) {
      case ToastType.success:
        accent = const Color(0xFF10B981);
        icon = Icons.check_circle_rounded;
        break;
      case ToastType.warning:
        accent = const Color(0xFFF59E0B);
        icon = Icons.warning_amber_rounded;
        break;
      case ToastType.error:
        accent = const Color(0xFFEF4444);
        icon = Icons.error_rounded;
        break;
      case ToastType.info:
        accent = PagobyteColors.cyan;
        icon = Icons.info_rounded;
        break;
    }

    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          duration: duration,
          elevation: 0,
          backgroundColor: Colors.transparent,
          behavior: SnackBarBehavior.floating,
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 86),
          padding: EdgeInsets.zero,
          content: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              color: PagobyteColors.ink,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: accent.withOpacity(0.55), width: 1.2),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.25),
                  blurRadius: 14,
                  offset: const Offset(0, 6),
                ),
              ],
            ),
            child: Row(
              children: [
                Icon(icon, color: accent, size: 22),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    message,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 13.5,
                      fontWeight: FontWeight.w600,
                      height: 1.3,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
  }
}

/// 02. MODAL: Diálogo animado con escala suave
class PagobyteModal {
  static Future<T?> show<T>(
    BuildContext context, {
    required String title,
    required Widget content,
    List<Widget>? actions,
  }) {
    return showGeneralDialog<T>(
      context: context,
      barrierDismissible: true,
      barrierLabel: 'Cerrar',
      barrierColor: Colors.black54,
      transitionDuration: const Duration(milliseconds: 220),
      pageBuilder: (_, __, ___) => const SizedBox.shrink(),
      transitionBuilder: (ctx, anim, _, __) {
        final curved = CurvedAnimation(parent: anim, curve: Curves.easeOutBack);
        return FadeTransition(
          opacity: anim,
          child: ScaleTransition(
            scale: Tween<double>(begin: 0.90, end: 1.0).animate(curved),
            child: AlertDialog(
              backgroundColor: PagobyteColors.card,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
              title: Text(title, style: PagobyteTheme.heading(18)),
              content: content,
              actions: actions,
            ),
          ),
        );
      },
    );
  }
}

/// 03. TOOLTIP: Burbuja informativa con la identidad Pagobyte
class PagobyteTooltip extends StatelessWidget {
  final String message;
  final Widget child;

  const PagobyteTooltip({
    super.key,
    required this.message,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: message,
      triggerMode: TooltipTriggerMode.tap,
      preferBelow: false,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      margin: const EdgeInsets.symmetric(horizontal: 20),
      decoration: BoxDecoration(
        color: PagobyteColors.ink,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: PagobyteColors.cyan.withOpacity(0.5)),
      ),
      textStyle: const TextStyle(
        color: Colors.white,
        fontSize: 12.5,
        fontWeight: FontWeight.w500,
      ),
      child: child,
    );
  }
}

/// 04. SKELETON LOADER: Carga animada tipo pulso/shimmer sin librerías externas
class PagobyteSkeleton extends StatefulWidget {
  final double width;
  final double height;
  final double radius;

  const PagobyteSkeleton({
    super.key,
    this.width = double.infinity,
    required this.height,
    this.radius = 12,
  });

  @override
  State<PagobyteSkeleton> createState() => _PagobyteSkeletonState();
}

class _PagobyteSkeletonState extends State<PagobyteSkeleton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 950),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (_, __) {
        final color = Color.lerp(
          const Color(0xFFE2E7F3),
          const Color(0xFFF1F4FB),
          _ctrl.value,
        );
        return Container(
          width: widget.width,
          height: widget.height,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(widget.radius),
          ),
        );
      },
    );
  }
}

/// Lista de Skeleton Cards para pantallas de carga
class PagobyteSkeletonList extends StatelessWidget {
  final int count;
  final bool showHero;

  const PagobyteSkeletonList({
    super.key,
    this.count = 3,
    this.showHero = true,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 12, 18, 110),
      children: [
        if (showHero) ...[
          const PagobyteSkeleton(height: 145, radius: 20),
          const SizedBox(height: 14),
        ],
        ...List.generate(
          count,
          (_) => Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: PagobyteColors.card,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: PagobyteColors.line),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    PagobyteSkeleton(width: 150, height: 16, radius: 6),
                    PagobyteSkeleton(width: 68, height: 16, radius: 6),
                  ],
                ),
                SizedBox(height: 10),
                PagobyteSkeleton(width: 220, height: 12, radius: 6),
                SizedBox(height: 12),
                PagobyteSkeleton(height: 44, radius: 10),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

/// 05. BADGE: Insignia moderna (con contador o punto de estado)
class PagobyteBadge extends StatelessWidget {
  final String label;
  final Color? backgroundColor;
  final Color? textColor;
  final bool showDot;

  const PagobyteBadge({
    super.key,
    required this.label,
    this.backgroundColor,
    this.textColor,
    this.showDot = false,
  });

  @override
  Widget build(BuildContext context) {
    final fg = textColor ?? PagobyteColors.byteBlue;
    final bg = backgroundColor ?? PagobyteColors.tint;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (showDot) ...[
            Container(
              width: 6,
              height: 6,
              decoration: BoxDecoration(color: fg, shape: BoxShape.circle),
            ),
            const SizedBox(width: 5),
          ],
          Text(
            label,
            style: TextStyle(
              color: fg,
              fontSize: 11.5,
              fontWeight: FontWeight.w800,
              letterSpacing: 0.2,
            ),
          ),
        ],
      ),
    );
  }
}
