import 'package:flutter/material.dart';
import '../core/theme.dart';

class PagobyteLogo extends StatelessWidget {
  final double size;
  final bool darkSurface;

  const PagobyteLogo({
    super.key,
    this.size = 30,
    this.darkSurface = false,
  });

  @override
  Widget build(BuildContext context) {
    final Color c1 = darkSurface ? Colors.white : PagobyteColors.ink;
    final Color c2 = darkSurface ? PagobyteColors.cyan : PagobyteColors.byteBlue;
    final double gap = size * 0.10;
    final double box = (size - gap) / 2;

    return SizedBox(
      width: size,
      height: size,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _block(box, c1, box * 0.25),
              _block(box, c1, box * 0.25),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _block(box, c1, box * 0.25),
              _block(box * 0.9, c2, box * 0.22),
            ],
          ),
        ],
      ),
    );
  }

  Widget _block(double s, Color color, double radius) {
    return Container(
      width: s,
      height: s,
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(radius),
      ),
    );
  }
}

class PagobyteWordmark extends StatelessWidget {
  final double fontSize;
  final bool darkSurface;

  const PagobyteWordmark({
    super.key,
    this.fontSize = 22,
    this.darkSurface = false,
  });

  @override
  Widget build(BuildContext context) {
    return RichText(
      text: TextSpan(
        children: [
          TextSpan(
            text: 'Pago',
            style: PagobyteTheme.heading(
              fontSize,
              color: darkSurface ? Colors.white : PagobyteColors.ink,
            ),
          ),
          TextSpan(
            text: 'byte',
            style: PagobyteTheme.mono(
              fontSize * 0.95,
              color: darkSurface ? PagobyteColors.cyan : PagobyteColors.byteBlue,
              weight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}
